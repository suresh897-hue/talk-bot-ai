import React, { useState } from 'react';
import { Shield, FileText } from 'lucide-react';
import { Language } from '../types';

interface LegalPageProps {
  initialTab?: 'privacy' | 'terms';
}

export const LegalPage: React.FC<LegalPageProps> = ({ initialTab = 'privacy' }) => {
  const [tab, setTab] = useState<'privacy' | 'terms'>(initialTab);

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-10 space-y-8">
      {/* Tab Switcher */}
      <div className="flex items-center justify-center">
        <div className="flex items-center p-1 rounded-xl bg-neutral-900 border border-neutral-800">
          <button
            onClick={() => setTab('privacy')}
            className={`px-4 py-2 rounded-lg text-xs font-semibold flex items-center gap-2 transition-colors cursor-pointer ${
              tab === 'privacy'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <Shield className="w-4 h-4" />
            <span>Privacy Policy</span>
          </button>
          <button
            onClick={() => setTab('terms')}
            className={`px-4 py-2 rounded-lg text-xs font-semibold flex items-center gap-2 transition-colors cursor-pointer ${
              tab === 'terms'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>Terms & Conditions</span>
          </button>
        </div>
      </div>

      {/* Content Container */}
      <div className="rounded-2xl border border-amber-500/20 bg-neutral-950 p-6 sm:p-10 shadow-2xl text-neutral-300 text-xs sm:text-sm leading-relaxed space-y-6">
        {tab === 'privacy' ? (
          <>
            <div className="border-b border-neutral-800 pb-4">
              <h1 className="text-2xl sm:text-3xl font-extrabold text-white">Privacy Policy</h1>
              <p className="text-xs text-neutral-500 mt-1">Effective Date: October 2026 · TalkBot AI</p>
            </div>

            <section className="space-y-2">
              <h2 className="text-base font-bold text-amber-300">1. Information We Collect</h2>
              <p>
                TalkBot AI values user confidentiality. When you create an account, we store your email, name, and a cryptographically salted password hash. We do not store plaintext passwords. When you interact with our chat system, your conversation history is linked exclusively to your private account ID.
              </p>
            </section>

            <section className="space-y-2">
              <h2 className="text-base font-bold text-amber-300">2. Processing of AI Queries</h2>
              <p>
                Your prompts and messages are processed server-side through Google Gemini APIs solely to generate responses. We do not sell your personal prompts, user profiles, or academic data to third-party data brokers.
              </p>
            </section>

            <section className="space-y-2">
              <h2 className="text-base font-bold text-amber-300">3. Local Storage & Security</h2>
              <p>
                Sessions and theme preferences are stored locally in your browser to maintain responsiveness and offline state. Backend tokens use authenticated Bearer headers with expiration lifetimes.
              </p>
            </section>

            <section className="space-y-2">
              <h2 className="text-base font-bold text-amber-300">4. Advertising and Cookies</h2>
              <p>
                TalkBot AI prepares dedicated ad placement slots for Google AdSense. Any future advertising integration will comply strictly with Google AdSense policies and GDPR / CCPA cookie consent frameworks.
              </p>
            </section>
          </>
        ) : (
          <>
            <div className="border-b border-neutral-800 pb-4">
              <h1 className="text-2xl sm:text-3xl font-extrabold text-white">Terms and Conditions</h1>
              <p className="text-xs text-neutral-500 mt-1">Last Updated: October 2026 · TalkBot AI</p>
            </div>

            <section className="space-y-2">
              <h2 className="text-base font-bold text-amber-300">1. Acceptance of Terms</h2>
              <p>
                By accessing or using TalkBot AI, you agree to comply with these Terms and Conditions. TalkBot AI is provided for educational, professional, and general informational productivity.
              </p>
            </section>

            <section className="space-y-2">
              <h2 className="text-base font-bold text-amber-300">2. Permitted Use & Safety</h2>
              <p>
                You agree not to use TalkBot AI to generate illegal content, hate speech, malicious malware, or harassment. We maintain strict compliance with Google Generative AI prohibited use policies.
              </p>
            </section>

            <section className="space-y-2">
              <h2 className="text-base font-bold text-amber-300">3. AI Accuracy Disclaimer</h2>
              <p>
                While Google Gemini 3.8 Flash is a highly capable foundational model, AI-generated outputs can occasionally contain inaccuracies. Users are advised to independently verify critical mathematical calculations, legal documents, or medical information.
              </p>
            </section>

            <section className="space-y-2">
              <h2 className="text-base font-bold text-amber-300">4. Intellectual Property</h2>
              <p>
                Users retain full rights to the content and original code prompts they submit. The TalkBot AI brand, logo, and user interface designs are protected under applicable copyright laws.
              </p>
            </section>
          </>
        )}
      </div>
    </div>
  );
};
