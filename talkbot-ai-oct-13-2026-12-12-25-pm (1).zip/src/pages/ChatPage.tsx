import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import { ChatMessage, ChatSession, Language } from '../types';
import { sendChatMessage, saveUserHistory, fetchUserHistories, deleteUserHistory } from '../services/api';
import { MarkdownView } from '../components/MarkdownView';
import {
  Send,
  Plus,
  Copy,
  Check,
  RefreshCw,
  Sparkles,
  Bot,
  User,
  Trash2,
  AlertTriangle,
  Globe,
  Sliders,
  GraduationCap,
  Code,
  Briefcase,
  HelpCircle,
  MessageSquare,
  Square,
  ArrowDown,
  X,
  RotateCcw
} from 'lucide-react';

interface ChatPageProps {
  language: Language;
  setLanguage: (lang: Language) => void;
  initialPrompt?: string;
}

export const ChatPage: React.FC<ChatPageProps> = ({
  language,
  setLanguage,
  initialPrompt = ''
}) => {
  const { user, token } = useAuth();

  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [currentSessionId, setCurrentSessionId] = useState<string>('');
  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [failedPrompt, setFailedPrompt] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [selectedPersona, setSelectedPersona] = useState<'general' | 'tutor' | 'coder' | 'business'>('general');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [retryCooldown, setRetryCooldown] = useState(0);
  const [isUserScrolledUp, setIsUserScrolledUp] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const messagesContainerRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const abortControllerRef = useRef<AbortController | null>(null);

  // Countdown timer for retry cooldown to prevent rapid repeated requests
  useEffect(() => {
    if (retryCooldown <= 0) return;
    const interval = setInterval(() => {
      setRetryCooldown(prev => {
        if (prev <= 1) {
          clearInterval(interval);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [retryCooldown]);

  // Auto-expand textarea as user types (ChatGPT style)
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      const newHeight = Math.min(textareaRef.current.scrollHeight, 160);
      textareaRef.current.style.height = `${Math.max(newHeight, 46)}px`;
    }
  }, [inputMessage]);

  // Load chat histories on mount or user change
  useEffect(() => {
    let loaded: ChatSession[] = [];
    const localSaved = localStorage.getItem('talkbot_guest_sessions');
    if (localSaved) {
      try {
        loaded = JSON.parse(localSaved);
      } catch (e) {
        console.error(e);
      }
    }

    if (token) {
      fetchUserHistories(token)
        .then(res => {
          if (res.histories && res.histories.length > 0) {
            setSessions(res.histories);
            setCurrentSessionId(res.histories[0].id);
          } else if (loaded.length > 0) {
            setSessions(loaded);
            setCurrentSessionId(loaded[0].id);
          } else {
            initNewSession();
          }
        })
        .catch(() => {
          if (loaded.length > 0) {
            setSessions(loaded);
            setCurrentSessionId(loaded[0].id);
          } else {
            initNewSession();
          }
        });
    } else {
      if (loaded.length > 0) {
        setSessions(loaded);
        setCurrentSessionId(loaded[0].id);
      } else {
        initNewSession();
      }
    }
  }, [token]);

  // Handle initial prompt from other pages
  useEffect(() => {
    if (initialPrompt && initialPrompt.trim()) {
      setInputMessage(initialPrompt);
      if (textareaRef.current) {
        textareaRef.current.focus();
      }
    }
  }, [initialPrompt]);

  const currentSession = sessions.find(s => s.id === currentSessionId);

  // Smart scrolling: Only auto-scroll if user is near bottom
  const scrollToBottom = (behavior: ScrollBehavior = 'smooth') => {
    messagesEndRef.current?.scrollIntoView({ behavior });
  };

  const handleContainerScroll = () => {
    if (!messagesContainerRef.current) return;
    const { scrollTop, scrollHeight, clientHeight } = messagesContainerRef.current;
    const distanceFromBottom = scrollHeight - scrollTop - clientHeight;
    setIsUserScrolledUp(distanceFromBottom > 120);
  };

  useEffect(() => {
    if (!isUserScrolledUp) {
      scrollToBottom();
    }
  }, [currentSession?.messages, isLoading]);

  const initNewSession = () => {
    const newSession: ChatSession = {
      id: `session-${Date.now()}`,
      title: language === 'te' ? 'కొత్త సంభాషణ' : 'New Conversation',
      messages: [],
      updatedAt: new Date().toISOString()
    };
    setSessions(prev => [newSession, ...prev]);
    setCurrentSessionId(newSession.id);
    setErrorMessage(null);
    setFailedPrompt(null);
    setSidebarOpen(false);
  };

  const persistSession = (updatedSession: ChatSession) => {
    setSessions(prev =>
      prev.map(s => (s.id === updatedSession.id ? updatedSession : s))
    );

    const updatedAll = sessions.map(s => (s.id === updatedSession.id ? updatedSession : s));
    localStorage.setItem('talkbot_guest_sessions', JSON.stringify(updatedAll.slice(0, 30)));

    if (token) {
      saveUserHistory(updatedSession, token).catch(err => {
        console.warn('Failed to sync history to server:', err);
      });
    }
  };

  const handleDeleteSession = async (sessionId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const remaining = sessions.filter(s => s.id !== sessionId);
    setSessions(remaining);
    localStorage.setItem('talkbot_guest_sessions', JSON.stringify(remaining));

    if (sessionId === currentSessionId) {
      if (remaining.length > 0) {
        setCurrentSessionId(remaining[0].id);
      } else {
        initNewSession();
      }
    }

    if (token) {
      deleteUserHistory(sessionId, token).catch(() => {});
    }
  };

  const handleClearConversation = () => {
    if (!currentSession || currentSession.messages.length === 0) return;
    if (window.confirm(language === 'te' ? 'ఈ సంభాషణలోని సందేశాలన్నింటినీ తొలగించాలా?' : 'Clear all messages in this conversation?')) {
      const cleared: ChatSession = {
        ...currentSession,
        messages: [],
        updatedAt: new Date().toISOString()
      };
      persistSession(cleared);
      setErrorMessage(null);
      setFailedPrompt(null);
    }
  };

  const handleStopGeneration = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
      setIsLoading(false);
    }
  };

  const handleSendMessage = async (customPrompt?: string) => {
    const textToSend = (customPrompt || inputMessage).trim();
    if (!textToSend || isLoading || retryCooldown > 0) return;

    setErrorMessage(null);
    setFailedPrompt(null);

    let activeSession = currentSession;
    if (!activeSession) {
      const newSession: ChatSession = {
        id: `session-${Date.now()}`,
        title: textToSend.slice(0, 32),
        messages: [],
        updatedAt: new Date().toISOString()
      };
      setSessions(prev => [newSession, ...prev]);
      setCurrentSessionId(newSession.id);
      activeSession = newSession;
    }

    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      role: 'user',
      content: textToSend,
      timestamp: new Date().toISOString(),
      language
    };

    const newMessages = [...activeSession.messages, userMsg];
    const sessionTitle =
      activeSession.messages.length === 0
        ? textToSend.slice(0, 30) + (textToSend.length > 30 ? '...' : '')
        : activeSession.title;

    const updatedSession: ChatSession = {
      ...activeSession,
      title: sessionTitle,
      messages: newMessages,
      updatedAt: new Date().toISOString()
    };

    persistSession(updatedSession);
    if (!customPrompt) {
      setInputMessage('');
      if (textareaRef.current) {
        textareaRef.current.style.height = '46px';
      }
    }
    setIsLoading(true);

    const controller = new AbortController();
    abortControllerRef.current = controller;

    try {
      const payloadMessages = newMessages.map(m => ({
        role: m.role,
        content: m.content
      }));

      const res = await sendChatMessage(payloadMessages, language, selectedPersona, controller.signal);

      const botMsg: ChatMessage = {
        id: `msg-${Date.now()}-model`,
        role: 'model',
        content: res.response,
        timestamp: new Date().toISOString(),
        language: res.language
      };

      const finalSession: ChatSession = {
        ...updatedSession,
        messages: [...newMessages, botMsg],
        updatedAt: new Date().toISOString()
      };

      persistSession(finalSession);
    } catch (err: any) {
      if (err?.name === 'AbortError') {
        // User voluntarily clicked Stop Generation
        return;
      }
      console.error('Chat error:', err);
      setFailedPrompt(textToSend);
      setErrorMessage(
        err?.message ||
          'Failed to reach Gemini AI service. Please verify your connection or backend credentials.'
      );
      const cooldownSec = err?.retryAfter ? Number(err.retryAfter) : 5;
      setRetryCooldown(Math.max(cooldownSec, 5));
    } finally {
      setIsLoading(false);
      abortControllerRef.current = null;
    }
  };

  const handleRetryLastMessage = async () => {
    if (retryCooldown > 0 || isLoading) return;
    const textToRetry = failedPrompt || (() => {
      if (!currentSession) return null;
      const userMessages = currentSession.messages.filter(m => m.role === 'user');
      return userMessages.length > 0 ? userMessages[userMessages.length - 1].content : null;
    })();

    if (textToRetry) {
      setErrorMessage(null);
      setRetryCooldown(5);
      await handleSendMessage(textToRetry);
    }
  };

  const handleRestoreFailedToInput = () => {
    if (failedPrompt) {
      setInputMessage(failedPrompt);
      setErrorMessage(null);
      if (textareaRef.current) {
        textareaRef.current.focus();
      }
    }
  };

  const handleRegenerate = async () => {
    if (!currentSession || currentSession.messages.length === 0 || isLoading) return;

    const msgs = [...currentSession.messages];
    let lastUserIndex = -1;
    for (let i = msgs.length - 1; i >= 0; i--) {
      if (msgs[i].role === 'user') {
        lastUserIndex = i;
        break;
      }
    }

    if (lastUserIndex === -1) return;

    const trimmed = msgs.slice(0, lastUserIndex + 1);
    const updatedSession: ChatSession = {
      ...currentSession,
      messages: trimmed,
      updatedAt: new Date().toISOString()
    };

    persistSession(updatedSession);
    setIsLoading(true);
    setErrorMessage(null);

    const controller = new AbortController();
    abortControllerRef.current = controller;

    try {
      const payloadMessages = trimmed.map(m => ({
        role: m.role,
        content: m.content
      }));

      const res = await sendChatMessage(payloadMessages, language, selectedPersona, controller.signal);

      const botMsg: ChatMessage = {
        id: `msg-${Date.now()}-model`,
        role: 'model',
        content: res.response,
        timestamp: new Date().toISOString(),
        language: res.language
      };

      const finalSession: ChatSession = {
        ...updatedSession,
        messages: [...trimmed, botMsg],
        updatedAt: new Date().toISOString()
      };

      persistSession(finalSession);
    } catch (err: any) {
      if (err?.name === 'AbortError') return;
      setErrorMessage(err?.message || 'Regeneration failed. Please retry.');
      setRetryCooldown(5);
    } finally {
      setIsLoading(false);
      abortControllerRef.current = null;
    }
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const presetTopics = [
    {
      category: language === 'te' ? 'విద్య' : 'Education',
      prompt:
        language === 'te'
          ? 'కిరణజన్య సంయోగక్రియ (Photosynthesis) విధానాన్ని సులభమైన ఉదాహరణలతో వివరించు?'
          : 'Explain the principles of thermodynamics and entropy with a clean everyday analogy.'
    },
    {
      category: language === 'te' ? 'గణితం' : 'Mathematics',
      prompt:
        language === 'te'
          ? 'పైథాగరస్ సిద్ధాంతం (Pythagorean Theorem) మరియు దాని నిరూపణను వివరించు.'
          : 'Solve step-by-step: Find the roots of 2x^2 + 7x - 15 = 0 using the quadratic formula.'
    },
    {
      category: language === 'te' ? 'కోడింగ్' : 'Coding',
      prompt:
        language === 'te'
          ? 'జావాస్క్రిప్ట్‌లో క్లోజర్స్ (Closures) ఎలా పనిచేస్తాయో కోడ్ ఎగ్జాంపుల్‌తో చెప్పు.'
          : 'Write an idiomatic TypeScript debounce function with cancellation support and typing.'
    },
    {
      category: language === 'te' ? 'వ్యాపారం' : 'Business',
      prompt:
        language === 'te'
          ? 'ఇండియాలో AI టెక్నాలజీ ఆధారిత సర్వీస్ ఏజెన్సీ ప్రారంభించేందుకు రోడ్‌మ్యాప్ ఇవ్వండి.'
          : 'Outline a 5-step validation framework for a B2B SaaS startup before writing any code.'
    }
  ];

  return (
    <div className="flex h-[calc(100vh-4.1rem)] h-[calc(100dvh-4.1rem)] max-w-7xl mx-auto px-2 sm:px-4 py-2 sm:py-3 gap-3 relative">
      {/* Mobile Backdrop for Sidebar */}
      {sidebarOpen && (
        <div
          onClick={() => setSidebarOpen(false)}
          className="fixed inset-0 bg-black/70 backdrop-blur-xs z-30 lg:hidden cursor-pointer"
          aria-hidden="true"
        />
      )}

      {/* Sidebar for Chat History */}
      <aside
        className={`fixed inset-y-0 left-0 z-40 w-72 bg-neutral-950 border-r border-amber-500/20 p-4 transition-transform duration-200 lg:static lg:translate-x-0 lg:rounded-2xl lg:border lg:flex lg:flex-col ${
          sidebarOpen ? 'translate-x-0 shadow-2xl' : '-translate-x-full'
        }`}
      >
        <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
          <div className="flex items-center gap-2">
            <MessageSquare className="w-4 h-4 text-amber-400" />
            <h2 className="text-xs font-bold uppercase tracking-wider text-white">
              {language === 'te' ? 'చాట్ చరిత్ర' : 'Chat History'}
            </h2>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              onClick={initNewSession}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg gold-gradient-bg text-black text-xs font-bold hover:brightness-110 cursor-pointer shadow-sm shadow-amber-500/20"
              title="Start new conversation"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{language === 'te' ? 'కొత్తది' : 'New'}</span>
            </button>
            <button
              onClick={() => setSidebarOpen(false)}
              className="lg:hidden p-1.5 rounded-lg bg-neutral-900 text-neutral-400 hover:text-white cursor-pointer"
              title="Close sidebar"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Sessions list */}
        <div className="flex-1 overflow-y-auto mt-3 space-y-1.5 pr-1">
          {sessions.length === 0 ? (
            <p className="text-xs text-neutral-500 text-center py-6">
              {language === 'te' ? 'చరిత్ర ఏదీ లేదు' : 'No saved conversations'}
            </p>
          ) : (
            sessions.map(s => {
              const active = s.id === currentSessionId;
              return (
                <div
                  key={s.id}
                  onClick={() => {
                    setCurrentSessionId(s.id);
                    setSidebarOpen(false);
                  }}
                  className={`group flex items-center justify-between p-2.5 rounded-xl text-xs cursor-pointer transition-colors ${
                    active
                      ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                      : 'text-neutral-400 hover:bg-neutral-900 hover:text-neutral-200 border border-transparent'
                  }`}
                >
                  <span className="truncate flex-1 font-medium mr-2">
                    {s.title}
                  </span>
                  <button
                    onClick={e => handleDeleteSession(s.id, e)}
                    className="opacity-0 group-hover:opacity-100 p-1 text-neutral-500 hover:text-red-400 transition-opacity cursor-pointer"
                    title="Delete conversation"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              );
            })
          )}
        </div>

        {/* Sidebar Footer info */}
        <div className="pt-3 border-t border-neutral-900 flex items-center justify-between text-[11px] text-neutral-500">
          <span>{sessions.length} {sessions.length === 1 ? 'chat' : 'chats'}</span>
          <button
            onClick={initNewSession}
            className="text-amber-400/80 hover:text-amber-300 transition-colors cursor-pointer"
          >
            + New Chat
          </button>
        </div>
      </aside>

      {/* Main Chat Workspace */}
      <main className="flex-1 flex flex-col bg-[#0C0C10] border border-amber-500/20 rounded-2xl overflow-hidden shadow-2xl relative">
        {/* Chat Header Bar */}
        <div className="px-4 py-2.5 border-b border-amber-500/15 bg-neutral-950 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setSidebarOpen(true)}
              className="lg:hidden p-1.5 rounded-lg bg-neutral-900 border border-neutral-800 text-neutral-300 hover:text-white cursor-pointer"
              title="Open history sidebar"
            >
              <MessageSquare className="w-4 h-4" />
            </button>
            <div className="flex items-center gap-2">
              <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
              <h2 className="text-xs font-bold text-white tracking-wide truncate max-w-[150px] sm:max-w-xs">
                {currentSession?.title || 'TALKBOT AI'}
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Persona Selector */}
            <div className="hidden sm:flex items-center bg-neutral-900 border border-neutral-800 rounded-lg p-0.5 text-[11px]">
              <button
                onClick={() => setSelectedPersona('general')}
                className={`px-2 py-1 rounded transition-colors cursor-pointer ${
                  selectedPersona === 'general' ? 'bg-amber-500/20 text-amber-300 font-bold' : 'text-neutral-400 hover:text-neutral-200'
                }`}
              >
                General
              </button>
              <button
                onClick={() => setSelectedPersona('tutor')}
                className={`px-2 py-1 rounded transition-colors cursor-pointer ${
                  selectedPersona === 'tutor' ? 'bg-amber-500/20 text-amber-300 font-bold' : 'text-neutral-400 hover:text-neutral-200'
                }`}
              >
                Tutor
              </button>
              <button
                onClick={() => setSelectedPersona('coder')}
                className={`px-2 py-1 rounded transition-colors cursor-pointer ${
                  selectedPersona === 'coder' ? 'bg-amber-500/20 text-amber-300 font-bold' : 'text-neutral-400 hover:text-neutral-200'
                }`}
              >
                Coder
              </button>
              <button
                onClick={() => setSelectedPersona('business')}
                className={`px-2 py-1 rounded transition-colors cursor-pointer ${
                  selectedPersona === 'business' ? 'bg-amber-500/20 text-amber-300 font-bold' : 'text-neutral-400 hover:text-neutral-200'
                }`}
              >
                Business
              </button>
            </div>

            {/* Clear Conversation Button */}
            {currentSession && currentSession.messages.length > 0 && (
              <button
                onClick={handleClearConversation}
                className="flex items-center gap-1 px-2 py-1 rounded-lg bg-neutral-900 border border-neutral-800 text-neutral-400 hover:text-red-400 transition-colors text-xs cursor-pointer"
                title="Clear current messages"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span className="hidden md:inline">Clear</span>
              </button>
            )}

            {/* Language Toggle in Chat */}
            <button
              onClick={() => setLanguage(language === 'en' ? 'te' : 'en')}
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-neutral-900 border border-amber-500/30 text-amber-300 text-xs font-semibold hover:bg-neutral-800 cursor-pointer"
              title="Toggle Telugu / English"
            >
              <Globe className="w-3.5 h-3.5" />
              <span>{language === 'en' ? 'EN' : 'తెలుగు'}</span>
            </button>
          </div>
        </div>

        {/* Messages Scroll Area */}
        <div
          ref={messagesContainerRef}
          onScroll={handleContainerScroll}
          className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5"
        >
          {(!currentSession || currentSession.messages.length === 0) ? (
            <div className="h-full flex flex-col items-center justify-center text-center max-w-xl mx-auto py-8">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-400 via-amber-500 to-amber-700 text-black flex items-center justify-center mb-4 shadow-lg shadow-amber-500/20">
                <Sparkles className="w-7 h-7 text-black" />
              </div>
              <h3 className="text-2xl font-black text-white tracking-wide mb-1">
                TALKBOT AI
              </h3>
              <p className="text-xs uppercase tracking-widest text-amber-400 font-semibold mb-3">
                “Your World. One AI.”
              </p>
              <p className="text-xs text-neutral-400 mb-6 leading-relaxed max-w-md">
                {language === 'te'
                  ? 'గూగుల్ జెమిని ఆధారిత అధునాతన ఇంటెలిజెన్స్. మీ విద్య, కోడింగ్, రచన మరియు వ్యాపార సందేహాలను తెలుగు లేదా ఇంగ్లీషులో అడగండి.'
                  : 'Powered by official Google Gemini neural intelligence. Ask questions in science, mathematics, software architecture, and creative writing in English or Telugu.'}
              </p>

              {/* Preset prompt grid */}
              <div className="w-full grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-left">
                {presetTopics.map((item, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleSendMessage(item.prompt)}
                    className="p-3.5 rounded-xl bg-neutral-900/80 hover:bg-neutral-800/80 border border-neutral-800 hover:border-amber-500/30 transition-all text-xs cursor-pointer group shadow-sm"
                  >
                    <span className="text-[10px] font-bold text-amber-400 uppercase tracking-wider block mb-1">
                      {item.category}
                    </span>
                    <span className="text-neutral-300 group-hover:text-white line-clamp-2 leading-relaxed">
                      {item.prompt}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          ) : (
            currentSession.messages.map((msg, index) => {
              const isUser = msg.role === 'user';
              return (
                <div
                  key={msg.id || index}
                  className={`flex gap-3 sm:gap-4 ${
                    isUser ? 'justify-end' : 'justify-start'
                  } animate-in fade-in`}
                >
                  {!isUser && (
                    <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-500 to-amber-700 text-black flex items-center justify-center shrink-0 shadow-md">
                      <Bot className="w-4 h-4 text-black" />
                    </div>
                  )}

                  <div
                    className={`max-w-[85%] sm:max-w-[80%] rounded-2xl p-4 text-xs sm:text-sm leading-relaxed ${
                      isUser
                        ? 'bg-neutral-900 text-white border border-amber-500/30 shadow-md'
                        : 'bg-[#101015] border border-amber-500/20 text-neutral-200 shadow-sm'
                    }`}
                  >
                    {isUser ? (
                      <p className="whitespace-pre-wrap leading-relaxed">{msg.content}</p>
                    ) : (
                      <MarkdownView content={msg.content} />
                    )}

                    {!isUser && (
                      <div className="mt-3 pt-2.5 border-t border-neutral-800/80 flex items-center justify-between text-[11px] text-neutral-400">
                        <span className="text-[10px] text-neutral-500">
                          {msg.language === 'te' ? 'తెలుగు' : 'English'} · Google Gemini
                        </span>
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => copyToClipboard(msg.content, msg.id)}
                            className="flex items-center gap-1 text-neutral-400 hover:text-amber-300 transition-colors cursor-pointer"
                            title="Copy response"
                          >
                            {copiedId === msg.id ? (
                              <>
                                <Check className="w-3.5 h-3.5 text-emerald-400" />
                                <span className="text-emerald-400">Copied</span>
                              </>
                            ) : (
                              <>
                                <Copy className="w-3.5 h-3.5" />
                                <span>Copy</span>
                              </>
                            )}
                          </button>
                          {index === currentSession.messages.length - 1 && (
                            <button
                              onClick={handleRegenerate}
                              disabled={isLoading}
                              className="flex items-center gap-1 text-neutral-400 hover:text-amber-300 transition-colors disabled:opacity-40 cursor-pointer"
                              title="Regenerate this response"
                            >
                              <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
                              <span>Regenerate</span>
                            </button>
                          )}
                        </div>
                      </div>
                    )}
                  </div>

                  {isUser && (
                    <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-300 flex items-center justify-center shrink-0 border border-amber-500/30">
                      <User className="w-4 h-4" />
                    </div>
                  )}
                </div>
              );
            })
          )}

          {/* Loading / Thinking Indicator */}
          {isLoading && (
            <div className="flex gap-3 sm:gap-4 justify-start animate-in fade-in">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-500 to-amber-700 text-black flex items-center justify-center shrink-0">
                <Bot className="w-4 h-4 text-black animate-pulse" />
              </div>
              <div className="rounded-2xl p-4 bg-neutral-900 border border-amber-500/30 text-neutral-300 flex items-center gap-3">
                <div className="flex items-center gap-1.5">
                  <div className="w-2 h-2 rounded-full bg-amber-400 animate-bounce" style={{ animationDelay: '0ms' }} />
                  <div className="w-2 h-2 rounded-full bg-amber-400 animate-bounce" style={{ animationDelay: '150ms' }} />
                  <div className="w-2 h-2 rounded-full bg-amber-400 animate-bounce" style={{ animationDelay: '300ms' }} />
                </div>
                <span className="text-xs text-amber-300/90 font-medium">
                  {language === 'te'
                    ? 'TALKBOT AI ఆలోచిస్తోంది...'
                    : 'TALKBOT AI is synthesizing response with Gemini...'}
                </span>
              </div>
            </div>
          )}

          {/* Real Error Message Banner */}
          {errorMessage && (
            <div className="p-4 rounded-xl bg-red-950/40 border border-red-500/40 text-red-200 text-xs flex items-start gap-3">
              <AlertTriangle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="font-semibold text-red-300 mb-1">
                  Gemini API Execution Notice
                </p>
                <p className="text-neutral-300 leading-relaxed">{errorMessage}</p>
                <p className="mt-2 text-[11px] text-neutral-400">
                  TALKBOT AI uses server-side Google Gemini. We never output mocked or fake answers when the real API encounters rate limits.
                </p>
                <div className="mt-3 flex flex-wrap items-center gap-2">
                  <button
                    onClick={handleRetryLastMessage}
                    disabled={isLoading || retryCooldown > 0}
                    className="px-3.5 py-1.5 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 font-semibold text-xs transition-all disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer flex items-center gap-1.5"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
                    <span>
                      {isLoading
                        ? 'Retrying...'
                        : retryCooldown > 0
                        ? `Wait ${retryCooldown}s to retry`
                        : 'Retry Request'}
                    </span>
                  </button>

                  {failedPrompt && (
                    <button
                      onClick={handleRestoreFailedToInput}
                      className="px-3 py-1.5 rounded-lg bg-neutral-900 hover:bg-neutral-800 border border-neutral-700 text-neutral-300 text-xs transition-colors cursor-pointer flex items-center gap-1"
                      title="Edit this prompt in message box"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Edit Prompt</span>
                    </button>
                  )}

                  {retryCooldown > 0 && (
                    <span className="text-[11px] text-neutral-400">
                      Preventing rapid requests (cooling down)
                    </span>
                  )}
                </div>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Floating Scroll to Bottom Button */}
        {isUserScrolledUp && (
          <button
            onClick={() => scrollToBottom('smooth')}
            className="absolute bottom-24 right-6 p-2 rounded-full bg-neutral-900 border border-amber-500/40 text-amber-400 shadow-xl hover:scale-105 active:scale-95 transition-all cursor-pointer z-10"
            title="Scroll to latest message"
          >
            <ArrowDown className="w-4 h-4" />
          </button>
        )}

        {/* Smart ChatGPT-Style Message Composer */}
        <div className="p-3 sm:p-4 border-t border-neutral-800 bg-neutral-950">
          <form
            onSubmit={e => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="relative flex items-end gap-2 bg-neutral-900 border border-neutral-800 focus-within:border-amber-500/60 focus-within:ring-1 focus-within:ring-amber-500/50 rounded-2xl p-1.5 transition-all shadow-inner"
          >
            <textarea
              ref={textareaRef}
              rows={1}
              value={inputMessage}
              onChange={e => setInputMessage(e.target.value)}
              onKeyDown={e => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage();
                }
              }}
              placeholder={
                language === 'te'
                  ? 'మీ సందేహాన్ని ఇక్కడ రాయండి (తెలుగు లేదా English)... Enter to send'
                  : 'Message TALKBOT AI (Press Enter to send, Shift+Enter for new line)...'
              }
              className="flex-1 resize-none py-2 px-3 bg-transparent text-white placeholder-neutral-500 text-xs sm:text-sm outline-none transition-all max-h-40 overflow-y-auto leading-relaxed"
            />

            {/* Action Buttons: Stop Generation or Send */}
            <div className="flex items-center gap-1 self-end pb-1 pr-1">
              {isLoading ? (
                <button
                  type="button"
                  onClick={handleStopGeneration}
                  className="p-2 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold transition-all cursor-pointer shadow-md shadow-red-500/20 active:scale-95 flex items-center justify-center"
                  title="Stop generating"
                  aria-label="Stop generating"
                >
                  <Square className="w-4 h-4 fill-white" />
                </button>
              ) : (
                <button
                  type="submit"
                  disabled={!inputMessage.trim() || retryCooldown > 0}
                  className="p-2.5 rounded-xl gold-gradient-bg text-black font-bold disabled:opacity-30 disabled:cursor-not-allowed hover:brightness-110 active:scale-95 transition-all cursor-pointer shadow-md shadow-amber-500/20 flex items-center justify-center"
                  aria-label="Send message"
                >
                  <Send className="w-4 h-4" />
                </button>
              )}
            </div>
          </form>

          <div className="mt-2 flex items-center justify-between text-[10px] text-neutral-500 px-1">
            <span>
              {language === 'te' ? 'ఆటోమేటిక్ అనువాదం & తెలుగు మద్దతు' : 'Multilingual reasoning in Telugu & English'}
            </span>
            <span>TALKBOT AI · “Your World. One AI.”</span>
          </div>
        </div>
      </main>
    </div>
  );
};
