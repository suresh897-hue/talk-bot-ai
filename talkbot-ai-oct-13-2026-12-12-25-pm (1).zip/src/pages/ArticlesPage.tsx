import React, { useState, useEffect } from 'react';
import { Article, Language } from '../types';
import { getArticles } from '../services/api';
import { MarkdownView } from '../components/MarkdownView';
import { AdPlacement } from '../components/AdPlacement';
import { Search, BookOpen, Clock, Calendar, ArrowLeft, Share2, Check } from 'lucide-react';

interface ArticlesPageProps {
  language: Language;
}

export const ArticlesPage: React.FC<ArticlesPageProps> = ({ language }) => {
  const [articles, setArticles] = useState<Article[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [copiedLink, setCopiedLink] = useState(false);

  const categories = [
    'All',
    'AI & Machine Learning',
    'Web Development',
    'Software Engineering'
  ];

  useEffect(() => {
    fetchArticles();
  }, [selectedCategory]);

  const fetchArticles = async () => {
    setLoading(true);
    try {
      const res = await getArticles(selectedCategory === 'All' ? undefined : selectedCategory, searchQuery);
      setArticles(res.articles);
    } catch (err) {
      console.error('Failed to load articles', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchArticles();
  };

  const copyArticleLink = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  // Detailed Article Reading View
  if (selectedArticle) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8 space-y-6">
        <button
          onClick={() => {
            setSelectedArticle(null);
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-amber-400 hover:text-amber-300 transition-colors cursor-pointer py-1"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Articles</span>
        </button>

        <article className="rounded-2xl border border-amber-500/20 bg-neutral-950 p-6 sm:p-10 shadow-2xl space-y-6">
          {/* Metadata strictly following zero-pill discipline (no pills, unboxed with separators) */}
          <div className="flex flex-wrap items-center gap-2 text-xs text-neutral-400">
            <span className="font-semibold text-amber-400">{selectedArticle.category}</span>
            <span aria-hidden="true">·</span>
            <span>Published {selectedArticle.publishedAt}</span>
            <span aria-hidden="true">·</span>
            <span>{selectedArticle.readTime}</span>
            <span aria-hidden="true">·</span>
            <span>By {selectedArticle.authorRole}</span>
          </div>

          <h1 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight leading-snug">
            {selectedArticle.title}
          </h1>

          <p className="text-sm sm:text-base text-neutral-300 leading-relaxed italic border-l-2 border-amber-500/40 pl-4">
            {selectedArticle.description}
          </p>

          <div className="pt-6 border-t border-neutral-800 text-sm leading-relaxed text-neutral-200">
            <MarkdownView content={selectedArticle.content} />
          </div>

          {/* Tags list (clean unboxed text) */}
          <div className="pt-6 border-t border-neutral-800 flex flex-wrap items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-2 text-xs text-neutral-400">
              <span className="font-semibold text-neutral-300">Tags:</span>
              {selectedArticle.tags.map((tag, idx) => (
                <span key={idx}>
                  #{tag}
                  {idx < selectedArticle.tags.length - 1 && ' '}
                </span>
              ))}
            </div>

            <button
              onClick={copyArticleLink}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-xs text-neutral-300 cursor-pointer transition-colors"
            >
              {copiedLink ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400">Link Copied</span>
                </>
              ) : (
                <>
                  <Share2 className="w-3.5 h-3.5" />
                  <span>Share Article</span>
                </>
              )}
            </button>
          </div>
        </article>

        <AdPlacement slotId="article-bottom" format="horizontal" />
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs font-semibold">
          <BookOpen className="w-3.5 h-3.5" />
          <span>Knowledge & Technology Library</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white">
          Original Engineering & AI Articles
        </h1>
        <p className="text-xs sm:text-sm text-neutral-300 max-w-xl mx-auto leading-relaxed">
          Genuinely useful educational insights into modern LLM prompt engineering, Telugu Indic tokenization, and resilient full-stack systems.
        </p>
      </div>

      {/* Search and Category Filters */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-2">
        {/* Category Segmented Controls (interactive functional buttons) */}
        <div className="flex flex-wrap items-center gap-1.5 p-1 rounded-xl bg-neutral-900 border border-neutral-800">
          {categories.map(cat => {
            const active = selectedCategory === cat;
            return (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                  active
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                {cat}
              </button>
            );
          })}
        </div>

        {/* Search Input */}
        <form onSubmit={handleSearchSubmit} className="relative w-full sm:w-72">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search articles & topics..."
            className="w-full pl-9 pr-4 py-2 rounded-xl bg-neutral-900 border border-neutral-800 text-xs text-white placeholder-neutral-500 focus:border-amber-500/50 outline-none"
          />
        </form>
      </div>

      {/* Articles Grid */}
      {loading ? (
        <div className="py-16 text-center text-xs text-neutral-400">
          <div className="w-8 h-8 rounded-full border-2 border-amber-400 border-t-transparent animate-spin mx-auto mb-3" />
          <span>Loading knowledge articles...</span>
        </div>
      ) : articles.length === 0 ? (
        <div className="py-16 text-center text-xs text-neutral-500 border border-neutral-800 rounded-2xl bg-neutral-950">
          No articles found matching your query.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {articles.map(article => (
            <div
              key={article.id}
              onClick={() => {
                setSelectedArticle(article);
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="group p-6 rounded-2xl bg-neutral-950 border border-neutral-800 hover:border-amber-500/40 hover:bg-neutral-900/80 transition-all duration-200 cursor-pointer flex flex-col justify-between shadow-lg"
            >
              <div>
                {/* Zero-pill metadata */}
                <div className="flex items-center gap-2 text-[11px] text-neutral-400 mb-2.5">
                  <span className="font-semibold text-amber-400">{article.category}</span>
                  <span aria-hidden="true">·</span>
                  <span>{article.readTime}</span>
                </div>

                <h3 className="text-base font-bold text-white group-hover:text-amber-300 transition-colors line-clamp-2 leading-snug">
                  {article.title}
                </h3>

                <p className="mt-2 text-xs text-neutral-400 line-clamp-3 leading-relaxed">
                  {article.description}
                </p>
              </div>

              <div className="mt-5 pt-3 border-t border-neutral-800/80 flex items-center justify-between text-[11px] text-neutral-500 group-hover:text-amber-400">
                <span>{article.publishedAt}</span>
                <span className="font-semibold flex items-center gap-1">
                  Read article &rarr;
                </span>
              </div>
            </div>
          ))}
        </div>
      )}

      <AdPlacement slotId="articles-footer" format="horizontal" />
    </div>
  );
};
