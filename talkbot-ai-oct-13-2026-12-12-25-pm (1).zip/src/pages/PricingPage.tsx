import React, { useState, useEffect } from 'react';
import { Language, SubscriptionPlan, PhonePeConfig, SubscriptionPlanId } from '../types';
import { useAuth } from '../context/AuthContext';
import {
  getSubscriptionPlans,
  createSubscriptionOrder,
  submitPhonePePaymentProof,
  getMySubscription
} from '../services/api';
import { storeSubscriptionInFirebase } from '../services/firebase';
import {
  Check,
  Crown,
  Shield,
  Smartphone,
  Copy,
  CheckCircle,
  AlertTriangle,
  Clock,
  Sparkles,
  ArrowRight,
  RefreshCw,
  Lock,
  ExternalLink,
  Info
} from 'lucide-react';
import { AdPlacement } from '../components/AdPlacement';

interface PricingPageProps {
  language: Language;
  onSelectFree: () => void;
}

export const PricingPage: React.FC<PricingPageProps> = ({ language, onSelectFree }) => {
  const { user, token, openAuthModal } = useAuth();

  const [plans, setPlans] = useState<SubscriptionPlan[]>([
    {
      id: 'basic',
      name: 'Basic',
      nameTe: 'బేసిక్ ప్లాన్',
      price: 19,
      billingPeriod: '/month',
      daysDuration: 30,
      badge: 'Starter Choice',
      features: [
        'Full Access to TALKBOT AI Chat',
        'Fluent Telugu & English Bilingual Intelligence',
        'Google Gemini Neural Reasoning',
        '30 Days Unlocked Access',
        'Encrypted Private Chat History',
        'Single Device Access'
      ]
    },
    {
      id: 'starter',
      name: 'Starter',
      nameTe: 'స్టార్టర్ ప్లాన్',
      price: 39,
      billingPeriod: '/month',
      daysDuration: 30,
      badge: 'Student Favorite',
      features: [
        'Everything in Basic Plan',
        '4 Specialized AI Engines (Study, Code, Writing, Business)',
        'Extended Response Lengths',
        '30 Days Verified Access',
        'Clean Ad-Free Experience'
      ]
    },
    {
      id: 'pro',
      name: 'Pro',
      nameTe: 'ప్రో ప్లాన్',
      price: 59,
      billingPeriod: '/month',
      daysDuration: 30,
      popular: true,
      badge: 'Most Popular',
      features: [
        'Everything in Starter Plan',
        'All 8 Specialized AI Workstations Unlocked',
        'Fast Inference Routing & Priority Models',
        'Full Code Analysis & System Architecture',
        '30 Days Guaranteed Access'
      ]
    },
    {
      id: 'premium',
      name: 'Premium',
      nameTe: 'ప్రీమియం ప్లాన్',
      price: 79,
      billingPeriod: '/month',
      daysDuration: 30,
      badge: 'Power Creator',
      features: [
        'Everything in Pro Plan',
        'Executive Business & Startup Strategy Engines',
        'High-Priority Model Allocation',
        'Export Chats & Markdown Summaries',
        '30 Days Unlocked Access',
        'Priority Support Assistance'
      ]
    },
    {
      id: 'ultimate',
      name: 'Ultimate',
      nameTe: 'అల్టిమేట్ ప్లాన్',
      price: 99,
      billingPeriod: '/month',
      daysDuration: 30,
      badge: 'VIP Full Access',
      features: [
        'Complete VIP Suite Access',
        'Highest Priority Server Queuing',
        'All 8 AI Workstations + Early New Features',
        'Maximum Token Context Window Allocation',
        '30 Days Guaranteed Unlocked Access',
        'Direct Priority Engineering Routing'
      ]
    }
  ]);

  const [phonePeConfig, setPhonePeConfig] = useState<PhonePeConfig>({
    phonePeNumber: '9876543210',
    phonePeUpiId: 'talkbot@ybl',
    phonePeRecipientName: 'TALKBOT AI (Maaneesh)',
    merchantVerifiedMode: false
  });

  // Modal payment flow state
  const [selectedPlan, setSelectedPlan] = useState<SubscriptionPlan | null>(null);
  const [paymentModalOpen, setPaymentModalOpen] = useState(false);
  const [activeOrderId, setActiveOrderId] = useState<string | null>(null);
  const [transactionIdInput, setTransactionIdInput] = useState('');
  const [customerPhoneInput, setCustomerPhoneInput] = useState('');
  const [isSubmittingProof, setIsSubmittingProof] = useState(false);
  const [submissionSuccess, setSubmissionSuccess] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const [copiedNumber, setCopiedNumber] = useState(false);
  const [copiedUpi, setCopiedUpi] = useState(false);

  // User subscription status
  const [userSubscription, setUserSubscription] = useState<any>(user?.subscription || null);
  const [isLoadingStatus, setIsLoadingStatus] = useState(false);

  useEffect(() => {
    loadPlansAndConfig();
    if (token) {
      loadUserSubscription();
    }
  }, [token]);

  const loadPlansAndConfig = async () => {
    try {
      const data = await getSubscriptionPlans();
      if (data.plans && data.plans.length > 0) {
        setPlans(data.plans);
      }
      if (data.phonePeConfig) {
        setPhonePeConfig(data.phonePeConfig);
      }
    } catch (err) {
      console.warn('Failed to fetch live subscription plans, using verified defaults');
    }
  };

  const loadUserSubscription = async () => {
    if (!token) return;
    setIsLoadingStatus(true);
    try {
      const data = await getMySubscription(token);
      setUserSubscription(data.subscription);
    } catch (err) {
      console.warn('Could not load user subscription status', err);
    } finally {
      setIsLoadingStatus(false);
    }
  };

  const handleStartPayment = async (plan: SubscriptionPlan) => {
    if (!user || !token) {
      openAuthModal('login');
      return;
    }

    setSelectedPlan(plan);
    setErrorMessage(null);
    setSubmissionSuccess(null);
    setTransactionIdInput('');
    setPaymentModalOpen(true);

    try {
      const res = await createSubscriptionOrder(plan.id, token);
      setActiveOrderId(res.order.id);
      if (res.phonePeConfig) {
        setPhonePeConfig(res.phonePeConfig);
      }
    } catch (err: any) {
      setErrorMessage(err?.message || 'Failed to initiate order. Please try again.');
    }
  };

  const handleSubmitProof = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token || !activeOrderId || !transactionIdInput.trim()) return;

    if (transactionIdInput.trim().length < 6) {
      setErrorMessage('Please enter a valid PhonePe Transaction ID / UTR (at least 6 characters).');
      return;
    }

    setIsSubmittingProof(true);
    setErrorMessage(null);

    try {
      const res = await submitPhonePePaymentProof(
        activeOrderId,
        transactionIdInput.trim(),
        customerPhoneInput.trim(),
        token
      );

      // Securely store subscription in Firebase Firestore
      if (res.order) {
        await storeSubscriptionInFirebase(res.order);
      }

      setSubmissionSuccess(
        res.message ||
          'Payment submission received! Your subscription is pending verification against official PhonePe records. Access will be granted for 30 days once verified.'
      );
      loadUserSubscription();
    } catch (err: any) {
      setErrorMessage(err?.message || 'Failed to submit payment proof. Please verify and try again.');
    } finally {
      setIsSubmittingProof(false);
    }
  };

  const copyToClipboard = (text: string, type: 'number' | 'upi') => {
    navigator.clipboard.writeText(text);
    if (type === 'number') {
      setCopiedNumber(true);
      setTimeout(() => setCopiedNumber(false), 2000);
    } else {
      setCopiedUpi(true);
      setTimeout(() => setCopiedUpi(false), 2000);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-12">
      {/* Page Title & Exclusive PhonePe Header */}
      <div className="text-center max-w-3xl mx-auto space-y-3">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-semibold shadow-sm">
          <Smartphone className="w-3.5 h-3.5 text-amber-400" />
          <span>Exclusive Payment Partner: PhonePe (UPI)</span>
        </div>
        <h1 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight">
          TalkBot AI Subscription Plans
        </h1>
        <p className="text-xs sm:text-sm text-neutral-300 max-w-2xl mx-auto leading-relaxed">
          Unlock 30 days of verified, high-speed neural intelligence powered by Google Gemini.
          Payments accepted exclusively through PhonePe with zero transaction surcharges.
        </p>
      </div>

      {/* User Subscription Status Card (If Logged In) */}
      {user && (
        <div className="max-w-4xl mx-auto rounded-2xl border border-amber-500/30 bg-neutral-950 p-6 shadow-xl">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
                <Crown className="w-6 h-6" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs uppercase tracking-wider font-bold text-neutral-400">
                    Account Status:
                  </span>
                  {userSubscription?.status === 'active' && !userSubscription.isExpired ? (
                    <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-bold flex items-center gap-1">
                      <CheckCircle className="w-3 h-3" />
                      Active ({userSubscription.planName} · ₹{userSubscription.amount})
                    </span>
                  ) : userSubscription?.status === 'pending_verification' ? (
                    <span className="px-2.5 py-0.5 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-bold flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      Pending PhonePe Verification
                    </span>
                  ) : userSubscription?.status === 'expired' || userSubscription?.isExpired ? (
                    <span className="px-2.5 py-0.5 rounded-full bg-red-500/15 border border-red-500/30 text-red-300 text-xs font-bold flex items-center gap-1">
                      <Lock className="w-3 h-3" />
                      Expired
                    </span>
                  ) : (
                    <span className="px-2.5 py-0.5 rounded-full bg-neutral-800 text-neutral-300 text-xs font-medium">
                      Free Standard User
                    </span>
                  )}
                </div>

                {userSubscription?.status === 'active' && userSubscription.expiresAt && !userSubscription.isExpired && (
                  <p className="text-xs text-neutral-300 mt-1 flex items-center gap-2">
                    <span>
                      Expires on: <strong className="text-amber-300">{new Date(userSubscription.expiresAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</strong>
                    </span>
                    <span className="text-neutral-500">·</span>
                    <span className="text-emerald-400 font-semibold">
                      {userSubscription.daysRemaining} days remaining
                    </span>
                  </p>
                )}

                {userSubscription?.status === 'pending_verification' && (
                  <p className="text-xs text-amber-200/90 mt-1">
                    Your PhonePe Transaction ID ({userSubscription.phonePeTransactionId || 'submitted'}) is being verified by the administrator. 30 days will be unlocked upon verification.
                  </p>
                )}

                {(userSubscription?.isExpired || userSubscription?.status === 'expired') && (
                  <p className="text-xs text-red-300/90 mt-1">
                    Your 30-day subscription has expired. Premium features are locked until manually renewed.
                  </p>
                )}
              </div>
            </div>

            {/* Manual Renew / Refresh Button */}
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <button
                onClick={loadUserSubscription}
                title="Refresh Status"
                className="p-2.5 rounded-xl bg-neutral-900 border border-neutral-800 hover:border-amber-500/40 text-neutral-300 hover:text-white transition-all cursor-pointer"
              >
                <RefreshCw className={`w-4 h-4 ${isLoadingStatus ? 'animate-spin' : ''}`} />
              </button>
              {userSubscription?.status === 'active' && !userSubscription.isExpired && (
                <button
                  onClick={() => {
                    const currentPlan = plans.find(p => p.id === userSubscription.planId) || plans[2];
                    handleStartPayment(currentPlan);
                  }}
                  className="w-full sm:w-auto px-4 py-2 rounded-xl gold-gradient-bg text-black font-bold text-xs hover:brightness-110 active:scale-95 transition-all cursor-pointer shadow-md shadow-amber-500/20"
                >
                  Renew Plan (+30 Days)
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Official Administrator PhonePe Contact Notice */}
      <div className="max-w-4xl mx-auto rounded-2xl border border-amber-500/20 bg-gradient-to-r from-neutral-950 via-[#121217] to-neutral-950 p-6 flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-[#5f259f]/20 border border-[#5f259f]/40 flex items-center justify-center text-purple-300 shrink-0 shadow-lg">
            <Smartphone className="w-6 h-6 text-purple-400" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[11px] uppercase tracking-wider font-bold text-amber-400">
                Official PhonePe Details
              </span>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-950/80 border border-purple-500/30 text-purple-200">
                PhonePe Exclusive
              </span>
            </div>
            <h3 className="text-sm sm:text-base font-bold text-white mt-0.5">
              PhonePe Number: <span className="text-amber-300 font-mono text-base">{phonePeConfig.phonePeNumber}</span>
            </h3>
            <p className="text-xs text-neutral-400">
              UPI ID: <span className="text-neutral-200 font-mono">{phonePeConfig.phonePeUpiId}</span> · Recipient: <span className="text-neutral-200">{phonePeConfig.phonePeRecipientName}</span>
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => copyToClipboard(phonePeConfig.phonePeNumber, 'number')}
            className="px-3.5 py-2 rounded-xl bg-neutral-900 border border-amber-500/30 hover:border-amber-400 text-xs font-semibold text-neutral-200 hover:text-white flex items-center gap-1.5 transition-all cursor-pointer"
          >
            {copiedNumber ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-amber-400" />}
            <span>{copiedNumber ? 'Copied Number' : 'Copy Number'}</span>
          </button>
          <button
            onClick={() => copyToClipboard(phonePeConfig.phonePeUpiId, 'upi')}
            className="px-3.5 py-2 rounded-xl bg-neutral-900 border border-amber-500/30 hover:border-amber-400 text-xs font-semibold text-neutral-200 hover:text-white flex items-center gap-1.5 transition-all cursor-pointer"
          >
            {copiedUpi ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-amber-400" />}
            <span>{copiedUpi ? 'Copied UPI' : 'Copy UPI'}</span>
          </button>
        </div>
      </div>

      {/* Subscription Plans Grid (All 5 Plans) */}
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-5">
        {plans.map(plan => {
          const isCurrent = userSubscription?.planId === plan.id && userSubscription?.status === 'active' && !userSubscription?.isExpired;
          return (
            <div
              key={plan.id}
              className={`rounded-2xl flex flex-col justify-between p-6 transition-all duration-300 relative ${
                plan.popular
                  ? 'border-2 border-amber-500 bg-neutral-950 shadow-2xl shadow-amber-500/10 scale-100 lg:-translate-y-2'
                  : 'border border-neutral-800 bg-[#0C0C10] hover:border-amber-500/40'
              }`}
            >
              {/* Badge */}
              {plan.badge && (
                <div
                  className={`absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider ${
                    plan.popular
                      ? 'gold-gradient-bg text-black shadow-md shadow-amber-500/20'
                      : 'bg-neutral-800 text-neutral-300 border border-neutral-700'
                  }`}
                >
                  {plan.badge}
                </div>
              )}

              <div>
                <div className="mb-4">
                  <h3 className="text-lg font-bold text-white">{plan.name}</h3>
                  <p className="text-[11px] text-amber-400/80 font-medium">
                    {language === 'te' ? plan.nameTe : '30 Days Unlocked Access'}
                  </p>
                </div>

                <div className="flex items-baseline gap-1 mb-6">
                  <span className="text-3xl font-extrabold text-amber-400">₹{plan.price}</span>
                  <span className="text-xs text-neutral-400">/ 30 days</span>
                </div>

                <ul className="space-y-2.5 text-xs text-neutral-300 mb-6">
                  {plan.features.map((feat, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <Check className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                      <span className="leading-tight">{feat}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="pt-4 border-t border-neutral-900">
                <button
                  onClick={() => handleStartPayment(plan)}
                  className={`w-full py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-md ${
                    isCurrent
                      ? 'bg-emerald-600 text-white hover:bg-emerald-500'
                      : plan.popular
                      ? 'gold-gradient-bg text-black hover:brightness-110 shadow-amber-500/20'
                      : 'bg-neutral-800 text-neutral-200 hover:bg-neutral-700 hover:text-white'
                  }`}
                >
                  <Smartphone className="w-3.5 h-3.5" />
                  <span>
                    {isCurrent
                      ? 'Renew Plan (₹' + plan.price + ')'
                      : userSubscription?.status === 'active'
                      ? 'Switch to ' + plan.name + ' (₹' + plan.price + ')'
                      : 'Pay ₹' + plan.price + ' via PhonePe'}
                  </span>
                </button>
                <p className="text-[10px] text-center text-neutral-500 mt-2">
                  30 Days Access · PhonePe Only
                </p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Free Community Option Banner */}
      <div className="max-w-4xl mx-auto rounded-2xl border border-neutral-800 bg-[#0B0B0E] p-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
        <div>
          <h4 className="font-bold text-white text-sm">
            Prefer to start chatting right away without payment?
          </h4>
          <p className="text-xs text-neutral-400 mt-0.5">
            Our community chat powered by Google Gemini 3.8 Flash is completely accessible to students and creators.
          </p>
        </div>
        <button
          onClick={onSelectFree}
          className="px-5 py-2.5 rounded-xl bg-neutral-900 border border-neutral-700 hover:border-amber-400 text-xs font-semibold text-white transition-all cursor-pointer shrink-0"
        >
          Open Free Chat
        </button>
      </div>

      {/* Prominent Founder & CEO Leadership Card */}
      <div className="max-w-4xl mx-auto rounded-2xl border border-amber-500/30 bg-neutral-950 p-6 sm:p-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6 shadow-xl">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-amber-400 via-amber-500 to-amber-600 text-black flex items-center justify-center font-black text-xl shadow-lg shadow-amber-500/20 shrink-0">
            <Crown className="w-7 h-7" />
          </div>
          <div>
            <span className="text-[11px] font-bold uppercase tracking-widest text-amber-400">
              Founder & Leadership
            </span>
            <h2 className="text-xl font-extrabold text-white tracking-wide">
              MAANEESH
            </h2>
            <p className="text-xs text-amber-300 font-semibold mt-0.5">
              Founder & CEO — TalkBot AI
            </p>
          </div>
        </div>
        <div className="text-left sm:text-right border-t sm:border-t-0 sm:border-l border-neutral-800 pt-3 sm:pt-0 sm:pl-6 w-full sm:w-auto">
          <span className="font-bold text-sm tracking-wide text-white block">
            TALKBOT AI
          </span>
          <p className="text-xs text-amber-300/80 font-medium">
            “Your World. One AI.”
          </p>
        </div>
      </div>

      {/* Security & Verification Integrity Policy */}
      <div className="max-w-4xl mx-auto rounded-2xl border border-neutral-800 bg-neutral-950/80 p-6 space-y-4 text-xs text-neutral-400 leading-relaxed">
        <h4 className="font-bold text-white text-sm flex items-center gap-2">
          <Shield className="w-4 h-4 text-amber-400" />
          <span>Strict PhonePe Verification & Security Guarantees</span>
        </h4>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="p-4 rounded-xl bg-neutral-900/60 border border-neutral-800/80">
            <h5 className="font-bold text-neutral-200 mb-1 text-xs">Zero Fake Confirmations</h5>
            <p className="text-[11px]">
              We do not claim a payment succeeded until it has been verified against official PhonePe merchant records. Screenshots and verbal claims alone never grant access.
            </p>
          </div>
          <div className="p-4 rounded-xl bg-neutral-900/60 border border-neutral-800/80">
            <h5 className="font-bold text-neutral-200 mb-1 text-xs">Exact 30-Day Expiry</h5>
            <p className="text-[11px]">
              Access is unlocked for exactly 30 days upon verification. When the period ends, premium access is automatically locked with easy manual renewal.
            </p>
          </div>
          <div className="p-4 rounded-xl bg-neutral-900/60 border border-neutral-800/80">
            <h5 className="font-bold text-neutral-200 mb-1 text-xs">Secure Firebase Storage</h5>
            <p className="text-[11px]">
              Subscription orders and audit trails are securely synchronized with Google Firebase Firestore and protected backend databases.
            </p>
          </div>
        </div>
      </div>

      {/* Dedicated PhonePe Payment Modal */}
      {paymentModalOpen && selectedPlan && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="w-full max-w-lg rounded-2xl border border-amber-500/40 bg-[#0C0C10] p-6 sm:p-8 shadow-2xl space-y-6 max-h-[90vh] overflow-y-auto">
            {/* Modal Header */}
            <div className="flex items-start justify-between border-b border-neutral-800 pb-4">
              <div>
                <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-amber-500/10 text-amber-400 text-[11px] font-bold">
                  <Smartphone className="w-3.5 h-3.5" />
                  <span>PhonePe Payment Process</span>
                </div>
                <h3 className="text-xl font-bold text-white mt-1">
                  Subscribe to {selectedPlan.name} Plan
                </h3>
              </div>
              <button
                onClick={() => setPaymentModalOpen(false)}
                className="text-neutral-400 hover:text-white text-lg p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Selected Plan Summary & Exact Amount */}
            <div className="p-4 rounded-xl bg-neutral-950 border border-amber-500/30 flex items-center justify-between">
              <div>
                <span className="text-[11px] uppercase tracking-wider text-neutral-400 font-semibold block">
                  Selected Plan
                </span>
                <span className="text-base font-extrabold text-white">{selectedPlan.name}</span>
                <span className="text-xs text-neutral-400 ml-2">(30 Days Validity)</span>
              </div>
              <div className="text-right">
                <span className="text-[11px] uppercase tracking-wider text-neutral-400 font-semibold block">
                  Exact Amount to Pay
                </span>
                <span className="text-2xl font-black text-amber-400">₹{selectedPlan.price}</span>
              </div>
            </div>

            {/* Step-by-Step Payment Instructions */}
            <div className="space-y-3">
              <h4 className="text-xs uppercase tracking-wider font-bold text-neutral-300">
                Payment Instructions:
              </h4>

              <div className="p-4 rounded-xl bg-neutral-900/80 border border-neutral-800 space-y-3 text-xs">
                <div className="flex items-center justify-between py-1 border-b border-neutral-800/60">
                  <span className="text-neutral-400">PhonePe Number:</span>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-amber-300 font-bold">{phonePeConfig.phonePeNumber}</span>
                    <button
                      type="button"
                      onClick={() => copyToClipboard(phonePeConfig.phonePeNumber, 'number')}
                      className="p-1 hover:text-amber-400 text-neutral-400 cursor-pointer"
                      title="Copy Number"
                    >
                      {copiedNumber ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>

                <div className="flex items-center justify-between py-1 border-b border-neutral-800/60">
                  <span className="text-neutral-400">PhonePe UPI ID:</span>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-neutral-200 font-semibold">{phonePeConfig.phonePeUpiId}</span>
                    <button
                      type="button"
                      onClick={() => copyToClipboard(phonePeConfig.phonePeUpiId, 'upi')}
                      className="p-1 hover:text-amber-400 text-neutral-400 cursor-pointer"
                      title="Copy UPI"
                    >
                      {copiedUpi ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>

                <div className="flex items-center justify-between py-1">
                  <span className="text-neutral-400">Recipient Name:</span>
                  <span className="text-neutral-200 font-medium">{phonePeConfig.phonePeRecipientName}</span>
                </div>
              </div>

              <ol className="text-xs text-neutral-400 space-y-1.5 list-decimal list-inside bg-neutral-950/60 p-3 rounded-xl border border-neutral-900">
                <li>Open the <strong>PhonePe app</strong> on your mobile phone.</li>
                <li>Send exactly <strong>₹{selectedPlan.price}</strong> to PhonePe Number <strong>{phonePeConfig.phonePeNumber}</strong>.</li>
                <li>Note the <strong>12-digit Transaction ID / UTR number</strong> from your PhonePe transaction screen.</li>
                <li>Enter the Transaction ID below and submit for verification.</li>
              </ol>
            </div>

            {/* Error / Success Notifications */}
            {errorMessage && (
              <div className="p-3.5 rounded-xl bg-red-950/50 border border-red-500/40 text-red-200 text-xs flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
                <span>{errorMessage}</span>
              </div>
            )}

            {submissionSuccess ? (
              <div className="p-4 rounded-xl bg-emerald-950/50 border border-emerald-500/40 text-emerald-200 text-xs space-y-2">
                <div className="flex items-center gap-2 font-bold text-emerald-300">
                  <CheckCircle className="w-4 h-4" />
                  <span>Submission Received Successfully</span>
                </div>
                <p className="leading-relaxed">{submissionSuccess}</p>
                <div className="pt-2 flex justify-end">
                  <button
                    onClick={() => {
                      setPaymentModalOpen(false);
                      setSubmissionSuccess(null);
                    }}
                    className="px-4 py-2 rounded-xl gold-gradient-bg text-black font-bold text-xs cursor-pointer"
                  >
                    Done
                  </button>
                </div>
              </div>
            ) : (
              /* Transaction ID Submission Form */
              <form onSubmit={handleSubmitProof} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
                    PhonePe Transaction ID / UTR Number <span className="text-amber-400">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={transactionIdInput}
                    onChange={e => setTransactionIdInput(e.target.value)}
                    placeholder="e.g. 429381749201 or T2408..."
                    className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-900 border border-neutral-700 text-white font-mono text-xs focus:border-amber-400 focus:outline-none"
                  />
                  <p className="text-[11px] text-neutral-500 mt-1">
                    Found in PhonePe under "Transaction Details" → "UTR / Transaction ID".
                  </p>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
                    Your PhonePe Mobile Number (Optional)
                  </label>
                  <input
                    type="tel"
                    value={customerPhoneInput}
                    onChange={e => setCustomerPhoneInput(e.target.value)}
                    placeholder="e.g. 9876543210"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-900 border border-neutral-700 text-white text-xs focus:border-amber-400 focus:outline-none"
                  />
                </div>

                <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-[11px] text-amber-200/90 leading-relaxed">
                  <strong className="text-amber-300">Security Rule:</strong> Access is not activated on screenshot alone. Your 30 days will be activated upon administrator verification against PhonePe records.
                </div>

                <div className="flex items-center justify-end gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setPaymentModalOpen(false)}
                    className="px-4 py-2.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-neutral-300 text-xs font-semibold cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmittingProof || !transactionIdInput.trim()}
                    className="px-5 py-2.5 rounded-xl gold-gradient-bg text-black font-bold text-xs flex items-center gap-1.5 hover:brightness-110 active:scale-95 transition-all cursor-pointer disabled:opacity-50"
                  >
                    {isSubmittingProof ? (
                      <>
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        <span>Submitting Proof...</span>
                      </>
                    ) : (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>Submit for Verification</span>
                      </>
                    )}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* AdPlacement banner */}
      <AdPlacement slot="pricing-bottom-banner" format="horizontal" />
    </div>
  );
};
