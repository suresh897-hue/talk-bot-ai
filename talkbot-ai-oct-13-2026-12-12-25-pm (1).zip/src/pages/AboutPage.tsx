import React from 'react';
import { Language } from '../types';
import { Sparkles, Globe, Shield, Layers, Crown } from 'lucide-react';
import { AdPlacement } from '../components/AdPlacement';

interface AboutPageProps {
  language: Language;
}

export const AboutPage: React.FC<AboutPageProps> = ({ language }) => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-10 space-y-12">
      {/* Hero */}
      <div className="text-center space-y-4">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs font-semibold">
          <Sparkles className="w-3.5 h-3.5" />
          <span>The Philosophy Behind TALKBOT AI</span>
        </div>
        <h1 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight">
          Your World. One AI.
        </h1>
        <p className="text-sm sm:text-base text-neutral-300 max-w-2xl mx-auto leading-relaxed">
          TALKBOT AI was founded on a simple conviction: cutting-edge artificial intelligence must be accessible, genuinely useful, and naturally bilingual across Indian and global languages.
        </p>
      </div>

      {/* Founder & CEO Leadership Card */}
      <div className="rounded-2xl border border-amber-500/30 bg-neutral-950 p-6 sm:p-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6 shadow-xl">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-amber-400 via-amber-500 to-amber-600 text-black flex items-center justify-center font-black text-xl shadow-lg shadow-amber-500/20 shrink-0">
            <Crown className="w-7 h-7" />
          </div>
          <div>
            <span className="text-[11px] font-bold uppercase tracking-widest text-amber-400">
              Founder & Leadership
            </span>
            <h2 className="text-xl font-extrabold text-white tracking-wide">
              MAANEESH
            </h2>
            <p className="text-xs text-amber-300 font-semibold mt-0.5">
              Founder & CEO — TalkBot AI
            </p>
          </div>
        </div>
        <div className="text-left sm:text-right border-t sm:border-t-0 sm:border-l border-neutral-800 pt-3 sm:pt-0 sm:pl-6 w-full sm:w-auto">
          <span className="font-bold text-sm tracking-wide text-white block">
            TALKBOT AI
          </span>
          <p className="text-xs text-amber-300/80 font-medium">
            “Your World. One AI.”
          </p>
        </div>
      </div>

      {/* Main Narrative */}
      <div className="rounded-2xl border border-amber-500/20 bg-neutral-950 p-6 sm:p-10 shadow-2xl space-y-8 text-neutral-300 text-xs sm:text-sm leading-relaxed">
        <div className="space-y-3">
          <h3 className="text-lg sm:text-xl font-bold text-white flex items-center gap-2">
            <Globe className="w-5 h-5 text-amber-400" />
            <span>Bridging the Linguistic Divide: English & Telugu (తెలుగు)</span>
          </h3>
          <p>
            While many AI platforms treat regional languages as an afterthought, TALKBOT AI places Indic linguistic precision at the center of its experience. By tuning system directives and prompt pipelines specifically for Telugu alongside English, students, scholars, and professionals can query complex mathematics, science, and coding in their native mother tongue without losing nuance or accuracy.
          </p>
        </div>

        <div className="space-y-3">
          <h3 className="text-lg sm:text-xl font-bold text-white flex items-center gap-2">
            <Layers className="w-5 h-5 text-amber-400" />
            <span>Zero-Pretense Architecture</span>
          </h3>
          <p>
            We do not mock AI responses. We do not invent fake testimonials, fake user numbers, or bogus billing claims. Every single answer in our 8 specialized workstations and main chat is generated live through Google's official Gemini 3.8 Flash API.
          </p>
        </div>

        <div className="space-y-3">
          <h3 className="text-lg sm:text-xl font-bold text-white flex items-center gap-2">
            <Shield className="w-5 h-5 text-amber-400" />
            <span>Strict Server-Side Credential Isolation</span>
          </h3>
          <p>
            User privacy and security are hard system requirements. All API keys remain isolated on our protected backend server, completely invisible to client web browsers. User accounts employ salted SHA-512 PBKDF2 hashing, ensuring your private chat sessions remain strictly confidential.
          </p>
        </div>
      </div>

      {/* Values Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 text-center">
        <div className="p-5 rounded-2xl bg-neutral-900/60 border border-neutral-800">
          <h4 className="font-bold text-white text-sm mb-1 text-amber-300">₹0 Budget Frugality</h4>
          <p className="text-xs text-neutral-400">
            Engineered efficiently to deliver maximum utility on generous free tiers without vendor debt.
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-neutral-900/60 border border-neutral-800">
          <h4 className="font-bold text-white text-sm mb-1 text-amber-300">Human-Centric UX</h4>
          <p className="text-xs text-neutral-400">
            Clean typography, zero-pill discipline, smooth animations, and responsive dark/light styling.
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-neutral-900/60 border border-neutral-800">
          <h4 className="font-bold text-white text-sm mb-1 text-amber-300">Truth in Engineering</h4>
          <p className="text-xs text-neutral-400">
            Real error notifications, real AI streams, and transparent technical boundaries.
          </p>
        </div>
      </div>

      <AdPlacement slotId="about-bottom" format="horizontal" />
    </div>
  );
};
