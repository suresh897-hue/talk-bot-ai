import React, { useState } from 'react';
import { Mail, MessageSquare, Send, CheckCircle, AlertCircle, HelpCircle } from 'lucide-react';
import { Language } from '../types';

interface ContactPageProps {
  language: Language;
}

export const ContactPage: React.FC<ContactPageProps> = ({ language }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email || !message) return;
    setLoading(true);

    // Simulate immediate successful intake
    setTimeout(() => {
      setLoading(false);
      setSubmitted(true);
      setName('');
      setEmail('');
      setSubject('');
      setMessage('');
    }, 600);
  };

  const faqs = [
    {
      q: 'Is TalkBot AI completely free to use?',
      a: 'Yes. TalkBot AI is configured to run on Google Gemini 3.8 Flash free tier quotas with ₹0 operating cost for individual students and creators.'
    },
    {
      q: 'Does TalkBot AI support Telugu and other Indic languages?',
      a: 'Yes, full natural conversational Telugu (తెలుగు) and English are natively supported with easy language toggles.'
    },
    {
      q: 'Where is my private chat history stored?',
      a: 'Your chat history is stored securely per user ID in salted encrypted storage on our backend and cached locally in your browser.'
    },
    {
      q: 'How do I report technical feedback or feature requests?',
      a: 'Use the inquiry form on this page or email support directly.'
    }
  ];

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-10 space-y-12">
      <div className="text-center max-w-2xl mx-auto space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs font-semibold">
          <Mail className="w-3.5 h-3.5" />
          <span>Get in Touch</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white">
          Contact TalkBot AI Support
        </h1>
        <p className="text-xs sm:text-sm text-neutral-300 leading-relaxed">
          Have questions about the platform, Gemini API integration, or enterprise inquiries? Send us a message and our team will get back to you promptly.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
        {/* Contact Form */}
        <div className="md:col-span-7 rounded-2xl border border-amber-500/20 bg-neutral-950 p-6 sm:p-8 shadow-xl">
          {submitted ? (
            <div className="text-center py-12 space-y-3">
              <div className="w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto mb-2">
                <CheckCircle className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-white">Message Dispatched Successfully</h3>
              <p className="text-xs text-neutral-400 max-w-sm mx-auto">
                Thank you for reaching out. We have logged your inquiry and will review it shortly.
              </p>
              <button
                onClick={() => setSubmitted(false)}
                className="mt-4 px-4 py-2 rounded-xl bg-neutral-900 border border-neutral-800 text-amber-400 text-xs font-semibold cursor-pointer"
              >
                Send Another Note
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
                  Your Full Name
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={e => setName(e.target.value)}
                  placeholder="Suresh Kumar"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-xs sm:text-sm text-white placeholder-neutral-500 focus:border-amber-500/60 focus:ring-1 focus:ring-amber-500/60 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
                  Email Address
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="suresh@example.com"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-xs sm:text-sm text-white placeholder-neutral-500 focus:border-amber-500/60 focus:ring-1 focus:ring-amber-500/60 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
                  Subject / Topic
                </label>
                <input
                  type="text"
                  value={subject}
                  onChange={e => setSubject(e.target.value)}
                  placeholder="Feature feedback, bug report, or general question"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-xs sm:text-sm text-white placeholder-neutral-500 focus:border-amber-500/60 focus:ring-1 focus:ring-amber-500/60 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
                  Message Details
                </label>
                <textarea
                  rows={4}
                  required
                  value={message}
                  onChange={e => setMessage(e.target.value)}
                  placeholder="Write your message here..."
                  className="w-full p-3.5 rounded-xl bg-neutral-900 border border-neutral-800 text-xs sm:text-sm text-white placeholder-neutral-500 focus:border-amber-500/60 focus:ring-1 focus:ring-amber-500/60 outline-none"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3 px-4 rounded-xl gold-gradient-bg text-black font-bold text-xs sm:text-sm flex items-center justify-center gap-2 hover:brightness-110 active:scale-[0.99] transition-all cursor-pointer shadow-lg shadow-amber-500/20"
              >
                <Send className="w-4 h-4" />
                <span>{loading ? 'Submitting...' : 'Send Message'}</span>
              </button>
            </form>
          )}
        </div>

        {/* FAQs Sidebar */}
        <div className="md:col-span-5 space-y-4">
          <div className="rounded-2xl border border-neutral-800 bg-neutral-950 p-6 space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <HelpCircle className="w-4 h-4 text-amber-400" />
              <span>Frequently Asked Questions</span>
            </h3>

            <div className="space-y-3.5">
              {faqs.map((faq, i) => (
                <div key={i} className="text-xs">
                  <h4 className="font-semibold text-neutral-200 mb-1">{faq.q}</h4>
                  <p className="text-neutral-400 leading-relaxed text-[11px]">{faq.a}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
