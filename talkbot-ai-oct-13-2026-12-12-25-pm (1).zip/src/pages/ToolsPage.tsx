import React, { useState, useEffect } from 'react';
import { executeTool } from '../services/api';
import { Language, ToolId } from '../types';
import { useAuth } from '../context/AuthContext';
import { MarkdownView } from '../components/MarkdownView';
import { AdPlacement } from '../components/AdPlacement';
import {
  GraduationCap,
  Sparkles,
  Code,
  Briefcase,
  Mail,
  Share2,
  Layout,
  UserCheck,
  Send,
  Copy,
  Check,
  RefreshCw,
  AlertTriangle,
  Globe,
  Lock,
  Crown,
  CheckCircle2
} from 'lucide-react';

interface ToolsPageProps {
  language: Language;
  setLanguage: (lang: Language) => void;
  defaultToolId?: ToolId;
}

export const ToolsPage: React.FC<ToolsPageProps> = ({
  language,
  setLanguage,
  defaultToolId = 'study'
}) => {
  const { user } = useAuth();
  const [activeTool, setActiveTool] = useState<ToolId>(defaultToolId);
  const [prompt, setPrompt] = useState('');
  const [subInputs, setSubInputs] = useState<Record<string, string>>({});
  const [result, setResult] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [retryCooldown, setRetryCooldown] = useState(0);

  useEffect(() => {
    if (retryCooldown <= 0) return;
    const interval = setInterval(() => {
      setRetryCooldown(prev => {
        if (prev <= 1) {
          clearInterval(interval);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [retryCooldown]);

  useEffect(() => {
    if (defaultToolId) {
      setActiveTool(defaultToolId);
    }
  }, [defaultToolId]);

  // Reset inputs when tool changes
  useEffect(() => {
    setPrompt('');
    setSubInputs({});
    setResult(null);
    setError(null);
  }, [activeTool]);

  const toolsMeta = [
    {
      id: 'study' as ToolId,
      name: 'Study Assistant',
      nameTe: 'స్టడీ అసిస్టెంట్',
      icon: GraduationCap,
      description: 'Break down complex topics, generate flashcards, solve mathematics, and prepare for academic tests.',
      placeholder: language === 'te'
        ? 'ఉదాహరణ: న్యూటన్ మూడో నియమం లేదా డీఎన్ఏ రెప్లికేషన్ గురించి వివరించండి...'
        : 'e.g., Explain Photosynthesis, prove the quadratic formula, or prepare a 5-question quiz on World War II...',
      fields: [
        { key: 'level', label: 'Academic Level', options: ['High School', 'Undergraduate', 'Postgraduate', 'General Curiosity'] },
        { key: 'goal', label: 'Study Objective', options: ['Concept Breakdown', 'Flashcards & Summary', 'Exam Practice Problems', 'Memory Mnemonics'] }
      ]
    },
    {
      id: 'writing' as ToolId,
      name: 'Writing Assistant',
      nameTe: 'రైటింగ్ అసిస్టెంట్',
      icon: Sparkles,
      description: 'Compose high-impact essays, articles, stories, and critique grammar with nuanced tone control.',
      placeholder: language === 'te'
        ? 'ఉదాహరణ: కృత్రిమ మేధస్సు భవిష్యత్తు గురించి 500 పదాల ఆలోచనాత్మక వ్యాసం...'
        : 'e.g., Draft an op-ed on renewable energy transition, or refine this article draft with an engaging hook...',
      fields: [
        { key: 'tone', label: 'Tone', options: ['Persuasive & Formal', 'Engaging & Conversational', 'Academic', 'Creative Narrative'] },
        { key: 'length', label: 'Length Target', options: ['Short (200 words)', 'Medium (500 words)', 'Comprehensive (1000 words)'] }
      ]
    },
    {
      id: 'coding' as ToolId,
      name: 'Coding Assistant',
      nameTe: 'కోడింగ్ అసిస్టెంట్',
      icon: Code,
      description: 'Write production-ready code, troubleshoot runtime bugs, refactor architecture, and design algorithms.',
      placeholder: language === 'te'
        ? 'ఉదాహరణ: రియాక్ట్ మరియు నోడ్.జెస్‌లో రెస్ట్‌ఫుల్ ఏపీఐ కోసం కోడ్ రాయండి...'
        : 'e.g., Implement a rate-limiter middleware in Express, or debug a React useEffect memory leak...',
      fields: [
        { key: 'language', label: 'Programming Language', options: ['TypeScript / JavaScript', 'Python', 'Go', 'Rust', 'Java', 'C++', 'SQL'] },
        { key: 'task', label: 'Task Type', options: ['Write New Code', 'Debug & Fix Error', 'Code Review & Refactor', 'Explain Algorithm'] }
      ]
    },
    {
      id: 'business' as ToolId,
      name: 'Business Ideas Assistant',
      nameTe: 'బిజినెస్ ఐడియాస్',
      icon: Briefcase,
      description: 'Formulate viable commercial ideas, revenue models, target personas, and go-to-market strategies.',
      placeholder: language === 'te'
        ? 'ఉదాహరణ: తక్కువ పెట్టుబడితో స్థానిక సేవల కోసం ఏఐ స్టార్టప్ ప్రణాళిక...'
        : 'e.g., Brainstorm 3 SaaS business models for remote engineering teams with high margins and low churn...',
      fields: [
        { key: 'industry', label: 'Industry Sector', options: ['AI & Tech', 'Education / EdTech', 'E-commerce', 'Health & Wellness', 'Fintech'] },
        { key: 'budget', label: 'Initial Capital', options: ['₹0 Bootstrapped', 'Under ₹50,000', 'Seed Funded', 'Enterprise Capital'] }
      ]
    },
    {
      id: 'email' as ToolId,
      name: 'Email & Letter Writer',
      nameTe: 'ఈమెయిల్ & లెటర్ రైటర్',
      icon: Mail,
      description: 'Draft executive business emails, job application cover letters, formal notices, and client outreach.',
      placeholder: language === 'te'
        ? 'ఉదాహరణ: జీతం పెంపు కోసం లేదా ప్రాజెక్ట్ గడువు పొడిగింపు కోసం అధికారిక ఈమెయిల్...'
        : 'e.g., Write a confident follow-up email to a prospective enterprise client after a product demo...',
      fields: [
        { key: 'type', label: 'Correspondence Type', options: ['Professional Job Application', 'Client Proposal', 'Executive Update', 'Polite Inquiry'] },
        { key: 'formality', label: 'Formality', options: ['Strictly Formal', 'Warm Professional', 'Direct & Concise'] }
      ]
    },
    {
      id: 'social' as ToolId,
      name: 'Social Media Caption Generator',
      nameTe: 'సోషల్ మీడియా క్యాప్షన్స్',
      icon: Share2,
      description: 'Generate 3 high-converting viral captions, audience engagement hooks, and curated hashtags.',
      placeholder: language === 'te'
        ? 'ఉదాహరణ: కొత్త కోడింగ్ బూట్‌క్యాంప్ ప్రారంభం గురించి ఆకర్షణీయమైన ఇన్‌స్టాగ్రామ్ క్యాప్షన్...'
        : 'e.g., Launching a minimalist productivity mobile app on Product Hunt this Thursday...',
      fields: [
        { key: 'platform', label: 'Primary Platform', options: ['LinkedIn', 'Twitter / X', 'Instagram', 'YouTube Community'] },
        { key: 'goal', label: 'Goal', options: ['Viral Engagement', 'Lead Generation & Click', 'Storytelling', 'Announcement'] }
      ]
    },
    {
      id: 'website' as ToolId,
      name: 'Website Planning Assistant',
      nameTe: 'వెబ్‌సైట్ ప్లానింగ్',
      icon: Layout,
      description: 'Architect complete website blueprints: sitemaps, conversion layouts, tech stack, and SEO checklists.',
      placeholder: language === 'te'
        ? 'ఉదాహరణ: స్థానిక రెస్టారెంట్ లేదా టెక్ కన్సల్టెన్సీ కోసం వెబ్‌సైట్ లేఅవుట్...'
        : 'e.g., Plan a portfolio and client acquisition website for an independent software architect...',
      fields: [
        { key: 'siteType', label: 'Website Type', options: ['SaaS Landing Page', 'E-commerce Store', 'Agency / Portfolio', 'Content / Blog Platform'] },
        { key: 'audience', label: 'Target Audience', options: ['B2B Professionals', 'Consumers (B2C)', 'Developers / Tech', 'Local Community'] }
      ]
    },
    {
      id: 'interview' as ToolId,
      name: 'Interview Practice Coach',
      nameTe: 'ఇంటర్వ్యూ ప్రాక్టీస్',
      icon: UserCheck,
      description: 'Simulate realistic behavioral and technical interview questions using the STAR framework.',
      placeholder: language === 'te'
        ? 'ఉదాహరణ: సీనియర్ ఫుల్‌స్టాక్ డెవలపర్ లేదా ప్రోడక్ట్ మేనేజర్ ఇంటర్వ్యూ ప్రశ్నలు...'
        : 'e.g., Simulate behavioral questions for an Engineering Manager position at a high-growth startup...',
      fields: [
        { key: 'role', label: 'Target Role', options: ['Software Engineer', 'Product Manager', 'Data Analyst', 'Business Development'] },
        { key: 'format', label: 'Practice Mode', options: ['Mock Questions & Sample Answers', 'STAR Story Critique', 'Technical System Design'] }
      ]
    }
  ];

  const currentToolMeta = toolsMeta.find(t => t.id === activeTool) || toolsMeta[0];

  const handleExecute = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim() || isLoading) return;

    setIsLoading(true);
    setError(null);
    setResult(null);

    try {
      const res = await executeTool(activeTool, prompt, language, subInputs);
      setResult(res.result);
    } catch (err: any) {
      console.error('Tool execution error:', err);
      setError(err?.message || 'Tool execution failed. Please verify API key.');
      setRetryCooldown(5);
    } finally {
      setIsLoading(false);
    }
  };

  const copyResult = () => {
    if (!result) return;
    navigator.clipboard.writeText(result);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-amber-500/15">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-bold uppercase tracking-wider text-amber-400">
              TalkBot AI Suite
            </span>
            <span aria-hidden="true" className="text-neutral-600">·</span>
            <span className="text-xs text-neutral-400">8 Dedicated Engines</span>
          </div>
          <h1 className="text-3xl font-extrabold text-white">
            Specialized AI Workstations
          </h1>
          <p className="text-xs sm:text-sm text-neutral-300 mt-1 max-w-2xl">
            Direct access to Google Gemini 3.8 Flash engines tuned for education, engineering, writing, and commercial strategy.
          </p>
        </div>

        {/* Language selector */}
        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            onClick={() => setLanguage(language === 'en' ? 'te' : 'en')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-neutral-900 border border-amber-500/30 text-amber-300 text-xs font-semibold hover:bg-neutral-800 transition-colors cursor-pointer"
          >
            <Globe className="w-3.5 h-3.5" />
            <span>Output in: {language === 'en' ? 'English' : 'తెలుగు (Telugu)'}</span>
          </button>
        </div>
      </div>

      {/* Tool Selector Tabs */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2">
        {toolsMeta.map(tool => {
          const Icon = tool.icon;
          const isActive = activeTool === tool.id;
          return (
            <button
              key={tool.id}
              onClick={() => setActiveTool(tool.id)}
              className={`p-3 rounded-xl flex flex-col items-center text-center transition-all cursor-pointer ${
                isActive
                  ? 'bg-amber-500/15 border-2 border-amber-500 text-amber-300 shadow-md shadow-amber-500/10'
                  : 'bg-neutral-900/70 border border-neutral-800 hover:border-amber-500/30 text-neutral-300 hover:text-white'
              }`}
            >
              <Icon className={`w-5 h-5 mb-1.5 ${isActive ? 'text-amber-400' : 'text-neutral-400'}`} />
              <span className="text-xs font-bold truncate w-full">
                {language === 'te' ? tool.nameTe : tool.name}
              </span>
            </button>
          );
        })}
      </div>

      {/* Active Tool Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Input Configuration Column */}
        <div className="lg:col-span-5 space-y-4">
          <div className="p-5 sm:p-6 rounded-2xl bg-neutral-950 border border-amber-500/20 shadow-xl space-y-5">
            <div>
              <div className="flex items-center gap-2 text-amber-400 mb-1">
                <currentToolMeta.icon className="w-5 h-5" />
                <h2 className="text-lg font-bold text-white">
                  {language === 'te' ? currentToolMeta.nameTe : currentToolMeta.name}
                </h2>
              </div>
              <p className="text-xs text-neutral-400 leading-relaxed">
                {currentToolMeta.description}
              </p>
            </div>

            {/* Subscription Status or Expiry Alert */}
            {user?.subscription && (
              <div>
                {user.subscription.status === 'active' && !user.subscription.isExpired && (
                  <div className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-emerald-200 text-xs flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <Crown className="w-4 h-4 text-emerald-400 shrink-0" />
                      <span>
                        <strong>{user.subscription.planName} Plan</strong> · {user.subscription.daysRemaining} days left
                      </span>
                    </div>
                    {user.subscription.expiresAt && (
                      <span className="text-[10px] text-neutral-400">
                        Expires: {new Date(user.subscription.expiresAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}
                      </span>
                    )}
                  </div>
                )}

                {(user.subscription.status === 'expired' || user.subscription.isExpired) && (
                  <div className="p-3.5 rounded-xl bg-red-950/40 border border-red-500/30 text-red-200 text-xs flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2">
                      <Lock className="w-4 h-4 text-red-400 shrink-0" />
                      <span>
                        Subscription Expired ({user.subscription.expiresAt ? new Date(user.subscription.expiresAt).toLocaleDateString('en-IN') : 'End of 30 days'}).
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        window.dispatchEvent(new CustomEvent('talkbot-navigate', { detail: 'pricing' }));
                      }}
                      className="px-2.5 py-1 rounded-lg gold-gradient-bg text-black font-bold text-[11px] shrink-0 cursor-pointer shadow"
                    >
                      Renew Plan
                    </button>
                  </div>
                )}

                {user.subscription.status === 'pending_verification' && (
                  <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-200 text-xs flex items-center gap-2">
                    <Crown className="w-4 h-4 text-amber-400 shrink-0" />
                    <span>
                      PhonePe Payment Verification in progress. 30 days access will unlock upon admin confirmation.
                    </span>
                  </div>
                )}
              </div>
            )}

            <form onSubmit={handleExecute} className="space-y-4">
              {/* Dynamic tool options */}
              {currentToolMeta.fields?.map(field => (
                <div key={field.key}>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
                    {field.label}
                  </label>
                  <select
                    value={subInputs[field.key] || field.options[0]}
                    onChange={e =>
                      setSubInputs(prev => ({ ...prev, [field.key]: e.target.value }))
                    }
                    className="w-full py-2 px-3 rounded-xl bg-neutral-900 border border-neutral-800 text-xs text-white focus:border-amber-500/60 focus:ring-1 focus:ring-amber-500/60 outline-none cursor-pointer"
                  >
                    {field.options.map(opt => (
                      <option key={opt} value={opt} className="bg-neutral-900 text-white">
                        {opt}
                      </option>
                    ))}
                  </select>
                </div>
              ))}

              {/* Main Prompt Input */}
              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
                  Detailed Prompt / Topic / Task
                </label>
                <textarea
                  rows={5}
                  required
                  value={prompt}
                  onChange={e => setPrompt(e.target.value)}
                  placeholder={currentToolMeta.placeholder}
                  className="w-full p-3 rounded-xl bg-neutral-900 border border-neutral-800 focus:border-amber-500/60 focus:ring-1 focus:ring-amber-500/60 text-xs sm:text-sm text-white placeholder-neutral-500 outline-none leading-relaxed"
                />
              </div>

              <button
                type="submit"
                disabled={isLoading || !prompt.trim() || retryCooldown > 0}
                className="w-full py-3 px-4 rounded-xl gold-gradient-bg text-black font-bold text-xs sm:text-sm flex items-center justify-center gap-2 hover:brightness-110 active:scale-[0.99] disabled:opacity-50 disabled:cursor-not-allowed transition-all cursor-pointer shadow-lg shadow-amber-500/20"
              >
                {isLoading ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Synthesizing with Gemini...</span>
                  </>
                ) : retryCooldown > 0 ? (
                  <span>Wait {retryCooldown}s before retrying</span>
                ) : (
                  <>
                    <Send className="w-4 h-4" />
                    <span>Generate Result</span>
                  </>
                )}
              </button>
            </form>
          </div>

          <AdPlacement slotId="tools-sidebar" format="sidebar" />
        </div>

        {/* Result Column */}
        <div className="lg:col-span-7 flex flex-col">
          <div className="flex-1 p-5 sm:p-6 rounded-2xl bg-[#0C0C10] border border-amber-500/20 shadow-xl flex flex-col min-h-[450px]">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800 mb-4">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-amber-400" />
                <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-200">
                  Generated Output
                </h3>
              </div>

              {result && (
                <div className="flex items-center gap-2">
                  <button
                    onClick={copyResult}
                    className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-xs text-neutral-300 hover:text-white transition-colors cursor-pointer"
                    title="Copy full output"
                  >
                    {copied ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-emerald-400">Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy</span>
                      </>
                    )}
                  </button>
                  <button
                    onClick={handleExecute}
                    disabled={isLoading}
                    className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-xs text-neutral-300 hover:text-white cursor-pointer"
                    title="Regenerate"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
                    <span>Regenerate</span>
                  </button>
                </div>
              )}
            </div>

            {/* Error Message */}
            {error && (
              <div className="p-4 rounded-xl bg-red-950/40 border border-red-500/40 text-red-200 text-xs flex items-start gap-3 my-auto">
                <AlertTriangle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                <div className="flex-1">
                  <p className="font-bold text-red-300">Tool Execution Notice</p>
                  <p className="text-neutral-300 mt-0.5">{error}</p>
                  <div className="mt-3 flex items-center gap-2">
                    <button
                      onClick={handleExecute}
                      disabled={isLoading || retryCooldown > 0}
                      className="px-3.5 py-1.5 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 font-semibold text-xs transition-all disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer flex items-center gap-1.5"
                    >
                      <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
                      <span>
                        {isLoading
                          ? 'Retrying...'
                          : retryCooldown > 0
                          ? `Wait ${retryCooldown}s to retry`
                          : 'Retry Tool'}
                      </span>
                    </button>
                    {retryCooldown > 0 && (
                      <span className="text-[11px] text-neutral-400">
                        Cooling down to prevent rapid requests
                      </span>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* Empty State */}
            {!result && !isLoading && !error && (
              <div className="flex-1 flex flex-col items-center justify-center text-center p-8 my-auto">
                <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center mb-3">
                  <Sparkles className="w-6 h-6" />
                </div>
                <h4 className="text-sm font-bold text-white mb-1">
                  Ready to Process
                </h4>
                <p className="text-xs text-neutral-400 max-w-sm leading-relaxed">
                  Configure your parameters on the left and click "Generate Result". Output is powered directly by Google Gemini 3.8 Flash.
                </p>
              </div>
            )}

            {/* Loading Indicator */}
            {isLoading && (
              <div className="flex-1 flex flex-col items-center justify-center text-center p-8 my-auto">
                <div className="w-10 h-10 rounded-full border-2 border-amber-400 border-t-transparent animate-spin mb-4" />
                <p className="text-xs font-semibold text-amber-300">
                  {language === 'te'
                    ? 'గూగుల్ జెమినితో ప్రాసెస్ చేస్తోంది...'
                    : 'Running neural inference via Gemini 3.8 Flash...'}
                </p>
                <p className="text-[11px] text-neutral-500 mt-1">
                  Constructing domain-specific architecture and citations.
                </p>
              </div>
            )}

            {/* Result View */}
            {result && !isLoading && (
              <div className="flex-1 overflow-y-auto pr-1 text-xs sm:text-sm text-neutral-200 leading-relaxed">
                <MarkdownView content={result} />
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
