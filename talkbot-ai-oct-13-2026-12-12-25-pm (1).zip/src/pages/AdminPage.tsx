import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { Article, SiteSettings, SubscriptionOrder } from '../types';
import {
  getArticles,
  saveArticle,
  updateArticle,
  deleteArticle,
  getAdminSettings,
  updateAdminSettings,
  checkHealth,
  getAdminSubscriptions,
  verifySubscriptionOrder,
  rejectSubscriptionOrder,
  deleteSubscriptionOrder
} from '../services/api';
import {
  ShieldAlert,
  Settings,
  BookOpen,
  Plus,
  Trash2,
  Edit,
  Save,
  CheckCircle,
  AlertTriangle,
  Users,
  Cpu,
  Layers,
  Lock,
  Smartphone,
  CheckCheck,
  XCircle,
  Clock,
  Crown,
  CreditCard,
  ExternalLink,
  ShieldCheck,
  RefreshCw
} from 'lucide-react';

export const AdminPage: React.FC = () => {
  const { user, token, isAdmin, openAuthModal } = useAuth();

  const [activeTab, setActiveTab] = useState<'subscriptions' | 'articles' | 'settings'>('subscriptions');
  const [articles, setArticles] = useState<Article[]>([]);
  const [subscriptions, setSubscriptions] = useState<SubscriptionOrder[]>([]);
  const [settings, setSettings] = useState<SiteSettings | null>(null);
  const [stats, setStats] = useState<{ totalUsers: number; totalArticles: number; adminEmail: string } | null>(null);
  const [healthStatus, setHealthStatus] = useState<any>(null);

  const [isLoading, setIsLoading] = useState(true);
  const [saveSuccess, setSaveSuccess] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Subscriptions filter
  const [subFilter, setSubFilter] = useState<'all' | 'pending' | 'active' | 'expired' | 'rejected'>('all');

  // Article creation/editing modal state
  const [editingArticle, setEditingArticle] = useState<Partial<Article> | null>(null);
  const [isNewArticle, setIsNewArticle] = useState(false);

  useEffect(() => {
    if (!token || !isAdmin) {
      setIsLoading(false);
      return;
    }

    loadAdminData();
  }, [token, isAdmin]);

  const loadAdminData = async () => {
    if (!token) return;
    setIsLoading(true);
    setError(null);
    try {
      const [articlesRes, adminRes, health, subsRes] = await Promise.all([
        getArticles(),
        getAdminSettings(token),
        checkHealth(),
        getAdminSubscriptions(token).catch(() => ({ subscriptions: [] }))
      ]);
      setArticles(articlesRes.articles);
      setSettings(adminRes.settings);
      setSubscriptions((subsRes as any).subscriptions || []);
      setStats({
        totalUsers: adminRes.totalUsers,
        totalArticles: adminRes.totalArticles,
        adminEmail: adminRes.adminEmail
      });
      setHealthStatus(health);
    } catch (err: any) {
      setError(err?.message || 'Failed to fetch admin data. Check credentials.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerifySubscription = async (id: string) => {
    if (!token) return;
    try {
      const res = await verifySubscriptionOrder(id, token);
      setSaveSuccess(res.message || 'Subscription verified successfully. 30 days of access granted.');
      loadAdminData();
      setTimeout(() => setSaveSuccess(null), 3500);
    } catch (err: any) {
      setError(err?.message || 'Failed to verify subscription.');
    }
  };

  const handleRejectSubscription = async (id: string) => {
    if (!token) return;
    const notes = prompt('Enter rejection reason (e.g. Transaction ID not found in PhonePe records):') || 'Transaction ID not verified';
    try {
      const res = await rejectSubscriptionOrder(id, notes, token);
      setSaveSuccess(res.message || 'Subscription marked as rejected.');
      loadAdminData();
      setTimeout(() => setSaveSuccess(null), 3500);
    } catch (err: any) {
      setError(err?.message || 'Failed to reject subscription.');
    }
  };

  const handleDeleteSubscription = async (id: string) => {
    if (!token || !confirm('Are you sure you want to delete this subscription record?')) return;
    try {
      await deleteSubscriptionOrder(id, token);
      setSaveSuccess('Subscription record deleted.');
      loadAdminData();
      setTimeout(() => setSaveSuccess(null), 3000);
    } catch (err: any) {
      setError(err?.message || 'Failed to delete subscription.');
    }
  };

  const handleSaveArticle = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token || !editingArticle) return;
    try {
      if (isNewArticle) {
        await saveArticle(editingArticle, token);
        setSaveSuccess('Article published successfully.');
      } else if (editingArticle.id) {
        await updateArticle(editingArticle.id, editingArticle, token);
        setSaveSuccess('Article updated successfully.');
      }
      setEditingArticle(null);
      setIsNewArticle(false);
      loadAdminData();
      setTimeout(() => setSaveSuccess(null), 3000);
    } catch (err: any) {
      setError(err?.message || 'Failed to save article.');
    }
  };

  const handleDeleteArticle = async (id: string) => {
    if (!token || !confirm('Are you sure you want to delete this article?')) return;
    try {
      await deleteArticle(id, token);
      setSaveSuccess('Article deleted.');
      loadAdminData();
      setTimeout(() => setSaveSuccess(null), 3000);
    } catch (err: any) {
      setError(err?.message || 'Failed to delete article.');
    }
  };

  const handleUpdateSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token || !settings) return;
    try {
      await updateAdminSettings(settings, token);
      setSaveSuccess('Site settings & PhonePe parameters updated successfully.');
      setTimeout(() => setSaveSuccess(null), 3000);
    } catch (err: any) {
      setError(err?.message || 'Failed to update settings.');
    }
  };

  if (!isAdmin) {
    return (
      <div className="max-w-md mx-auto px-4 py-20 text-center space-y-4">
        <div className="w-16 h-16 rounded-full bg-red-950/40 border border-red-500/30 text-red-400 flex items-center justify-center mx-auto">
          <Lock className="w-8 h-8" />
        </div>
        <h1 className="text-2xl font-bold text-white">Administrator Access Required</h1>
        <p className="text-xs text-neutral-400 leading-relaxed">
          The Admin Console is strictly restricted to verified system administrators (configured for authorized administrator suresh897@gmail.com). Public signups cannot grant administrative access.
        </p>
        <button
          onClick={() => openAuthModal('login')}
          className="mt-4 px-6 py-2.5 rounded-xl gold-gradient-bg text-black font-bold text-xs cursor-pointer shadow-lg shadow-amber-500/20"
        >
          Sign In with Admin Account
        </button>
      </div>
    );
  }

  const pendingCount = subscriptions.filter(s => s.status === 'pending_verification').length;
  const activeSubsCount = subscriptions.filter(s => s.status === 'active').length;

  const filteredSubscriptions = subscriptions.filter(s => {
    if (subFilter === 'pending') return s.status === 'pending_verification';
    if (subFilter === 'active') return s.status === 'active';
    if (subFilter === 'expired') return s.status === 'expired';
    if (subFilter === 'rejected') return s.status === 'rejected';
    return true;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-amber-500/20">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[11px] font-bold uppercase tracking-wider text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
              Verified Administrator
            </span>
            <span className="text-xs text-neutral-400">{user?.email}</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
            TalkBot AI Administration & Subscriptions
          </h1>
        </div>

        {/* Tab switcher */}
        <div className="flex items-center p-1 rounded-xl bg-neutral-900 border border-neutral-800">
          <button
            onClick={() => setActiveTab('subscriptions')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
              activeTab === 'subscriptions'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>PhonePe Subscriptions</span>
            {pendingCount > 0 && (
              <span className="ml-1 px-1.5 py-0.2 rounded-full bg-amber-500 text-black text-[10px] font-extrabold">
                {pendingCount}
              </span>
            )}
          </button>
          <button
            onClick={() => setActiveTab('articles')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
              activeTab === 'articles'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>Articles</span>
          </button>
          <button
            onClick={() => setActiveTab('settings')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
              activeTab === 'settings'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <Settings className="w-3.5 h-3.5" />
            <span>PhonePe & Site Settings</span>
          </button>
        </div>
      </div>

      {/* Notifications */}
      {saveSuccess && (
        <div className="flex items-center gap-2 p-3 rounded-xl bg-emerald-950/40 border border-emerald-500/40 text-emerald-200 text-xs">
          <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{saveSuccess}</span>
        </div>
      )}

      {error && (
        <div className="flex items-center gap-2 p-3 rounded-xl bg-red-950/40 border border-red-500/40 text-red-200 text-xs">
          <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800">
          <div className="flex items-center justify-between text-neutral-400 mb-2">
            <span className="text-xs font-semibold">Active Subscriptions</span>
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
          </div>
          <p className="text-lg font-bold text-white">{activeSubsCount}</p>
          <p className="text-[10px] text-neutral-500 mt-1">30 Days Verified Access</p>
        </div>

        <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800">
          <div className="flex items-center justify-between text-neutral-400 mb-2">
            <span className="text-xs font-semibold">Pending Verifications</span>
            <Clock className="w-4 h-4 text-amber-400" />
          </div>
          <p className="text-lg font-bold text-amber-400">{pendingCount}</p>
          <p className="text-[10px] text-neutral-500 mt-1">Requires Admin PhonePe Check</p>
        </div>

        <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800">
          <div className="flex items-center justify-between text-neutral-400 mb-2">
            <span className="text-xs font-semibold">Registered Users</span>
            <Users className="w-4 h-4 text-amber-400" />
          </div>
          <p className="text-lg font-bold text-white">{stats?.totalUsers || 1}</p>
          <p className="text-[10px] text-neutral-500 mt-1">PBKDF2 SHA-512 Encrypted</p>
        </div>

        <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800">
          <div className="flex items-center justify-between text-neutral-400 mb-2">
            <span className="text-xs font-semibold">Gemini AI Status</span>
            <Cpu className="w-4 h-4 text-amber-400" />
          </div>
          <p className="text-lg font-bold text-emerald-400">Connected & Live</p>
          <p className="text-[10px] text-neutral-500 mt-1">Primary: gemini-3.1-flash-lite</p>
        </div>
      </div>

      {/* Tab 1: PhonePe Subscriptions Management */}
      {activeTab === 'subscriptions' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-lg font-bold text-white">PhonePe Subscription Orders & Verifications</h2>
              <p className="text-xs text-neutral-400 mt-0.5">
                Review submitted PhonePe transaction IDs, cross-reference against your PhonePe Business account, and grant 30 days of access.
              </p>
            </div>

            {/* Filter buttons */}
            <div className="flex items-center gap-1.5 p-1 rounded-xl bg-neutral-900 border border-neutral-800 text-xs">
              {(['all', 'pending', 'active', 'expired', 'rejected'] as const).map(filter => (
                <button
                  key={filter}
                  onClick={() => setSubFilter(filter)}
                  className={`px-2.5 py-1 rounded-lg capitalize font-medium cursor-pointer ${
                    subFilter === filter
                      ? 'bg-amber-500 text-black font-bold'
                      : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  {filter}
                </button>
              ))}
            </div>
          </div>

          {/* Security Notice on Verification */}
          <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/30 text-xs text-amber-200/90 flex items-start gap-3">
            <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <strong className="text-amber-300">Verification Protocol:</strong>
              <p>
                1. Open your <strong>PhonePe Merchant / Business app</strong>.<br />
                2. Check the transaction list for the incoming amount (₹19, ₹39, ₹59, ₹79, or ₹99) and match the 12-digit UTR.<br />
                3. Click <strong>"Verify & Grant 30 Days"</strong> only when the payment is confirmed. Access is strictly granted for exactly 30 days and automatically expires thereafter.
              </p>
            </div>
          </div>

          {/* Subscriptions Table */}
          <div className="rounded-2xl border border-neutral-800 bg-neutral-950 overflow-hidden shadow-xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-neutral-900/80 text-neutral-400 border-b border-neutral-800 uppercase text-[10px] tracking-wider">
                  <tr>
                    <th className="py-3 px-4">Customer</th>
                    <th className="py-3 px-4">Plan & Amount</th>
                    <th className="py-3 px-4">PhonePe UTR / Tx ID</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4">Submitted Date</th>
                    <th className="py-3 px-4">Expiry Date</th>
                    <th className="py-3 px-4 text-right">Verification Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-900 text-neutral-300">
                  {filteredSubscriptions.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="py-8 text-center text-neutral-500">
                        No subscription orders found in this category.
                      </td>
                    </tr>
                  ) : (
                    filteredSubscriptions.map(sub => {
                      const isPending = sub.status === 'pending_verification';
                      const isActive = sub.status === 'active';
                      return (
                        <tr key={sub.id} className="hover:bg-neutral-900/40 transition-colors">
                          <td className="py-3.5 px-4">
                            <span className="font-semibold text-white block">{sub.userName || 'Customer'}</span>
                            <span className="text-[11px] text-neutral-400">{sub.userEmail}</span>
                            {sub.customerPhone && (
                              <span className="text-[10px] text-amber-400/80 block font-mono">
                                Ph: {sub.customerPhone}
                              </span>
                            )}
                          </td>
                          <td className="py-3.5 px-4">
                            <span className="font-bold text-amber-400 block">{sub.planName}</span>
                            <span className="font-bold text-white text-sm">₹{sub.amount}</span>
                            <span className="text-[10px] text-neutral-500 block">30 days</span>
                          </td>
                          <td className="py-3.5 px-4 font-mono">
                            <span className="bg-neutral-900 px-2 py-1 rounded border border-neutral-800 text-amber-300 select-all font-bold">
                              {sub.phonePeTransactionId || 'Awaiting Input'}
                            </span>
                          </td>
                          <td className="py-3.5 px-4">
                            {isPending ? (
                              <span className="px-2 py-0.5 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 font-bold text-[10px] inline-flex items-center gap-1">
                                <Clock className="w-3 h-3" />
                                Pending Check
                              </span>
                            ) : isActive ? (
                              <span className="px-2 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 font-bold text-[10px] inline-flex items-center gap-1">
                                <CheckCheck className="w-3 h-3" />
                                Active (30d)
                              </span>
                            ) : sub.status === 'expired' ? (
                              <span className="px-2 py-0.5 rounded-full bg-neutral-800 text-neutral-400 font-semibold text-[10px]">
                                Expired
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 rounded-full bg-red-500/15 border border-red-500/30 text-red-300 font-semibold text-[10px]">
                                Rejected
                              </span>
                            )}
                          </td>
                          <td className="py-3.5 px-4 text-neutral-400 text-[11px]">
                            {new Date(sub.createdAt).toLocaleDateString('en-IN', {
                              day: 'numeric',
                              month: 'short',
                              year: 'numeric'
                            })}
                          </td>
                          <td className="py-3.5 px-4 text-[11px]">
                            {sub.expiresAt ? (
                              <span className="text-emerald-300 font-semibold">
                                {new Date(sub.expiresAt).toLocaleDateString('en-IN', {
                                  day: 'numeric',
                                  month: 'short',
                                  year: 'numeric'
                                })}
                              </span>
                            ) : (
                              <span className="text-neutral-500">—</span>
                            )}
                          </td>
                          <td className="py-3.5 px-4 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              {isPending && (
                                <>
                                  <button
                                    onClick={() => handleVerifySubscription(sub.id)}
                                    className="px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] flex items-center gap-1 cursor-pointer shadow"
                                    title="Verify & Unlock 30 Days"
                                  >
                                    <CheckCheck className="w-3.5 h-3.5" />
                                    <span>Verify (30 Days)</span>
                                  </button>
                                  <button
                                    onClick={() => handleRejectSubscription(sub.id)}
                                    className="px-2.5 py-1.5 rounded-lg bg-red-950/80 border border-red-800 text-red-300 hover:bg-red-900 font-semibold text-[11px] cursor-pointer"
                                    title="Reject invalid transaction"
                                  >
                                    Reject
                                  </button>
                                </>
                              )}
                              <button
                                onClick={() => handleDeleteSubscription(sub.id)}
                                className="p-1.5 rounded-lg text-neutral-500 hover:text-red-400 hover:bg-neutral-900 cursor-pointer"
                                title="Delete Order"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Articles Management */}
      {activeTab === 'articles' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-bold text-white">Articles & Educational Content</h2>
              <p className="text-xs text-neutral-400">
                Publish and manage guides and articles across Technology and Engineering.
              </p>
            </div>
            <button
              onClick={() => {
                setEditingArticle({
                  title: '',
                  category: 'Technology',
                  description: '',
                  content: '',
                  readTime: '5 min read',
                  tags: ['AI', 'Tech']
                });
                setIsNewArticle(true);
              }}
              className="px-3.5 py-2 rounded-xl gold-gradient-bg text-black font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-md shadow-amber-500/20"
            >
              <Plus className="w-4 h-4" />
              <span>Create Article</span>
            </button>
          </div>

          {/* Article Modal */}
          {editingArticle && (
            <div className="p-6 rounded-2xl bg-neutral-900 border border-amber-500/40 space-y-4">
              <h3 className="font-bold text-white text-base">
                {isNewArticle ? 'Create New Article' : 'Edit Article'}
              </h3>
              <form onSubmit={handleSaveArticle} className="space-y-4 text-xs">
                <div>
                  <label className="block text-neutral-300 font-semibold mb-1">Title</label>
                  <input
                    type="text"
                    required
                    value={editingArticle.title || ''}
                    onChange={e => setEditingArticle({ ...editingArticle, title: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-neutral-950 border border-neutral-800 text-white outline-none focus:border-amber-500/50"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-neutral-300 font-semibold mb-1">Category</label>
                    <input
                      type="text"
                      value={editingArticle.category || 'Technology'}
                      onChange={e => setEditingArticle({ ...editingArticle, category: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl bg-neutral-950 border border-neutral-800 text-white outline-none focus:border-amber-500/50"
                    />
                  </div>
                  <div>
                    <label className="block text-neutral-300 font-semibold mb-1">Read Time</label>
                    <input
                      type="text"
                      value={editingArticle.readTime || '5 min read'}
                      onChange={e => setEditingArticle({ ...editingArticle, readTime: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl bg-neutral-950 border border-neutral-800 text-white outline-none focus:border-amber-500/50"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-neutral-300 font-semibold mb-1">Summary Description</label>
                  <textarea
                    rows={2}
                    value={editingArticle.description || ''}
                    onChange={e => setEditingArticle({ ...editingArticle, description: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-neutral-950 border border-neutral-800 text-white outline-none focus:border-amber-500/50"
                  />
                </div>

                <div>
                  <label className="block text-neutral-300 font-semibold mb-1">Markdown Content</label>
                  <textarea
                    rows={8}
                    required
                    value={editingArticle.content || ''}
                    onChange={e => setEditingArticle({ ...editingArticle, content: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-neutral-950 border border-neutral-800 text-white font-mono text-xs outline-none focus:border-amber-500/50"
                  />
                </div>

                <div className="flex items-center justify-end gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setEditingArticle(null)}
                    className="px-4 py-2 rounded-xl bg-neutral-800 text-neutral-300 font-semibold cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-xl gold-gradient-bg text-black font-bold flex items-center gap-1.5 cursor-pointer shadow-md shadow-amber-500/20"
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>{isNewArticle ? 'Publish' : 'Update'}</span>
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* Articles Table */}
          <div className="rounded-2xl border border-neutral-800 bg-neutral-950 overflow-hidden shadow-xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-neutral-900/80 text-neutral-400 border-b border-neutral-800 uppercase text-[10px] tracking-wider">
                  <tr>
                    <th className="py-3 px-4">Title</th>
                    <th className="py-3 px-4">Category</th>
                    <th className="py-3 px-4">Date</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-900 text-neutral-300">
                  {articles.map(art => (
                    <tr key={art.id} className="hover:bg-neutral-900/40 transition-colors">
                      <td className="py-3.5 px-4 font-semibold text-white max-w-xs truncate">
                        {art.title}
                      </td>
                      <td className="py-3.5 px-4 text-neutral-400">{art.category}</td>
                      <td className="py-3.5 px-4 text-neutral-500">{art.publishedAt}</td>
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => {
                              setEditingArticle(art);
                              setIsNewArticle(false);
                            }}
                            className="p-1.5 rounded-lg text-neutral-400 hover:text-amber-400 hover:bg-neutral-900 cursor-pointer"
                            title="Edit Article"
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDeleteArticle(art.id)}
                            className="p-1.5 rounded-lg text-neutral-400 hover:text-red-400 hover:bg-neutral-900 cursor-pointer"
                            title="Delete Article"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Settings & PhonePe Configuration */}
      {activeTab === 'settings' && settings && (
        <div className="rounded-2xl border border-neutral-800 bg-neutral-950 p-6 sm:p-8 space-y-6">
          <div>
            <h2 className="text-lg font-bold text-white mb-1">PhonePe Payment & Site Configuration</h2>
            <p className="text-xs text-neutral-400">
              Configure your official PhonePe contact number, UPI receiver identity, and automated verification setup.
            </p>
          </div>

          <form onSubmit={handleUpdateSettings} className="space-y-6 text-xs">
            {/* PhonePe Administrator Payment Parameters */}
            <div className="p-5 rounded-2xl bg-[#5f259f]/10 border border-[#5f259f]/30 space-y-4">
              <div className="flex items-center gap-2 text-purple-300 font-bold text-sm">
                <Smartphone className="w-4 h-4" />
                <span>PhonePe Administrator Contact Settings</span>
              </div>
              <p className="text-neutral-400 text-[11px]">
                Customers will be directed to make PhonePe transfers strictly to this contact number and UPI handle.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-neutral-300 font-semibold mb-1">
                    PhonePe Mobile Number <span className="text-amber-400">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={settings.phonePeNumber || ''}
                    onChange={e => setSettings({ ...settings, phonePeNumber: e.target.value })}
                    placeholder="9876543210"
                    className="w-full px-3 py-2.5 rounded-xl bg-neutral-900 border border-neutral-700 text-white font-mono outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="block text-neutral-300 font-semibold mb-1">
                    PhonePe UPI ID <span className="text-amber-400">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={settings.phonePeUpiId || ''}
                    onChange={e => setSettings({ ...settings, phonePeUpiId: e.target.value })}
                    placeholder="talkbot@ybl"
                    className="w-full px-3 py-2.5 rounded-xl bg-neutral-900 border border-neutral-700 text-white font-mono outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="block text-neutral-300 font-semibold mb-1">
                    Recipient Display Name
                  </label>
                  <input
                    type="text"
                    value={settings.phonePeRecipientName || ''}
                    onChange={e => setSettings({ ...settings, phonePeRecipientName: e.target.value })}
                    placeholder="TALKBOT AI (Maaneesh)"
                    className="w-full px-3 py-2.5 rounded-xl bg-neutral-900 border border-neutral-700 text-white outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              {/* Automatic PhonePe Verification Explanation Box */}
              <div className="p-4 rounded-xl bg-neutral-900/90 border border-neutral-800 space-y-2 text-[11px] text-neutral-300">
                <div className="flex items-center gap-2 font-bold text-amber-300">
                  <ShieldCheck className="w-4 h-4" />
                  <span>PhonePe Automated Verification Architecture</span>
                </div>
                <p className="leading-relaxed text-neutral-400">
                  Currently active in <strong>Direct Administrator Verification Mode</strong>: Customers submit their 12-digit PhonePe Transaction ID (UTR), which appears immediately in your "PhonePe Subscriptions" tab for you to cross-verify against your PhonePe app.
                </p>
                <p className="leading-relaxed text-neutral-400">
                  To enable fully automated server-to-server PhonePe API verification, you must obtain PhonePe Merchant credentials (<code className="text-amber-300">PHONEPE_MERCHANT_ID</code> and <code className="text-amber-300">PHONEPE_SALT_KEY</code>) from the PhonePe Business portal and configure server webhook endpoints.
                </p>
              </div>
            </div>

            {/* Language & Maintenance */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-neutral-300 font-semibold mb-1">Default Language</label>
                <select
                  value={settings.defaultLanguage}
                  onChange={e => setSettings({ ...settings, defaultLanguage: e.target.value as any })}
                  className="w-full px-3 py-2 rounded-xl bg-neutral-900 border border-neutral-800 text-white outline-none cursor-pointer"
                >
                  <option value="en">English (Default)</option>
                  <option value="te">తెలుగు (Telugu)</option>
                </select>
              </div>

              <div>
                <label className="block text-neutral-300 font-semibold mb-1">Maintenance Mode</label>
                <select
                  value={settings.maintenanceMode ? 'true' : 'false'}
                  onChange={e => setSettings({ ...settings, maintenanceMode: e.target.value === 'true' })}
                  className="w-full px-3 py-2 rounded-xl bg-neutral-900 border border-neutral-800 text-white outline-none cursor-pointer"
                >
                  <option value="false">Live (Standard Operation)</option>
                  <option value="true">Maintenance Mode Active</option>
                </select>
              </div>
            </div>

            {/* AdSense configuration */}
            <div className="p-4 rounded-xl bg-neutral-900/60 border border-neutral-800 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-white text-sm">Google AdSense Integration Ready</h3>
                  <p className="text-neutral-400 text-[11px] mt-0.5">
                    Toggle visibility of responsive ad spaces.
                  </p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings.adSenseEnabled}
                    onChange={e => setSettings({ ...settings, adSenseEnabled: e.target.checked })}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-neutral-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-amber-500"></div>
                </label>
              </div>

              <div>
                <label className="block text-neutral-300 font-semibold mb-1">
                  AdSense Publisher Client ID (ca-pub-XXXXXXXX)
                </label>
                <input
                  type="text"
                  value={settings.adSenseClientId || ''}
                  onChange={e => setSettings({ ...settings, adSenseClientId: e.target.value })}
                  placeholder="ca-pub-1234567890123456"
                  className="w-full px-3 py-2 rounded-xl bg-neutral-900 border border-neutral-800 text-white outline-none focus:border-amber-500/50"
                />
              </div>
            </div>

            <div>
              <label className="block text-neutral-300 font-semibold mb-1">Site-wide Notice Banner (Optional)</label>
              <input
                type="text"
                value={settings.bannerNotice || ''}
                onChange={e => setSettings({ ...settings, bannerNotice: e.target.value })}
                placeholder="e.g. Welcome to TalkBot AI! Full Telugu and English Gemini models active."
                className="w-full px-3 py-2 rounded-xl bg-neutral-900 border border-neutral-800 text-white outline-none focus:border-amber-500/50"
              />
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="submit"
                className="px-6 py-2.5 rounded-xl gold-gradient-bg text-black font-bold flex items-center gap-2 cursor-pointer shadow-md shadow-amber-500/20"
              >
                <Save className="w-4 h-4" />
                <span>Save All Settings</span>
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
