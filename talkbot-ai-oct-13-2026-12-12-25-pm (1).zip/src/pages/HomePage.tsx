import React, { useState } from 'react';
import { Sparkles, Bot, Code, GraduationCap, Briefcase, Mail, Share2, Layout, UserCheck, ArrowRight, CheckCircle2, ShieldCheck, Zap, Crown } from 'lucide-react';
import { Language } from '../types';
import { AdPlacement } from '../components/AdPlacement';

interface HomePageProps {
  setCurrentPage: (page: string) => void;
  language: Language;
  onSelectTool?: (toolId: string) => void;
  onStartChatWithPrompt?: (prompt: string) => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  setCurrentPage,
  language,
  onSelectTool,
  onStartChatWithPrompt
}) => {
  const [quickInput, setQuickInput] = useState('');

  const handleQuickSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickInput.trim()) return;
    if (onStartChatWithPrompt) {
      onStartChatWithPrompt(quickInput.trim());
    } else {
      setCurrentPage('chat');
    }
  };

  const toolsList = [
    {
      id: 'study',
      name: language === 'te' ? 'స్టడీ అసిస్టెంట్' : 'Study Assistant',
      desc: language === 'te' ? 'క్లిష్టమైన కాన్సెప్ట్‌లు, పరీక్షల తయారీ మరియు లెక్కల వివరణ' : 'Deconstruct complex topics, generate flashcards, and master exam problem sets.',
      icon: GraduationCap,
      color: 'from-amber-400 to-yellow-600'
    },
    {
      id: 'coding',
      name: language === 'te' ? 'కోడింగ్ అసిస్టెంట్' : 'Coding Assistant',
      desc: language === 'te' ? 'క్లీన్ కోడ్ రాత, డీబగ్గింగ్, అల్గారిథమ్స్ మరియు సిస్టమ్ ఆర్కిటెక్చర్' : 'Write idiomatic code, troubleshoot runtime bugs, and master system architectures.',
      icon: Code,
      color: 'from-amber-500 to-amber-700'
    },
    {
      id: 'writing',
      name: language === 'te' ? 'రైటింగ్ అసిస్టెంట్' : 'Writing Assistant',
      desc: language === 'te' ? 'వ్యాసాలు, బ్లాగులు, ప్రొఫెషనల్ రీరైటింగ్ మరియు శైలి మెరుగుదల' : 'Craft essays, editorial articles, and polished narratives with nuanced tone control.',
      icon: Sparkles,
      color: 'from-yellow-400 to-amber-600'
    },
    {
      id: 'business',
      name: language === 'te' ? 'బిజినెస్ ఐడియాస్' : 'Business Ideas Assistant',
      desc: language === 'te' ? 'స్టార్టప్ వ్యూహాలు, మార్కెట్ మోడల్స్, మరియు ఆదాయ పద్ధతులు' : 'Formulate market validation, revenue blueprints, and executable startup strategies.',
      icon: Briefcase,
      color: 'from-amber-300 to-amber-600'
    },
    {
      id: 'email',
      name: language === 'te' ? 'ఈమెయిల్ & లెటర్ రైటర్' : 'Email & Letter Writer',
      desc: language === 'te' ? 'అధికారిక ఈమెయిళ్ళు, జాబ్ కవర్ లెటర్లు మరియు ప్రొఫెషనల్ నోటీసులు' : 'Generate persuasive executive emails, cover letters, and formal corporate proposals.',
      icon: Mail,
      color: 'from-amber-400 to-yellow-700'
    },
    {
      id: 'social',
      name: language === 'te' ? 'సోషల్ మీడియా క్యాప్షన్స్' : 'Social Media Generator',
      desc: language === 'te' ? 'వైరల్ క్యాప్షన్స్, హాష్‌ట్యాగ్‌లు, మరియు ఎంగేజ్‌మెంట్ హుక్స్' : 'Produce high-converting caption variations with relevant tags and viral hooks.',
      icon: Share2,
      color: 'from-yellow-500 to-amber-600'
    },
    {
      id: 'website',
      name: language === 'te' ? 'వెబ్‌సైట్ ప్లానింగ్' : 'Website Planning Guide',
      desc: language === 'te' ? 'సైట్‌మ్యాప్, UI/UX లేఅవుట్, కన్వర్షన్ సెక్షన్లు మరియు టెక్ స్టాక్' : 'Structure sitemaps, information hierarchy, and UI/UX conversion wireframes.',
      icon: Layout,
      color: 'from-amber-400 to-amber-800'
    },
    {
      id: 'interview',
      name: language === 'te' ? 'ఇంటర్వ్యూ ప్రాక్టీస్' : 'Interview Practice Coach',
      desc: language === 'te' ? 'రియలిస్టిక్ ఇంటర్వ్యూ ప్రశ్నలు మరియు STAR మోడల్ సమాధానాలు' : 'Simulate rigorous technical and behavioral questions using the STAR framework.',
      icon: UserCheck,
      color: 'from-amber-200 to-amber-600'
    }
  ];

  const samplePrompts = [
    language === 'te'
      ? 'క్వాంటమ్ కంప్యూటింగ్ ఎలా పనిచేస్తుందో తెలుగులో సరళంగా వివరించు?'
      : 'Explain how asynchronous event loops work in Node.js with a simple analogy.',
    language === 'te'
      ? 'ఆన్‌లైన్ బిజినెస్ ప్రారంభించడానికి 5 తక్కువ బడ్జెట్ ఆలోచనలు ఇవ్వండి.'
      : 'Formulate a 30-day MVP launch plan for a B2B SaaS analytics tool.',
    language === 'te'
      ? 'పైథాన్‌లో బైనరీ సెర్చ్ అల్గారిథమ్ కోడ్ రాసి వివరించు.'
      : 'Write a clean TypeScript debounce hook with cancellation support.',
  ];

  return (
    <div className="space-y-16 py-8">
      {/* Hero Section */}
      <section className="relative overflow-hidden pt-8 pb-14 text-center">
        {/* Subtle decorative gold ambient background glow */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-amber-500/10 blur-[130px] rounded-full pointer-events-none -z-10" />

        <div className="max-w-4xl mx-auto px-4">
          {/* Subtle Tagline kicker */}
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs font-semibold uppercase tracking-wider mb-6">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>TalkBot AI · Your World. One AI.</span>
          </div>

          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white mb-6 leading-[1.15]">
            Experience Pure Intelligence with{' '}
            <span className="gold-gradient-text block sm:inline">
              TalkBot AI
            </span>
          </h1>

          <p className="text-base sm:text-lg text-neutral-300 max-w-2xl mx-auto mb-8 leading-relaxed">
            {language === 'te'
              ? 'విద్య, కోడింగ్, రచన, మరియు వ్యాపార ఆలోచనల కోసం రూపొందించబడిన ఆధునిక కృత్రిమ మేధస్సు. ఇంగ్లీష్ మరియు తెలుగు భాషలలో పరిపూర్ణమైన సమాధానాలు పొందండి.'
              : 'The definitive all-in-one intelligence suite. Engineered with Google Gemini to master education, coding, creative writing, enterprise strategy, and multilingual dialogue.'}
          </p>

          {/* Quick Chat Input Box */}
          <div className="max-w-2xl mx-auto mb-6">
            <form onSubmit={handleQuickSubmit} className="relative flex items-center">
              <input
                type="text"
                value={quickInput}
                onChange={e => setQuickInput(e.target.value)}
                placeholder={
                  language === 'te'
                    ? 'ఏదైనా అడగండి (ఉదా: పైథాన్ కోడ్, గణిత సమస్య, లేదా వ్యాపార ప్రణాళిక)...'
                    : 'Ask anything (e.g., Explain Quantum Physics, Debug Python, or Plan a Startup)...'
                }
                className="w-full pl-5 pr-32 py-4 rounded-2xl bg-neutral-900/90 border border-amber-500/30 text-white placeholder-neutral-500 text-sm focus:outline-none focus:border-amber-400 focus:ring-2 focus:ring-amber-500/20 shadow-2xl transition-all"
              />
              <button
                type="submit"
                className="absolute right-2.5 px-4 py-2.5 rounded-xl gold-gradient-bg text-black font-bold text-xs flex items-center gap-1.5 hover:brightness-110 active:scale-95 transition-all cursor-pointer shadow-md shadow-amber-500/20"
              >
                <span>{language === 'te' ? 'స్టార్ట్' : 'Chat Now'}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </form>

            {/* Prompt suggestions */}
            <div className="flex flex-wrap items-center justify-center gap-2 mt-3">
              {samplePrompts.map((p, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    if (onStartChatWithPrompt) onStartChatWithPrompt(p);
                    else setCurrentPage('chat');
                  }}
                  className="text-left text-[11px] px-3 py-1.5 rounded-lg bg-neutral-900/60 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 hover:text-amber-300 transition-colors cursor-pointer truncate max-w-xs"
                >
                  "{p}"
                </button>
              ))}
            </div>
          </div>

          {/* Action CTAs */}
          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            <button
              onClick={() => setCurrentPage('chat')}
              className="py-3 px-6 rounded-xl gold-gradient-bg text-black font-bold text-sm flex items-center gap-2 hover:brightness-110 shadow-lg shadow-amber-500/20 transition-all cursor-pointer"
            >
              <Bot className="w-4 h-4" />
              <span>{language === 'te' ? 'AI చాట్‌ను ప్రారంభించండి' : 'Launch Full AI Chat'}</span>
            </button>
            <button
              onClick={() => setCurrentPage('tools')}
              className="py-3 px-6 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-amber-500/30 text-amber-300 font-semibold text-sm flex items-center gap-2 transition-all cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>{language === 'te' ? '8 AI టూల్స్ చూడండి' : 'Explore 8 AI Tools'}</span>
            </button>
          </div>
        </div>
      </section>

      {/* Feature Highlights Banner */}
      <section className="max-w-6xl mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 rounded-2xl bg-neutral-900/60 border border-amber-500/20">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center mb-4">
              <Zap className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-white mb-2">Real Google Gemini 3.8 Flash</h3>
            <p className="text-xs text-neutral-400 leading-relaxed">
              Strictly powered by Google's modern Gemini API on our authenticated backend. Zero fabricated responses or mocked answers.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-neutral-900/60 border border-amber-500/20">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center mb-4">
              <Sparkles className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-white mb-2">Telugu & English Mastery</h3>
            <p className="text-xs text-neutral-400 leading-relaxed">
              Fluent bilingual reasoning across scripts. Seamlessly handles pure Telugu, modern transliteration, and technical English terminology.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-neutral-900/60 border border-amber-500/20">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center mb-4">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-white mb-2">Private User Accounts</h3>
            <p className="text-xs text-neutral-400 leading-relaxed">
              Individual chat sessions stay strictly private. Secure salted credentials and session encryption protect your conversations.
            </p>
          </div>
        </div>
      </section>

      {/* AdSense Placement Area */}
      <section className="max-w-5xl mx-auto px-4">
        <AdPlacement slotId="home-leaderboard" format="horizontal" />
      </section>

      {/* 8 AI Specialized Tools Section */}
      <section className="max-w-6xl mx-auto px-4">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 gap-4">
          <div>
            <span className="text-xs font-semibold text-amber-400 uppercase tracking-widest">
              Specialized Capabilities
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white mt-1">
              8 Tailored AI Productivity Tools
            </h2>
          </div>
          <button
            onClick={() => setCurrentPage('tools')}
            className="text-xs font-semibold text-amber-300 hover:text-amber-200 flex items-center gap-1 cursor-pointer self-start sm:self-auto"
          >
            <span>View All Tools</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {toolsList.map(tool => {
            const Icon = tool.icon;
            return (
              <div
                key={tool.id}
                onClick={() => {
                  if (onSelectTool) onSelectTool(tool.id);
                  setCurrentPage('tools');
                }}
                className="group p-5 rounded-2xl bg-neutral-900/60 border border-neutral-800 hover:border-amber-500/40 hover:bg-neutral-900 transition-all duration-200 cursor-pointer flex flex-col justify-between"
              >
                <div>
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-neutral-800 to-neutral-900 border border-amber-500/20 flex items-center justify-center text-amber-400 group-hover:scale-105 transition-transform mb-3">
                    <Icon className="w-5 h-5" />
                  </div>
                  <h3 className="text-sm font-bold text-white group-hover:text-amber-300 transition-colors">
                    {tool.name}
                  </h3>
                  <p className="text-xs text-neutral-400 mt-1.5 leading-relaxed">
                    {tool.desc}
                  </p>
                </div>
                <div className="mt-4 pt-3 border-t border-neutral-800/80 flex items-center justify-between text-[11px] font-semibold text-amber-400/80 group-hover:text-amber-300">
                  <span>Open Assistant</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Founder & CEO Leadership Section */}
      <section className="max-w-4xl mx-auto px-4">
        <div className="rounded-2xl border border-amber-500/25 bg-neutral-950 p-6 sm:p-7 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-5 shadow-lg">
          <div className="flex items-center gap-3.5">
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-amber-400 via-amber-500 to-amber-600 text-black flex items-center justify-center font-bold shadow-md shadow-amber-500/20 shrink-0">
              <Crown className="w-6 h-6" />
            </div>
            <div>
              <span className="text-[10px] font-bold uppercase tracking-widest text-amber-400">
                Leadership
              </span>
              <h3 className="text-base font-bold text-white tracking-wide">
                MAANEESH
              </h3>
              <p className="text-xs text-amber-300 font-semibold">
                Founder & CEO — TalkBot AI
              </p>
            </div>
          </div>
          <div className="text-left sm:text-right border-t sm:border-t-0 sm:border-l border-neutral-800 pt-3 sm:pt-0 sm:pl-5 w-full sm:w-auto">
            <span className="font-bold text-xs tracking-wide text-white block">
              TALKBOT AI
            </span>
            <p className="text-[11px] text-amber-300/80 font-medium">
              “Your World. One AI.”
            </p>
          </div>
        </div>
      </section>

      {/* Zero Budget / Genuinely Free Tier Promise */}
      <section className="max-w-4xl mx-auto px-4">
        <div className="rounded-2xl border border-amber-500/30 bg-gradient-to-b from-[#131318] to-[#0A0A0E] p-8 text-center relative overflow-hidden">
          <div className="max-w-xl mx-auto">
            <h3 className="text-2xl font-bold text-white mb-2">
              Free Access for Everyone. Zero Subscriptions Required.
            </h3>
            <p className="text-xs text-neutral-300 mb-6 leading-relaxed">
              TalkBot AI is intentionally configured on genuinely free-tier cloud architectures. No surprise credit card billing, no fake paywalls, and no hidden subscriptions.
            </p>
            <div className="flex flex-wrap justify-center gap-4 text-xs text-neutral-300">
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>₹0 Core Usage</span>
              </span>
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>No Credit Card Required</span>
              </span>
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Telugu & English Supported</span>
              </span>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
