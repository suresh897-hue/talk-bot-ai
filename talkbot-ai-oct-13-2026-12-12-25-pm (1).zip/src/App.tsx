/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { ThemeProvider } from './context/ThemeContext';
import { AuthProvider } from './context/AuthContext';
import { LanguageProvider, useLanguage } from './context/LanguageContext';
import { ToolId } from './types';
import { getPublicSettings } from './services/api';

import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { AuthModal } from './components/AuthModal';

import { HomePage } from './pages/HomePage';
import { ChatPage } from './pages/ChatPage';
import { ToolsPage } from './pages/ToolsPage';
import { ArticlesPage } from './pages/ArticlesPage';
import { PricingPage } from './pages/PricingPage';
import { AboutPage } from './pages/AboutPage';
import { ContactPage } from './pages/ContactPage';
import { LegalPage } from './pages/LegalPage';
import { AdminPage } from './pages/AdminPage';

function AppContent() {
  const [currentPage, setCurrentPage] = useState<string>('home');
  const { language, setLanguage } = useLanguage();
  const [selectedToolId, setSelectedToolId] = useState<ToolId>('study');
  const [chatInitialPrompt, setChatInitialPrompt] = useState<string>('');
  const [bannerNotice, setBannerNotice] = useState<string>('');

  useEffect(() => {
    getPublicSettings()
      .then(settings => {
        if (settings?.bannerNotice) {
          setBannerNotice(settings.bannerNotice);
        }
        // Only set default language if user has not yet customized it in localStorage
        try {
          const stored = localStorage.getItem('talkbot_language');
          if (!stored && settings?.defaultLanguage) {
            setLanguage(settings.defaultLanguage);
          }
        } catch {
          // Fallback if localStorage is inaccessible
          if (settings?.defaultLanguage) {
            setLanguage(settings.defaultLanguage);
          }
        }
      })
      .catch(() => {});
  }, [setLanguage]);

  useEffect(() => {
    const handleNav = (e: any) => {
      if (e.detail) {
        setCurrentPage(e.detail);
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    };
    window.addEventListener('talkbot-navigate', handleNav);
    return () => window.removeEventListener('talkbot-navigate', handleNav);
  }, []);

  const handleStartChatWithPrompt = (prompt: string) => {
    setChatInitialPrompt(prompt);
    setCurrentPage('chat');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectTool = (toolId: string) => {
    setSelectedToolId(toolId as ToolId);
    setCurrentPage('tools');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#08080A] text-slate-100 transition-colors">
      {/* Optional Admin Banner Notice */}
      {bannerNotice && (
        <div className="w-full bg-gradient-to-r from-amber-600 via-amber-500 to-amber-600 text-black px-4 py-1.5 text-center text-xs font-bold tracking-wide shadow-sm">
          {bannerNotice}
        </div>
      )}

      {/* Navigation Bar with Persistent Language Switcher */}
      <Navbar
        currentPage={currentPage}
        setCurrentPage={setCurrentPage}
        language={language}
        setLanguage={setLanguage}
      />

      {/* Page Routing */}
      <div className="flex-1">
        {currentPage === 'home' && (
          <HomePage
            setCurrentPage={setCurrentPage}
            language={language}
            onSelectTool={handleSelectTool}
            onStartChatWithPrompt={handleStartChatWithPrompt}
          />
        )}

        {currentPage === 'chat' && (
          <ChatPage
            language={language}
            setLanguage={setLanguage}
            initialPrompt={chatInitialPrompt}
          />
        )}

        {currentPage === 'tools' && (
          <ToolsPage
            language={language}
            setLanguage={setLanguage}
            defaultToolId={selectedToolId}
          />
        )}

        {currentPage === 'articles' && (
          <ArticlesPage language={language} />
        )}

        {currentPage === 'pricing' && (
          <PricingPage
            language={language}
            onSelectFree={() => {
              setCurrentPage('chat');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}

        {currentPage === 'about' && (
          <AboutPage language={language} />
        )}

        {currentPage === 'contact' && (
          <ContactPage language={language} />
        )}

        {currentPage === 'privacy' && (
          <LegalPage initialTab="privacy" />
        )}

        {currentPage === 'terms' && (
          <LegalPage initialTab="terms" />
        )}

        {currentPage === 'admin' && (
          <AdminPage />
        )}
      </div>

      {/* Footer */}
      <Footer setCurrentPage={setCurrentPage} language={language} />

      {/* Global Authentication Modal */}
      <AuthModal />
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <LanguageProvider>
        <AuthProvider>
          <AppContent />
        </AuthProvider>
      </LanguageProvider>
    </ThemeProvider>
  );
}
