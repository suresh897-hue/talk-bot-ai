import React, { createContext, useContext, useEffect, useState } from 'react';
import { User } from '../types';
import { getCurrentUser, loginUser, registerUser, resetPassword as apiResetPassword } from '../services/api';

interface AuthContextType {
  user: User | null;
  token: string | null;
  isLoading: boolean;
  isAdmin: boolean;
  authModalOpen: boolean;
  authModalView: 'login' | 'register' | 'forgot';
  openAuthModal: (view?: 'login' | 'register' | 'forgot') => void;
  closeAuthModal: () => void;
  login: (email: string, pass: string) => Promise<void>;
  register: (name: string, email: string, pass: string) => Promise<void>;
  logout: () => void;
  resetPassword: (email: string, pass: string) => Promise<string>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(() => localStorage.getItem('talkbot_token'));
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authModalView, setAuthModalView] = useState<'login' | 'register' | 'forgot'>('login');

  useEffect(() => {
    async function loadUser() {
      if (!token) {
        setUser(null);
        setIsLoading(false);
        return;
      }
      try {
        const { user } = await getCurrentUser(token);
        setUser(user);
      } catch (err) {
        console.warn('Session expired or token invalid, removing local token');
        localStorage.removeItem('talkbot_token');
        setToken(null);
        setUser(null);
      } finally {
        setIsLoading(false);
      }
    }
    loadUser();
  }, [token]);

  const openAuthModal = (view: 'login' | 'register' | 'forgot' = 'login') => {
    setAuthModalView(view);
    setAuthModalOpen(true);
  };

  const closeAuthModal = () => {
    setAuthModalOpen(false);
  };

  const login = async (email: string, pass: string) => {
    const res = await loginUser(email, pass);
    localStorage.setItem('talkbot_token', res.token);
    setToken(res.token);
    setUser(res.user);
    setAuthModalOpen(false);
  };

  const register = async (name: string, email: string, pass: string) => {
    const res = await registerUser(name, email, pass);
    localStorage.setItem('talkbot_token', res.token);
    setToken(res.token);
    setUser(res.user);
    setAuthModalOpen(false);
  };

  const logout = () => {
    if (token) {
      fetch('/api/auth/logout', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` }
      }).catch(() => {});
    }
    localStorage.removeItem('talkbot_token');
    setToken(null);
    setUser(null);
  };

  const resetPassword = async (email: string, pass: string) => {
    const res = await apiResetPassword(email, pass);
    return res.message;
  };

  const isAdmin = user?.role === 'admin' || user?.email.toLowerCase() === 'suresh897@gmail.com';

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        isLoading,
        isAdmin,
        authModalOpen,
        authModalView,
        openAuthModal,
        closeAuthModal,
        login,
        register,
        logout,
        resetPassword
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
