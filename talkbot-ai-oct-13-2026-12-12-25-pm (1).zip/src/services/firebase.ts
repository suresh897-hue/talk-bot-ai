import { initializeApp, getApps, getApp } from 'firebase/app';
import { getFirestore, doc, setDoc, getDoc, getDocFromServer } from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';
import { SubscriptionOrder, UserSubscription } from '../types';

// Initialize Firebase App singleton
const app = getApps().length > 0 ? getApp() : initializeApp({
  apiKey: firebaseConfig.apiKey,
  authDomain: firebaseConfig.authDomain,
  projectId: firebaseConfig.projectId,
  storageBucket: firebaseConfig.storageBucket,
  messagingSenderId: firebaseConfig.messagingSenderId,
  appId: firebaseConfig.appId
});

// Initialize Firestore with configured databaseId
export const db = getFirestore(
  app,
  firebaseConfig.firestoreDatabaseId || '(default)'
);

/**
 * Validate connection to Firestore as required by Firebase Integration standard
 */
export async function testFirestoreConnection(): Promise<boolean> {
  try {
    await getDocFromServer(doc(db, '_connection_test', 'ping'));
    return true;
  } catch (error: any) {
    if (error?.message?.includes('the client is offline')) {
      console.warn('[Firebase] Client is offline or Firestore config needs attention.');
    }
    return false;
  }
}

/**
 * Securely store / sync subscription record in Firebase Firestore
 */
export async function storeSubscriptionInFirebase(order: SubscriptionOrder): Promise<void> {
  try {
    const subRef = doc(db, 'subscriptions', order.id);
    await setDoc(subRef, {
      id: order.id,
      userId: order.userId,
      userEmail: order.userEmail,
      userName: order.userName,
      planId: order.planId,
      planName: order.planName,
      amount: order.amount,
      phonePeTransactionId: order.phonePeTransactionId,
      customerPhone: order.customerPhone || '',
      status: order.status,
      createdAt: order.createdAt,
      verifiedAt: order.verifiedAt || null,
      expiresAt: order.expiresAt || null,
      notes: order.notes || ''
    }, { merge: true });

    // Also sync to user subscription path
    if (order.status === 'active' && order.userId) {
      const userSubRef = doc(db, 'users', order.userId, 'subscription', 'current');
      const now = Date.now();
      const expiresAtMs = order.expiresAt ? new Date(order.expiresAt).getTime() : 0;
      const isExpired = expiresAtMs > 0 && expiresAtMs < now;
      const daysRemaining = !isExpired && expiresAtMs > now
        ? Math.max(0, Math.ceil((expiresAtMs - now) / (1000 * 60 * 60 * 24)))
        : 0;

      await setDoc(userSubRef, {
        planId: order.planId,
        planName: order.planName,
        amount: order.amount,
        status: isExpired ? 'expired' : 'active',
        phonePeTransactionId: order.phonePeTransactionId,
        createdAt: order.createdAt,
        verifiedAt: order.verifiedAt,
        expiresAt: order.expiresAt,
        isExpired,
        daysRemaining
      }, { merge: true });
    }
  } catch (err) {
    console.warn('[Firebase] Could not sync subscription to Firestore directly (server backup is active):', err);
  }
}

/**
 * Fetch subscription status from Firebase Firestore
 */
export async function getSubscriptionFromFirebase(userId: string): Promise<UserSubscription | null> {
  try {
    const userSubRef = doc(db, 'users', userId, 'subscription', 'current');
    const snap = await getDoc(userSubRef);
    if (!snap.exists()) return null;
    return snap.data() as UserSubscription;
  } catch (err) {
    console.warn('[Firebase] Failed to fetch subscription from Firestore:', err);
    return null;
  }
}
