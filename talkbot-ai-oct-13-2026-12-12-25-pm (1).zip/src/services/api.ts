import {
  ChatMessage,
  Language,
  Article,
  SiteSettings,
  User,
  ChatSession,
  ToolId,
  SubscriptionPlan,
  SubscriptionPlanId,
  SubscriptionOrder,
  PhonePeConfig,
  UserSubscription
} from '../types';

export class ApiError extends Error {
  status?: number;
  errorType?: string;
  retryAfter?: number;
  constructor(message: string, status?: number, errorType?: string, retryAfter?: number) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.errorType = errorType;
    this.retryAfter = retryAfter;
  }
}

async function handleResponse<T>(res: Response): Promise<T> {
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const errorMsg = data.error || `Server request failed with status ${res.status}`;
    throw new ApiError(errorMsg, res.status, data.errorType, data.retryAfter);
  }
  return data as T;
}

export async function checkHealth() {
  const res = await fetch('/api/health');
  return handleResponse<{
    status: string;
    appName: string;
    tagline: string;
    geminiConfigured: boolean;
    adSenseEnabled: boolean;
    defaultLanguage: Language;
    maintenanceMode: boolean;
  }>(res);
}

export async function sendChatMessage(
  messages: { role: 'user' | 'model'; content: string }[],
  language: Language = 'en',
  persona: string = 'general',
  signal?: AbortSignal
) {
  const res = await fetch('/api/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ messages, language, persona }),
    signal
  });
  return handleResponse<{ response: string; model: string; language: Language }>(res);
}

export async function executeTool(
  toolId: ToolId,
  prompt: string,
  language: Language = 'en',
  inputs: Record<string, string> = {}
) {
  const res = await fetch('/api/tool/execute', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ toolId, prompt, language, inputs })
  });
  return handleResponse<{ toolId: ToolId; result: string; language: Language }>(res);
}

export async function getArticles(category?: string, search?: string) {
  const params = new URLSearchParams();
  if (category) params.append('category', category);
  if (search) params.append('search', search);

  const url = `/api/articles${params.toString() ? '?' + params.toString() : ''}`;
  const res = await fetch(url);
  return handleResponse<{ articles: Article[] }>(res);
}

export async function getArticleBySlug(slug: string) {
  const res = await fetch(`/api/articles/${encodeURIComponent(slug)}`);
  return handleResponse<{ article: Article }>(res);
}

export async function saveArticle(data: Partial<Article>, token: string) {
  const res = await fetch('/api/admin/articles', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    },
    body: JSON.stringify(data)
  });
  return handleResponse<{ article: Article }>(res);
}

export async function updateArticle(id: string, data: Partial<Article>, token: string) {
  const res = await fetch(`/api/admin/articles/${encodeURIComponent(id)}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    },
    body: JSON.stringify(data)
  });
  return handleResponse<{ article: Article }>(res);
}

export async function deleteArticle(id: string, token: string) {
  const res = await fetch(`/api/admin/articles/${encodeURIComponent(id)}`, {
    method: 'DELETE',
    headers: {
      Authorization: `Bearer ${token}`
    }
  });
  return handleResponse<{ success: boolean; message: string }>(res);
}

export async function loginUser(email: string, password: string) {
  const res = await fetch('/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password })
  });
  return handleResponse<{ token: string; user: User }>(res);
}

export async function registerUser(name: string, email: string, password: string) {
  const res = await fetch('/api/auth/register', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, email, password })
  });
  return handleResponse<{ token: string; user: User }>(res);
}

export async function getCurrentUser(token: string) {
  const res = await fetch('/api/auth/me', {
    headers: { Authorization: `Bearer ${token}` }
  });
  return handleResponse<{ user: User }>(res);
}

export async function resetPassword(email: string, newPassword: string) {
  const res = await fetch('/api/auth/reset-password', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, newPassword })
  });
  return handleResponse<{ success: boolean; message: string }>(res);
}

export async function getPublicSettings() {
  const res = await fetch('/api/settings/public');
  return handleResponse<Partial<SiteSettings>>(res);
}

export async function getAdminSettings(token: string) {
  const res = await fetch('/api/admin/settings', {
    headers: { Authorization: `Bearer ${token}` }
  });
  return handleResponse<{
    settings: SiteSettings;
    totalUsers: number;
    totalArticles: number;
    adminEmail: string;
  }>(res);
}

export async function updateAdminSettings(settings: Partial<SiteSettings>, token: string) {
  const res = await fetch('/api/admin/settings', {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    },
    body: JSON.stringify(settings)
  });
  return handleResponse<{ settings: SiteSettings; message: string }>(res);
}

export async function fetchUserHistories(token: string) {
  const res = await fetch('/api/history', {
    headers: { Authorization: `Bearer ${token}` }
  });
  return handleResponse<{ histories: ChatSession[] }>(res);
}

export async function saveUserHistory(session: ChatSession, token: string) {
  const res = await fetch('/api/history', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    },
    body: JSON.stringify(session)
  });
  return handleResponse<{ success: boolean; history: ChatSession }>(res);
}

export async function deleteUserHistory(id: string, token: string) {
  const res = await fetch(`/api/history/${encodeURIComponent(id)}`, {
    method: 'DELETE',
    headers: { Authorization: `Bearer ${token}` }
  });
  return handleResponse<{ success: boolean }>(res);
}

// -------------------------------------------------------------
// PhonePe Subscriptions API Client
// -------------------------------------------------------------

export async function getSubscriptionPlans() {
  const res = await fetch('/api/subscriptions/plans');
  return handleResponse<{
    plans: SubscriptionPlan[];
    phonePeConfig: PhonePeConfig;
  }>(res);
}

export async function getMySubscription(token: string) {
  const res = await fetch('/api/subscriptions/my', {
    headers: { Authorization: `Bearer ${token}` }
  });
  return handleResponse<{
    subscription: UserSubscription | null;
    user: Partial<User>;
  }>(res);
}

export async function createSubscriptionOrder(planId: SubscriptionPlanId, token: string) {
  const res = await fetch('/api/subscriptions/create-order', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    },
    body: JSON.stringify({ planId })
  });
  return handleResponse<{
    order: SubscriptionOrder;
    phonePeConfig: PhonePeConfig;
    paymentInstructions: {
      planName: string;
      amount: number;
      currency: string;
      daysDuration: number;
      phonePeNumber: string;
      phonePeUpiId: string;
      recipientName: string;
      steps: string[];
    };
  }>(res);
}

export async function submitPhonePePaymentProof(
  orderId: string,
  phonePeTransactionId: string,
  customerPhone: string,
  token: string
) {
  const res = await fetch('/api/subscriptions/submit-proof', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    },
    body: JSON.stringify({ orderId, phonePeTransactionId, customerPhone })
  });
  return handleResponse<{
    success: boolean;
    status: 'pending_verification' | 'active';
    order: SubscriptionOrder;
    verified: boolean;
    message: string;
    securityNotice: string;
  }>(res);
}

export async function getAdminSubscriptions(token: string) {
  const res = await fetch('/api/admin/subscriptions', {
    headers: { Authorization: `Bearer ${token}` }
  });
  return handleResponse<{
    subscriptions: SubscriptionOrder[];
    totalOrders: number;
    pendingCount: number;
    activeCount: number;
    phonePeConfig: PhonePeConfig;
  }>(res);
}

export async function verifySubscriptionOrder(orderId: string, token: string) {
  const res = await fetch(`/api/admin/subscriptions/${encodeURIComponent(orderId)}/verify`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}` }
  });
  return handleResponse<{
    success: boolean;
    order: SubscriptionOrder;
    userSubscription: UserSubscription | null;
    message: string;
  }>(res);
}

export async function rejectSubscriptionOrder(orderId: string, notes: string, token: string) {
  const res = await fetch(`/api/admin/subscriptions/${encodeURIComponent(orderId)}/reject`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    },
    body: JSON.stringify({ notes })
  });
  return handleResponse<{
    success: boolean;
    order: SubscriptionOrder;
    message: string;
  }>(res);
}

export async function deleteSubscriptionOrder(orderId: string, token: string) {
  const res = await fetch(`/api/admin/subscriptions/${encodeURIComponent(orderId)}`, {
    method: 'DELETE',
    headers: { Authorization: `Bearer ${token}` }
  });
  return handleResponse<{ success: boolean; message: string }>(res);
}

