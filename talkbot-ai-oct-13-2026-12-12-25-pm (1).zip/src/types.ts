export type Language = 'en' | 'te';

export type SubscriptionPlanId = 'basic' | 'starter' | 'pro' | 'premium' | 'ultimate';

export interface SubscriptionPlan {
  id: SubscriptionPlanId;
  name: string;
  nameTe: string;
  price: number; // in INR (₹)
  billingPeriod: string; // '/month'
  daysDuration: number; // 30
  badge?: string;
  popular?: boolean;
  features: string[];
}

export interface UserSubscription {
  planId: SubscriptionPlanId;
  planName: string;
  amount: number;
  status: 'pending_verification' | 'active' | 'expired' | 'rejected';
  phonePeTransactionId: string;
  createdAt: string;
  verifiedAt?: string;
  expiresAt?: string;
  isExpired: boolean;
  daysRemaining: number;
}

export interface SubscriptionOrder {
  id: string;
  userId: string;
  userEmail: string;
  userName: string;
  planId: SubscriptionPlanId;
  planName: string;
  amount: number;
  phonePeTransactionId: string;
  customerPhone?: string;
  status: 'pending_verification' | 'active' | 'expired' | 'rejected';
  createdAt: string;
  verifiedAt?: string;
  expiresAt?: string;
  notes?: string;
}

export interface PhonePeConfig {
  phonePeNumber: string;
  phonePeUpiId: string;
  phonePeRecipientName: string;
  merchantVerifiedMode: boolean;
}

export interface User {
  id: string;
  email: string;
  name: string;
  role: 'admin' | 'user';
  subscription?: UserSubscription;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  content: string;
  timestamp: string;
  language?: Language;
}

export interface ChatSession {
  id: string;
  title: string;
  messages: ChatMessage[];
  updatedAt: string;
}

export interface Article {
  id: string;
  slug: string;
  title: string;
  category: string;
  description: string;
  content: string;
  readTime: string;
  publishedAt: string;
  published: boolean;
  authorRole: string;
  tags: string[];
}

export interface SiteSettings {
  adSenseEnabled: boolean;
  adSenseClientId: string;
  maintenanceMode: boolean;
  defaultLanguage: Language;
  allowSignups: boolean;
  bannerNotice: string;
  phonePeNumber: string;
  phonePeUpiId: string;
  phonePeRecipientName: string;
  merchantVerifiedMode: boolean;
}

export type ToolId =
  | 'study'
  | 'writing'
  | 'coding'
  | 'business'
  | 'email'
  | 'social'
  | 'website'
  | 'interview';

export interface ToolMeta {
  id: ToolId;
  name: string;
  nameTe: string;
  tagline: string;
  description: string;
  icon: string;
  placeholder: string;
  presetPrompts: string[];
  options?: {
    label: string;
    key: string;
    values: { label: string; value: string }[];
  }[];
}
