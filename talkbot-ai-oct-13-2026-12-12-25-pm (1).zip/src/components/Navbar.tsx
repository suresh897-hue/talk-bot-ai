import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import { useLanguage } from '../context/LanguageContext';
import { Language } from '../types';
import {
  Sparkles,
  Bot,
  ShieldAlert,
  Moon,
  Sun,
  Menu,
  X,
  LogOut,
  Globe
} from 'lucide-react';

interface NavbarProps {
  currentPage: string;
  setCurrentPage: (page: string) => void;
  language?: Language;
  setLanguage?: (lang: Language) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentPage,
  setCurrentPage,
  language: propLanguage,
  setLanguage: propSetLanguage
}) => {
  const { user, isAdmin, openAuthModal, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const { language: ctxLanguage, setLanguage: ctxSetLanguage, toggleLanguage } = useLanguage();

  const language = propLanguage || ctxLanguage;
  const setLanguage = propSetLanguage || ctxSetLanguage;

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);

  const navItems = [
    { id: 'home', label: language === 'te' ? 'హోమ్' : 'Home' },
    { id: 'chat', label: language === 'te' ? 'AI చాట్' : 'AI Chat' },
    { id: 'tools', label: language === 'te' ? 'AI టూల్స్' : 'AI Tools' },
    { id: 'articles', label: language === 'te' ? 'ఆర్టికల్స్' : 'Articles' },
    { id: 'pricing', label: language === 'te' ? 'ధరలు' : 'Pricing' },
    { id: 'about', label: language === 'te' ? 'గురించి' : 'About' },
    { id: 'contact', label: language === 'te' ? 'సంప్రదించండి' : 'Contact' },
  ];

  const handleNavClick = (pageId: string) => {
    setCurrentPage(pageId);
    setMobileMenuOpen(false);
    setUserDropdownOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="sticky top-0 z-40 w-full backdrop-blur-xl border-b border-amber-500/15 bg-black/80 dark:bg-black/85 text-slate-100 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Brand */}
        <div
          onClick={() => handleNavClick('home')}
          className="flex items-center gap-3 cursor-pointer group"
        >
          <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 via-amber-500 to-amber-700 text-black shadow-md shadow-amber-500/20 group-hover:scale-105 transition-transform">
            <Sparkles className="w-5 h-5 text-black" />
          </div>
          <div className="flex flex-col">
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-lg tracking-wider text-white">
                TALKBOT<span className="text-amber-400 font-black">.AI</span>
              </span>
            </div>
            <span className="text-[10px] tracking-widest uppercase text-amber-300/80 font-medium hidden sm:block">
              Your World. One AI.
            </span>
          </div>
        </div>

        {/* Desktop Navigation Links */}
        <nav className="hidden lg:flex items-center gap-1">
          {navItems.map(item => {
            const isActive = currentPage === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                  isActive
                    ? 'text-amber-300 bg-amber-500/10 border border-amber-500/20 shadow-sm'
                    : 'text-neutral-300 hover:text-white hover:bg-neutral-800/50'
                }`}
              >
                {item.label}
              </button>
            );
          })}
          {isAdmin && (
            <button
              onClick={() => handleNavClick('admin')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all flex items-center gap-1 cursor-pointer ${
                currentPage === 'admin'
                  ? 'text-amber-300 bg-amber-500/15 border border-amber-500/30'
                  : 'text-amber-400/90 hover:text-amber-300 hover:bg-amber-500/10'
              }`}
            >
              <ShieldAlert className="w-3.5 h-3.5" />
              <span>Admin</span>
            </button>
          )}
        </nav>

        {/* Right Action Controls */}
        <div className="hidden sm:flex items-center gap-2.5">
          {/* Language Switcher Toggle */}
          <div className="flex items-center gap-1.5 px-2 py-1 rounded-xl bg-neutral-900/90 border border-amber-500/20 shadow-inner">
            <Globe className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <div className="relative flex items-center p-0.5 rounded-lg bg-black/60 border border-neutral-800 text-[11px] font-semibold">
              <button
                type="button"
                onClick={() => setLanguage('en')}
                aria-pressed={language === 'en'}
                className={`px-2.5 py-1 rounded-md transition-all cursor-pointer flex items-center gap-1 ${
                  language === 'en'
                    ? 'bg-amber-500 text-black font-bold shadow-sm'
                    : 'text-neutral-400 hover:text-white'
                }`}
                title="Switch to English"
              >
                <span>EN</span>
              </button>
              <button
                type="button"
                onClick={() => setLanguage('te')}
                aria-pressed={language === 'te'}
                className={`px-2.5 py-1 rounded-md transition-all cursor-pointer flex items-center gap-1 ${
                  language === 'te'
                    ? 'bg-amber-500 text-black font-bold shadow-sm'
                    : 'text-neutral-400 hover:text-white'
                }`}
                title="తెలుగులోకి మారండి (Telugu)"
              >
                <span>తెలుగు</span>
              </button>
            </div>
          </div>

          {/* Theme Toggle */}
          <button
            onClick={toggleTheme}
            className="p-2 rounded-lg text-neutral-400 hover:text-amber-300 hover:bg-neutral-800 transition-colors cursor-pointer"
            aria-label="Toggle theme"
            title={`Switch to ${theme === 'dark' ? 'Light' : 'Dark'} mode`}
          >
            {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>

          {/* Auth Button / Profile */}
          {user ? (
            <div className="relative">
              <button
                onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                className="flex items-center gap-2 pl-2 pr-3 py-1.5 rounded-xl bg-neutral-900 border border-amber-500/20 hover:border-amber-500/40 transition-colors cursor-pointer"
              >
                <div className="w-6 h-6 rounded-full bg-gradient-to-tr from-amber-500 to-amber-300 text-black text-xs font-bold flex items-center justify-center">
                  {user.name.charAt(0).toUpperCase()}
                </div>
                <span className="text-xs font-medium text-neutral-200 max-w-[100px] truncate">
                  {user.name}
                </span>
              </button>

              {userDropdownOpen && (
                <div className="absolute right-0 mt-2 w-48 rounded-xl bg-neutral-900 border border-amber-500/20 shadow-xl py-1 text-xs text-neutral-200 z-50 animate-in fade-in">
                  <div className="px-3 py-2 border-b border-neutral-800">
                    <p className="font-semibold text-white truncate">{user.name}</p>
                    <p className="text-neutral-400 text-[10px] truncate">{user.email}</p>
                    {isAdmin && (
                      <span className="inline-block mt-1 text-[9px] font-bold tracking-wider uppercase text-amber-400 bg-amber-500/10 px-1.5 py-0.5 rounded">
                        Admin
                      </span>
                    )}
                  </div>
                  {isAdmin && (
                    <button
                      onClick={() => handleNavClick('admin')}
                      className="w-full text-left px-3 py-2 hover:bg-neutral-800 flex items-center gap-2 text-amber-300 cursor-pointer"
                    >
                      <ShieldAlert className="w-3.5 h-3.5" />
                      <span>Admin Dashboard</span>
                    </button>
                  )}
                  <button
                    onClick={() => handleNavClick('pricing')}
                    className="w-full text-left px-3 py-2 hover:bg-neutral-800 flex items-center justify-between text-neutral-200 cursor-pointer"
                  >
                    <span className="flex items-center gap-2">
                      <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                      <span>Subscription</span>
                    </span>
                    {user.subscription?.status === 'active' && !user.subscription.isExpired ? (
                      <span className="text-[10px] text-emerald-400 font-bold bg-emerald-950/60 px-1.5 py-0.5 rounded border border-emerald-500/30">
                        {user.subscription.daysRemaining}d left
                      </span>
                    ) : user.subscription?.status === 'pending_verification' ? (
                      <span className="text-[10px] text-amber-300 font-bold bg-amber-950/60 px-1.5 py-0.5 rounded border border-amber-500/30">
                        Pending
                      </span>
                    ) : user.subscription?.status === 'expired' ? (
                      <span className="text-[10px] text-red-400 font-bold bg-red-950/60 px-1.5 py-0.5 rounded border border-red-500/30">
                        Renew
                      </span>
                    ) : (
                      <span className="text-[10px] text-neutral-400">View Plans</span>
                    )}
                  </button>
                  <button
                    onClick={() => handleNavClick('chat')}
                    className="w-full text-left px-3 py-2 hover:bg-neutral-800 flex items-center gap-2 cursor-pointer"
                  >
                    <Bot className="w-3.5 h-3.5" />
                    <span>My AI Chats</span>
                  </button>
                  <button
                    onClick={() => {
                      logout();
                      setUserDropdownOpen(false);
                    }}
                    className="w-full text-left px-3 py-2 hover:bg-neutral-800 text-red-400 flex items-center gap-2 border-t border-neutral-800 cursor-pointer"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>Sign Out</span>
                  </button>
                </div>
              )}
            </div>
          ) : (
            <button
              onClick={() => openAuthModal('login')}
              className="py-1.5 px-3.5 rounded-xl gold-gradient-bg text-black font-bold text-xs hover:brightness-110 active:scale-[0.98] transition-all cursor-pointer shadow-sm shadow-amber-500/20"
            >
              Sign In
            </button>
          )}
        </div>

        {/* Mobile top controls (language toggle + menu) */}
        <div className="flex items-center gap-2 lg:hidden">
          {/* Mobile Language Switcher Toggle */}
          <button
            type="button"
            onClick={toggleLanguage}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-neutral-900 border border-amber-500/30 text-amber-300 text-xs font-semibold cursor-pointer active:scale-95 transition-all shadow-sm"
            title={language === 'en' ? 'తెలుగులోకి మారండి' : 'Switch to English'}
            aria-label="Toggle language"
          >
            <Globe className="w-3.5 h-3.5 text-amber-400" />
            <span>{language === 'en' ? 'తెలుగు' : 'EN'}</span>
          </button>

          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 rounded-lg text-neutral-300 hover:text-white hover:bg-neutral-800 transition-colors cursor-pointer"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-b border-amber-500/15 bg-neutral-950 px-4 pt-2 pb-6 space-y-3 animate-in slide-in-from-top-2">
          {/* Mobile Language Switcher Panel */}
          <div className="flex items-center justify-between p-2.5 rounded-xl bg-neutral-900/80 border border-neutral-800">
            <div className="flex items-center gap-2 text-xs text-neutral-300">
              <Globe className="w-4 h-4 text-amber-400" />
              <span>{language === 'te' ? 'భాష (Language)' : 'Language'}</span>
            </div>
            <div className="flex items-center p-0.5 rounded-lg bg-black/60 border border-neutral-800 text-xs font-semibold">
              <button
                type="button"
                onClick={() => setLanguage('en')}
                className={`px-3 py-1 rounded-md transition-all cursor-pointer ${
                  language === 'en'
                    ? 'bg-amber-500 text-black font-bold shadow-sm'
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                English
              </button>
              <button
                type="button"
                onClick={() => setLanguage('te')}
                className={`px-3 py-1 rounded-md transition-all cursor-pointer ${
                  language === 'te'
                    ? 'bg-amber-500 text-black font-bold shadow-sm'
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                తెలుగు
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-1.5 pt-1">
            {navItems.map(item => (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`text-left px-3 py-2.5 rounded-lg text-xs font-semibold cursor-pointer ${
                  currentPage === item.id
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                    : 'text-neutral-300 hover:bg-neutral-900'
                }`}
              >
                {item.label}
              </button>
            ))}
            {isAdmin && (
              <button
                onClick={() => handleNavClick('admin')}
                className="text-left px-3 py-2.5 rounded-lg text-xs font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/20 flex items-center gap-1.5 cursor-pointer"
              >
                <ShieldAlert className="w-3.5 h-3.5" />
                <span>Admin Dashboard</span>
              </button>
            )}
          </div>

          <div className="pt-3 border-t border-neutral-800 flex items-center justify-between">
            <button
              onClick={toggleTheme}
              className="p-2 rounded-lg bg-neutral-900 border border-neutral-800 text-neutral-300 flex items-center gap-2 text-xs cursor-pointer"
            >
              {theme === 'dark' ? <Sun className="w-3.5 h-3.5" /> : <Moon className="w-3.5 h-3.5" />}
              <span>{theme === 'dark' ? 'Light Mode' : 'Dark Mode'}</span>
            </button>

            {user ? (
              <button
                onClick={() => {
                  logout();
                  setMobileMenuOpen(false);
                }}
                className="px-3 py-2 text-xs text-red-400 font-semibold bg-red-950/30 rounded-lg border border-red-500/20 cursor-pointer"
              >
                Sign Out ({user.name})
              </button>
            ) : (
              <button
                onClick={() => {
                  openAuthModal('login');
                  setMobileMenuOpen(false);
                }}
                className="px-4 py-2 text-xs font-bold gold-gradient-bg text-black rounded-lg cursor-pointer"
              >
                Sign In
              </button>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
