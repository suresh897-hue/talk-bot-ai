import React from 'react';
import { Sparkles, Crown } from 'lucide-react';
import { Language } from '../types';

interface FooterProps {
  setCurrentPage: (page: string) => void;
  language: Language;
}

export const Footer: React.FC<FooterProps> = ({ setCurrentPage, language }) => {
  const handleNav = (page: string) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="w-full border-t border-amber-500/15 bg-black/95 text-neutral-400 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-12">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-8 mb-10">
          {/* Brand Info */}
          <div className="md:col-span-2 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-gradient-to-br from-amber-400 via-amber-500 to-amber-600 text-black font-bold shadow-md shadow-amber-500/20">
                <Sparkles className="w-4 h-4" />
              </div>
              <span className="font-extrabold text-base tracking-wider text-white">
                TALKBOT<span className="text-amber-400">.AI</span>
              </span>
            </div>
            <p className="text-neutral-400 text-xs leading-relaxed max-w-sm">
              Your World. One AI. Next-generation artificial intelligence platform powered by Google Gemini.
              Empowering education, engineering, literature, and global enterprise in English and Telugu.
            </p>
            <div className="flex items-center gap-2 text-[11px] text-neutral-500">
              <span>English & Telugu Conversational Intelligence</span>
              <span aria-hidden="true">·</span>
              <span>Gemini 3.8 Flash</span>
            </div>
          </div>

          {/* Core Navigation */}
          <div>
            <h4 className="font-bold text-white uppercase text-[11px] tracking-wider mb-3 text-amber-300">
              Explore
            </h4>
            <ul className="space-y-2">
              <li>
                <button onClick={() => handleNav('home')} className="hover:text-amber-400 transition-colors cursor-pointer">
                  {language === 'te' ? 'హోమ్' : 'Home'}
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('chat')} className="hover:text-amber-400 transition-colors cursor-pointer">
                  {language === 'te' ? 'AI చాట్' : 'AI Chat'}
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('tools')} className="hover:text-amber-400 transition-colors cursor-pointer">
                  {language === 'te' ? 'AI టూల్స్' : 'AI Tools'}
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('articles')} className="hover:text-amber-400 transition-colors cursor-pointer">
                  {language === 'te' ? 'నాలెడ్జ్ ఆర్టికల్స్' : 'Articles & Guides'}
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('pricing')} className="hover:text-amber-400 transition-colors cursor-pointer">
                  {language === 'te' ? 'ధరల ప్రణాళిక' : 'Pricing (₹0 Free)'}
                </button>
              </li>
            </ul>
          </div>

          {/* AI Tools Suite */}
          <div>
            <h4 className="font-bold text-white uppercase text-[11px] tracking-wider mb-3 text-amber-300">
              Assistants
            </h4>
            <ul className="space-y-2">
              <li>
                <button onClick={() => handleNav('tools')} className="hover:text-amber-400 transition-colors cursor-pointer">
                  Study Assistant
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('tools')} className="hover:text-amber-400 transition-colors cursor-pointer">
                  Writing Assistant
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('tools')} className="hover:text-amber-400 transition-colors cursor-pointer">
                  Coding Assistant
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('tools')} className="hover:text-amber-400 transition-colors cursor-pointer">
                  Business Ideas Assistant
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('tools')} className="hover:text-amber-400 transition-colors cursor-pointer">
                  Interview Practice Coach
                </button>
              </li>
            </ul>
          </div>

          {/* Company & Legal */}
          <div>
            <h4 className="font-bold text-white uppercase text-[11px] tracking-wider mb-3 text-amber-300">
              Legal & Support
            </h4>
            <ul className="space-y-2">
              <li>
                <button onClick={() => handleNav('about')} className="hover:text-amber-400 transition-colors cursor-pointer">
                  About TalkBot AI
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('contact')} className="hover:text-amber-400 transition-colors cursor-pointer">
                  Contact Us
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('privacy')} className="hover:text-amber-400 transition-colors cursor-pointer">
                  Privacy Policy
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('terms')} className="hover:text-amber-400 transition-colors cursor-pointer">
                  Terms & Conditions
                </button>
              </li>
            </ul>
          </div>
        </div>

        {/* Dedicated Founder & CEO Credit Section */}
        <div className="py-6 my-6 border-y border-neutral-900/80 bg-neutral-950/60 rounded-2xl px-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
              <Crown className="w-5 h-5" />
            </div>
            <div>
              <p className="text-[11px] uppercase tracking-wider text-amber-400 font-bold">
                Leadership
              </p>
              <h3 className="text-sm font-bold text-white tracking-wide">
                MAANEESH
              </h3>
              <p className="text-xs text-amber-300 font-semibold">
                Founder & CEO — TalkBot AI
              </p>
            </div>
          </div>
          <div className="text-left sm:text-right">
            <span className="text-xs font-bold text-white tracking-wider">
              TALKBOT AI
            </span>
            <p className="text-[11px] text-amber-300/80 font-medium">
              “Your World. One AI.”
            </p>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-4 flex flex-col sm:flex-row items-center justify-between gap-4 text-neutral-500 text-[11px]">
          <p>© {new Date().getFullYear()} TALKBOT AI. All rights reserved. “Your World. One AI.”</p>
          <div className="flex items-center gap-3">
            <span>Server-side Google Gemini Integration</span>
            <span aria-hidden="true">·</span>
            <span>Zero Data Selling</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
