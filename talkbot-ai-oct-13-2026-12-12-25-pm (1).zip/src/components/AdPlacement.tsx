import React from 'react';

interface AdPlacementProps {
  slotId?: string;
  format?: 'horizontal' | 'rectangle' | 'sidebar';
  className?: string;
}

export const AdPlacement: React.FC<AdPlacementProps> = ({
  slotId = 'default',
  format = 'horizontal',
  className = ''
}) => {
  return (
    <div
      className={`relative w-full rounded-xl border border-dashed border-amber-500/20 bg-amber-500/[0.02] p-4 text-center transition-all ${
        format === 'horizontal' ? 'min-h-[90px]' : format === 'sidebar' ? 'min-h-[250px]' : 'min-h-[160px]'
      } flex flex-col items-center justify-center ${className}`}
      aria-label="Advertisement placeholder"
    >
      <div className="flex items-center gap-2 text-[11px] font-medium uppercase tracking-wider text-amber-500/60">
        <span>Google AdSense Placement Area</span>
        <span aria-hidden="true">·</span>
        <span>Slot ID: {slotId}</span>
      </div>
      <p className="mt-1 text-xs text-neutral-400 dark:text-neutral-500 max-w-md">
        Reserved responsive container for Google AdSense integration. Compliant placement space ready for verified publisher tags.
      </p>
    </div>
  );
};
