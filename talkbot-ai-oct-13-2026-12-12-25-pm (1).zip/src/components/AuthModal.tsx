import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { X, Lock, Mail, User as UserIcon, AlertCircle, CheckCircle, ShieldCheck } from 'lucide-react';

export const AuthModal: React.FC = () => {
  const { authModalOpen, authModalView, closeAuthModal, openAuthModal, login, register, resetPassword } = useAuth();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  if (!authModalOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);
    setLoading(true);

    try {
      if (authModalView === 'login') {
        await login(email, password);
        setEmail('');
        setPassword('');
      } else if (authModalView === 'register') {
        if (!name.trim()) throw new Error('Please enter your full name');
        if (password.length < 6) throw new Error('Password must be at least 6 characters long');
        await register(name, email, password);
        setName('');
        setEmail('');
        setPassword('');
      } else if (authModalView === 'forgot') {
        const msg = await resetPassword(email, password);
        setSuccess(msg);
      }
    } catch (err: any) {
      setError(err?.message || 'Authentication operation failed. Please check inputs.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-md rounded-2xl border border-amber-500/30 bg-[#0E0E12] dark:bg-[#0E0E12] p-6 md:p-8 shadow-2xl text-slate-100">
        {/* Close Button */}
        <button
          onClick={closeAuthModal}
          className="absolute top-4 right-4 p-2 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800/60 transition-colors cursor-pointer"
          aria-label="Close authentication modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-amber-500/10 border border-amber-500/30 mb-3 text-amber-400">
            <Lock className="w-5 h-5" />
          </div>
          <h2 className="text-2xl font-bold tracking-tight text-white">
            {authModalView === 'login' && 'Sign In to TalkBot AI'}
            {authModalView === 'register' && 'Create Your Account'}
            {authModalView === 'forgot' && 'Reset Account Password'}
          </h2>
          <p className="text-xs text-neutral-400 mt-1">
            {authModalView === 'login' && 'Access private chat sessions, custom assistants, and saved history.'}
            {authModalView === 'register' && 'Join TalkBot AI. Free forever tier with Google Gemini intelligence.'}
            {authModalView === 'forgot' && 'Enter your registered email and choose a new secure password.'}
          </p>
        </div>

        {/* Error / Success Notices */}
        {error && (
          <div className="mb-4 flex items-center gap-2.5 p-3 rounded-lg bg-red-950/40 border border-red-500/40 text-red-200 text-xs">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
            <span>{error}</span>
          </div>
        )}

        {success && (
          <div className="mb-4 flex items-center gap-2.5 p-3 rounded-lg bg-emerald-950/40 border border-emerald-500/40 text-emerald-200 text-xs">
            <CheckCircle className="w-4 h-4 shrink-0 text-emerald-400" />
            <span>{success}</span>
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {authModalView === 'register' && (
            <div>
              <label className="block text-xs font-medium text-neutral-300 mb-1.5">Full Name</label>
              <div className="relative">
                <UserIcon className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" />
                <input
                  type="text"
                  required
                  value={name}
                  onChange={e => setName(e.target.value)}
                  placeholder="Alex Mercer"
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 focus:border-amber-500/60 focus:ring-1 focus:ring-amber-500/60 text-sm text-white placeholder-neutral-500 transition-all outline-none"
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-medium text-neutral-300 mb-1.5">Email Address</label>
            <div className="relative">
              <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" />
              <input
                type="email"
                required
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="name@example.com"
                className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 focus:border-amber-500/60 focus:ring-1 focus:ring-amber-500/60 text-sm text-white placeholder-neutral-500 transition-all outline-none"
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-medium text-neutral-300">
                {authModalView === 'forgot' ? 'New Password' : 'Password'}
              </label>
              {authModalView === 'login' && (
                <button
                  type="button"
                  onClick={() => openAuthModal('forgot')}
                  className="text-[11px] text-amber-400/80 hover:text-amber-300 transition-colors cursor-pointer"
                >
                  Forgot password?
                </button>
              )}
            </div>
            <div className="relative">
              <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" />
              <input
                type="password"
                required
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="••••••••"
                minLength={6}
                className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 focus:border-amber-500/60 focus:ring-1 focus:ring-amber-500/60 text-sm text-white placeholder-neutral-500 transition-all outline-none"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-2.5 px-4 rounded-xl gold-gradient-bg text-black font-semibold text-sm hover:brightness-110 active:scale-[0.99] transition-all disabled:opacity-50 cursor-pointer shadow-lg shadow-amber-500/10 mt-2"
          >
            {loading ? 'Processing...' : (
              authModalView === 'login' ? 'Sign In' :
              authModalView === 'register' ? 'Create Account' :
              'Reset Password'
            )}
          </button>
        </form>

        {/* Switch view */}
        <div className="mt-6 pt-4 border-t border-neutral-800 text-center text-xs text-neutral-400">
          {authModalView === 'login' ? (
            <p>
              Don't have an account?{' '}
              <button
                type="button"
                onClick={() => openAuthModal('register')}
                className="text-amber-400 font-medium hover:underline cursor-pointer"
              >
                Sign up free
              </button>
            </p>
          ) : authModalView === 'register' ? (
            <p>
              Already have an account?{' '}
              <button
                type="button"
                onClick={() => openAuthModal('login')}
                className="text-amber-400 font-medium hover:underline cursor-pointer"
              >
                Sign in
              </button>
            </p>
          ) : (
            <p>
              Remembered your password?{' '}
              <button
                type="button"
                onClick={() => openAuthModal('login')}
                className="text-amber-400 font-medium hover:underline cursor-pointer"
              >
                Back to sign in
              </button>
            </p>
          )}
        </div>

        <div className="mt-4 flex items-center justify-center gap-1.5 text-[11px] text-neutral-500">
          <ShieldCheck className="w-3.5 h-3.5 text-amber-500/70" />
          <span>Encrypted with SHA-512 PBKDF2 salting. Private data stays secure.</span>
        </div>
      </div>
    </div>
  );
};
