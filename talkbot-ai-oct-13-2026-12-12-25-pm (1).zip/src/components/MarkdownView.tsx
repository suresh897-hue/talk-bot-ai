import React, { useState } from 'react';
import { Check, Copy } from 'lucide-react';

interface MarkdownViewProps {
  content: string;
  className?: string;
}

export const MarkdownView: React.FC<MarkdownViewProps> = ({ content, className = '' }) => {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  const copyCode = (code: string, idx: number) => {
    navigator.clipboard.writeText(code);
    setCopiedIndex(idx);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const renderFormatted = () => {
    const lines = content.split('\n');
    const elements: React.ReactNode[] = [];
    let inCodeBlock = false;
    let codeBuffer: string[] = [];
    let codeLanguage = '';
    let blockIndex = 0;

    let inTable = false;
    let tableRows: string[][] = [];
    let tableHeaders: string[] = [];

    const flushTable = (keyIndex: number) => {
      if (!inTable) return;
      if (tableHeaders.length > 0 || tableRows.length > 0) {
        elements.push(
          <div key={`table-wrapper-${keyIndex}`} className="my-4 overflow-x-auto rounded-xl border border-amber-500/20 bg-neutral-950/80 shadow-md">
            <table className="w-full text-left text-xs sm:text-sm text-neutral-200 border-collapse">
              {tableHeaders.length > 0 && (
                <thead className="bg-neutral-900 border-b border-amber-500/30 text-amber-300 font-bold uppercase text-[11px] tracking-wider">
                  <tr>
                    {tableHeaders.map((th, thi) => (
                      <th key={thi} className="px-4 py-2.5 font-bold">
                        {formatInline(th.trim())}
                      </th>
                    ))}
                  </tr>
                </thead>
              )}
              <tbody className="divide-y divide-neutral-800/60">
                {tableRows.map((row, ri) => (
                  <tr key={ri} className="hover:bg-amber-500/5 transition-colors">
                    {row.map((cell, ci) => (
                      <td key={ci} className="px-4 py-2 text-neutral-300">
                        {formatInline(cell.trim())}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        );
      }
      inTable = false;
      tableHeaders = [];
      tableRows = [];
    };

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];

      // Code blocks
      if (line.startsWith('```')) {
        flushTable(i);
        if (inCodeBlock) {
          const codeString = codeBuffer.join('\n');
          const currentIdx = blockIndex++;
          elements.push(
            <div key={`code-${currentIdx}`} className="my-4 rounded-xl overflow-hidden border border-amber-500/25 bg-black/95 font-mono text-xs md:text-sm shadow-xl">
              <div className="flex items-center justify-between px-4 py-2 bg-neutral-900/90 border-b border-amber-500/15 text-neutral-400">
                <span className="text-[10px] uppercase tracking-wider text-amber-400 font-bold">
                  {codeLanguage || 'CODE'}
                </span>
                <button
                  type="button"
                  onClick={() => copyCode(codeString, currentIdx)}
                  className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-neutral-800 hover:bg-neutral-700 text-neutral-200 transition-colors text-xs cursor-pointer active:scale-95"
                  title="Copy code"
                >
                  {copiedIndex === currentIdx ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-emerald-400 font-medium">Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5 text-neutral-400" />
                      <span>Copy Code</span>
                    </>
                  )}
                </button>
              </div>
              <pre className="p-4 overflow-x-auto text-amber-100/90 leading-relaxed font-mono selection:bg-amber-500/30">
                <code>{codeString}</code>
              </pre>
            </div>
          );
          inCodeBlock = false;
          codeBuffer = [];
          codeLanguage = '';
        } else {
          inCodeBlock = true;
          codeLanguage = line.replace('```', '').trim();
        }
        continue;
      }

      if (inCodeBlock) {
        codeBuffer.push(line);
        continue;
      }

      // Check table row (| col | col |)
      if (line.trim().startsWith('|') && line.trim().endsWith('|')) {
        const rawCells = line.trim().split('|').slice(1, -1);
        const isSeparator = rawCells.every(c => /^[\s-:]+$/.test(c));

        if (isSeparator) {
          // Separator line between header and body
          inTable = true;
        } else if (!inTable && tableHeaders.length === 0) {
          // First row is headers
          tableHeaders = rawCells;
          inTable = true;
        } else {
          // Data row
          tableRows.push(rawCells);
        }
        continue;
      } else if (inTable) {
        flushTable(i);
      }

      // Headers
      if (line.startsWith('### ')) {
        elements.push(
          <h3 key={`h3-${i}`} className="text-base sm:text-lg font-bold text-amber-300 mt-4 mb-2 tracking-tight">
            {formatInline(line.replace('### ', ''))}
          </h3>
        );
      } else if (line.startsWith('## ')) {
        elements.push(
          <h2 key={`h2-${i}`} className="text-lg sm:text-xl font-extrabold text-amber-400 mt-5 mb-2 pb-1 border-b border-amber-500/20 tracking-tight">
            {formatInline(line.replace('## ', ''))}
          </h2>
        );
      } else if (line.startsWith('# ')) {
        elements.push(
          <h1 key={`h1-${i}`} className="text-xl sm:text-2xl font-black text-amber-400 mt-6 mb-3 tracking-tight">
            {formatInline(line.replace('# ', ''))}
          </h1>
        );
      } else if (line.startsWith('> ')) {
        // Blockquote
        elements.push(
          <blockquote key={`quote-${i}`} className="my-2.5 pl-4 border-l-2 border-amber-500/60 text-neutral-300 italic text-xs sm:text-sm bg-neutral-900/40 py-1 rounded-r-lg">
            {formatInline(line.replace('> ', ''))}
          </blockquote>
        );
      } else if (line.startsWith('- ') || line.startsWith('* ')) {
        elements.push(
          <li key={`li-${i}`} className="ml-5 list-disc my-1 text-inherit leading-relaxed">
            {formatInline(line.substring(2))}
          </li>
        );
      } else if (/^\d+\.\s/.test(line)) {
        const match = line.match(/^(\d+)\.\s(.*)/);
        if (match) {
          elements.push(
            <div key={`ol-${i}`} className="flex gap-2.5 my-1.5 ml-1 text-inherit leading-relaxed">
              <span className="font-bold text-amber-400 text-xs sm:text-sm">{match[1]}.</span>
              <span className="flex-1">{formatInline(match[2])}</span>
            </div>
          );
        }
      } else if (line.trim() === '') {
        elements.push(<div key={`space-${i}`} className="h-2" />);
      } else {
        elements.push(
          <p key={`p-${i}`} className="my-1.5 leading-relaxed text-inherit break-words">
            {formatInline(line)}
          </p>
        );
      }
    }

    flushTable(lines.length);

    if (inCodeBlock && codeBuffer.length > 0) {
      elements.push(
        <pre key="unclosed-code" className="p-3 my-2 rounded bg-neutral-900 overflow-x-auto text-xs text-neutral-200">
          <code>{codeBuffer.join('\n')}</code>
        </pre>
      );
    }

    return elements;
  };

  const formatInline = (text: string): React.ReactNode => {
    // Regex matches:
    // 1: Bold **text**
    // 2: Inline code `code`
    // 3: Markdown link [label](url)
    // 4: Italic *text* or _text_
    const regex = /(\*\*.*?\*\*|`.*?`|\[.*?\]\(https?:\/\/.*?\)|\*.*?\*|_.*?_)/g;
    const parts = text.split(regex);

    return parts.map((part, index) => {
      if (!part) return null;

      // Bold
      if (part.startsWith('**') && part.endsWith('**') && part.length >= 4) {
        return (
          <strong key={index} className="font-bold text-amber-200">
            {part.slice(2, -2)}
          </strong>
        );
      }

      // Inline code
      if (part.startsWith('`') && part.endsWith('`') && part.length >= 2) {
        return (
          <code key={index} className="px-1.5 py-0.5 mx-0.5 rounded bg-amber-500/10 text-amber-300 font-mono text-xs border border-amber-500/20">
            {part.slice(1, -1)}
          </code>
        );
      }

      // Safe Links [label](url)
      const linkMatch = part.match(/^\[(.*?)\]\((https?:\/\/.*?)\)$/);
      if (linkMatch) {
        const [, label, url] = linkMatch;
        return (
          <a
            key={index}
            href={url}
            target="_blank"
            rel="noopener noreferrer"
            className="text-amber-400 hover:text-amber-300 underline underline-offset-2 transition-colors cursor-pointer"
          >
            {label}
          </a>
        );
      }

      // Italic *text* or _text_
      if (
        ((part.startsWith('*') && part.endsWith('*')) || (part.startsWith('_') && part.endsWith('_'))) &&
        part.length >= 3
      ) {
        return (
          <em key={index} className="italic text-neutral-300">
            {part.slice(1, -1)}
          </em>
        );
      }

      return part;
    });
  };

  return (
    <div className={`markdown-content space-y-1 text-inherit break-words overflow-wrap-anywhere ${className}`}>
      {renderFormatted()}
    </div>
  );
};
