import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const isProd = process.env.NODE_ENV === 'production';
const PORT = Number(process.env.PORT) || 3000;
const ADMIN_EMAIL = process.env.ADMIN_EMAIL || 'suresh897@gmail.com';

const app = express();
app.use(express.json({ limit: '5mb' }));

// Initialize persistent data directory
const DATA_DIR = path.resolve(__dirname, '.data');
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}
const DB_FILE = path.resolve(DATA_DIR, 'db.json');

interface UserSubscriptionRecord {
  planId: 'basic' | 'starter' | 'pro' | 'premium' | 'ultimate';
  planName: string;
  amount: number;
  status: 'pending_verification' | 'active' | 'expired' | 'rejected';
  phonePeTransactionId: string;
  customerPhone?: string;
  createdAt: string;
  verifiedAt?: string;
  expiresAt?: string;
  notes?: string;
}

interface UserRecord {
  id: string;
  email: string;
  name: string;
  passwordHash: string;
  salt: string;
  role: 'admin' | 'user';
  createdAt: string;
  subscription?: UserSubscriptionRecord;
}

interface SubscriptionOrder {
  id: string;
  userId: string;
  userEmail: string;
  userName: string;
  planId: 'basic' | 'starter' | 'pro' | 'premium' | 'ultimate';
  planName: string;
  amount: number;
  phonePeTransactionId: string;
  customerPhone?: string;
  status: 'pending_verification' | 'active' | 'expired' | 'rejected';
  createdAt: string;
  verifiedAt?: string;
  expiresAt?: string;
  notes?: string;
}

interface ArticleRecord {
  id: string;
  slug: string;
  title: string;
  category: string;
  description: string;
  content: string;
  readTime: string;
  publishedAt: string;
  published: boolean;
  authorRole: string;
  tags: string[];
}

interface SiteSettings {
  adSenseEnabled: boolean;
  adSenseClientId: string;
  maintenanceMode: boolean;
  defaultLanguage: 'en' | 'te';
  allowSignups: boolean;
  bannerNotice: string;
  phonePeNumber: string;
  phonePeUpiId: string;
  phonePeRecipientName: string;
  merchantVerifiedMode: boolean;
}

interface ChatHistoryItem {
  id: string;
  userId: string;
  title: string;
  messages: Array<{
    id: string;
    role: 'user' | 'model';
    content: string;
    timestamp: string;
    language?: 'en' | 'te';
  }>;
  updatedAt: string;
}

interface DatabaseSchema {
  users: UserRecord[];
  articles: ArticleRecord[];
  settings: SiteSettings;
  subscriptions: SubscriptionOrder[];
  chatHistories: Record<string, ChatHistoryItem[]>; // keyed by userId
  sessions: Record<string, { userId: string; email: string; role: 'admin' | 'user'; expiresAt: number }>;
}

// Initial seed articles (original, high-value, realistic educational content)
const INITIAL_ARTICLES: ArticleRecord[] = [
  {
    id: 'art-1',
    slug: 'mastering-gemini-multilingual-prompt-engineering',
    title: 'Mastering Multilingual AI: How Telugu & English Prompting Works in Modern LLMs',
    category: 'AI & Machine Learning',
    description: 'An architectural exploration of cross-lingual tokenization, cultural semantics, and how Gemini processes Indian languages with precision.',
    content: `## The Modern Cross-Lingual Paradigm\n\nNatural Language Processing (NLP) has made quantum leaps over the last three years. Previously, non-Latin scripts such as Telugu (తెలుగు) suffered from significant sub-token fragmentation, causing higher latency and degraded reasoning.\n\n### Why Token Efficiency Matters in Telugu\nIn early generative models, Indic characters often required 4 to 8 byte-level tokens per single syllable (అక్షరం). Modern multimodal architectures like Google Gemini employ extensive byte-pair encodings optimized for global scripts. This reduces token overhead by over 60%, allowing rich conversational nuances in Telugu such as sandhi rules, honorifics, and dialectical vocabulary.\n\n### Practical Prompt Engineering Guidelines\n1. **Specify Grammar & Tone:** Clarify whether you expect formal (*గౌరవప్రదమైన శైలి*) or conversational Telugu.\n2. **Hybrid Script Handling:** Gemini seamlessly understands Tenglish (Telugu transliterated into English script) as well as pure Telugu script.\n3. **Domain Grounding:** For technical explanations, request standard Telugu terminology supplemented with parenthetical English technical terms (e.g., *కంప్యూటర్ ప్రోగ్రామింగ్ (Computer Programming)*) for maximum clarity.`,
    readTime: '5 min read',
    publishedAt: '2026-03-15',
    published: true,
    authorRole: 'TalkBot Engineering Group',
    tags: ['Gemini', 'Telugu NLP', 'Prompt Engineering', 'AI Architecture']
  },
  {
    id: 'art-2',
    slug: 'building-resilient-web-applications-zero-budget',
    title: 'Building Resilient Full-Stack Web Apps on a Zero-Dollar Budget',
    category: 'Web Development',
    description: 'Practical strategies for deploying production-grade React and Node.js applications using generous free tiers without vendor lock-in.',
    content: `## The Art of Zero-Cost Infrastructure\n\nBootstrapping modern web services no longer demands enterprise capital. By leveraging cloud runtimes, server-side streaming, and lightweight persistent storage, developers can deliver sub-100ms global response times at zero operational cost.\n\n### Core Tenets of Frugal Architecture\n- **Client-Side Heavy, Server-Side Light:** Offload rendering and state management to client React bundles. Restrict server workloads strictly to credential safeguarding and API orchestration.\n- **Zero-Secret Client Bundles:** Never bundle API tokens into frontend JavaScript. Always proxy outbound third-party requests through an authenticated or rate-limited Express tier.\n- **Smart In-Memory & File Caching:** For static catalogs, articles, and configuration parameters, rely on zero-latency memory caches rather than making redundant external database roundtrips.\n\n### Error Resilience and Graceful Fallbacks\nAlways design frontends to gracefully communicate rate limits and quota windows. Providing transparent system state cultivates long-term user trust.`,
    readTime: '6 min read',
    publishedAt: '2026-03-28',
    published: true,
    authorRole: 'TalkBot Systems Team',
    tags: ['Architecture', 'Node.js', 'React', 'DevOps']
  },
  {
    id: 'art-3',
    slug: 'essential-clean-code-principles-2026',
    title: 'Clean Code in the AI Era: Why Architecture Matters More Than Ever',
    category: 'Software Engineering',
    description: 'Why software engineering fundamentals, typing discipline, and system boundaries remain vital when developing alongside AI code generators.',
    content: `## The AI Accelerant\n\nAs AI code assistants generate larger percentages of baseline software, the primary bottleneck in engineering has shifted from code generation to system architecture, verification, and maintainability.\n\n### Key Principles for Modern Codebases\n1. **Strict Type Contracts:** Leverage TypeScript strict mode and exhaustiveness checks. Strong contracts prevent silent runtime drift.\n2. **Defensive API Boundaries:** Validate external API payloads and inputs at the system perimeter.\n3. **Modular Component Isolation:** Keep UI components focused on a single responsibility. Business logic and backend calls should remain cleanly decoupled in dedicated service hooks or controllers.\n\nCode written cleanly is easier for both humans and AI models to inspect, extend, and refactor.`,
    readTime: '4 min read',
    publishedAt: '2026-04-02',
    published: true,
    authorRole: 'TalkBot Editorial Group',
    tags: ['TypeScript', 'Clean Code', 'Best Practices']
  }
];

function loadDatabase(): DatabaseSchema {
  const defaultSettings: SiteSettings = {
    adSenseEnabled: false,
    adSenseClientId: '',
    maintenanceMode: false,
    defaultLanguage: 'en',
    allowSignups: true,
    bannerNotice: '',
    phonePeNumber: process.env.PHONEPE_CONTACT_NUMBER || '9876543210',
    phonePeUpiId: process.env.PHONEPE_UPI_ID || 'talkbot@ybl',
    phonePeRecipientName: 'TALKBOT AI (Maaneesh)',
    merchantVerifiedMode: false
  };

  if (!fs.existsSync(DB_FILE)) {
    const initial: DatabaseSchema = {
      users: [],
      articles: INITIAL_ARTICLES,
      settings: defaultSettings,
      subscriptions: [],
      chatHistories: {},
      sessions: {}
    };
    fs.writeFileSync(DB_FILE, JSON.stringify(initial, null, 2), 'utf-8');
    return initial;
  }
  try {
    const raw = fs.readFileSync(DB_FILE, 'utf-8');
    const parsed = JSON.parse(raw);
    if (!parsed.articles || parsed.articles.length === 0) {
      parsed.articles = INITIAL_ARTICLES;
    }
    parsed.subscriptions = Array.isArray(parsed.subscriptions) ? parsed.subscriptions : [];
    parsed.settings = {
      ...defaultSettings,
      ...(parsed.settings || {})
    };
    return parsed;
  } catch (e) {
    console.error('Failed to parse db.json, resetting with defaults', e);
    return {
      users: [],
      articles: INITIAL_ARTICLES,
      settings: defaultSettings,
      subscriptions: [],
      chatHistories: {},
      sessions: {}
    };
  }
}

function saveDatabase(db: DatabaseSchema) {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), 'utf-8');
  } catch (e) {
    console.error('Failed to write db.json', e);
  }
}

let db = loadDatabase();

// Cryptographic helpers
function hashPassword(password: string, salt: string): string {
  return crypto.pbkdf2Sync(password, salt, 10000, 64, 'sha512').toString('hex');
}

function generateSalt(): string {
  return crypto.randomBytes(16).toString('hex');
}

function generateToken(): string {
  return crypto.randomBytes(32).toString('hex');
}

// Authentication middleware
function authenticate(req: express.Request, res: express.Response, next: express.NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Unauthorized: Missing or invalid token' });
  }
  const token = authHeader.substring(7);
  const session = db.sessions[token];
  if (!session || session.expiresAt < Date.now()) {
    return res.status(401).json({ error: 'Session expired or invalid. Please log in again.' });
  }
  (req as any).user = session;
  next();
}

function requireAdmin(req: express.Request, res: express.Response, next: express.NextFunction) {
  const user = (req as any).user;
  if (!user || user.role !== 'admin') {
    return res.status(403).json({ error: 'Forbidden: Administrator credentials required' });
  }
  next();
}

// -------------------------------------------------------------
// Official TalkBot AI Subscription Plans (30 Days / Month via PhonePe)
// -------------------------------------------------------------
const SUBSCRIPTION_PLANS = [
  {
    id: 'basic',
    name: 'Basic',
    nameTe: 'బేసిక్ ప్లాన్',
    price: 19,
    billingPeriod: '/month',
    daysDuration: 30,
    badge: 'Starter Choice',
    features: [
      'Full Access to TALKBOT AI Chat',
      'Fluent Telugu & English Bilingual Intelligence',
      'Google Gemini Neural Reasoning',
      '30 Days Unlocked Access',
      'Encrypted Private Chat History',
      'Single Device Access'
    ]
  },
  {
    id: 'starter',
    name: 'Starter',
    nameTe: 'స్టార్టర్ ప్లాన్',
    price: 39,
    billingPeriod: '/month',
    daysDuration: 30,
    badge: 'Popular for Students',
    features: [
      'Everything in Basic Plan',
      '4 Specialized AI Engines (Study, Code, Writing, Business)',
      'Extended Response Lengths',
      '30 Days Verified Access',
      'Clean Ad-Free Experience'
    ]
  },
  {
    id: 'pro',
    name: 'Pro',
    nameTe: 'ప్రో ప్లాన్',
    price: 59,
    billingPeriod: '/month',
    daysDuration: 30,
    popular: true,
    badge: 'Most Popular',
    features: [
      'Everything in Starter Plan',
      'All 8 Specialized AI Workstations Unlocked',
      'Fast Inference Routing & Priority Models',
      'Full Code Analysis & System Architecture',
      '30 Days Guaranteed Access'
    ]
  },
  {
    id: 'premium',
    name: 'Premium',
    nameTe: 'ప్రీమియం ప్లాన్',
    price: 79,
    billingPeriod: '/month',
    daysDuration: 30,
    badge: 'Power User',
    features: [
      'Everything in Pro Plan',
      'Executive Business & Startup Strategy Engines',
      'High-Priority Model Allocation',
      'Export Chats & Markdown Summaries',
      '30 Days Unlocked Access',
      'Priority Support Assistance'
    ]
  },
  {
    id: 'ultimate',
    name: 'Ultimate',
    nameTe: 'అల్టిమేట్ ప్లాన్',
    price: 99,
    billingPeriod: '/month',
    daysDuration: 30,
    badge: 'VIP Full Access',
    features: [
      'Complete VIP Suite Access',
      'Highest Priority Server Queuing',
      'All 8 AI Workstations + Early New Features',
      'Maximum Token Context Window Allocation',
      '30 Days Guaranteed Unlocked Access',
      'Direct Priority Engineering Routing'
    ]
  }
];

function getUserSubscriptionWithStatus(user: UserRecord) {
  if (!user.subscription) return undefined;
  const now = Date.now();
  const expiresAtMs = user.subscription.expiresAt ? new Date(user.subscription.expiresAt).getTime() : 0;
  const isExpired = user.subscription.status === 'active' && expiresAtMs > 0 && expiresAtMs < now;
  const daysRemaining = user.subscription.status === 'active' && expiresAtMs > now
    ? Math.max(0, Math.ceil((expiresAtMs - now) / (1000 * 60 * 60 * 24)))
    : 0;

  if (isExpired && user.subscription.status === 'active') {
    user.subscription.status = 'expired';
    saveDatabase(db);
  }

  return {
    ...user.subscription,
    status: isExpired ? ('expired' as const) : user.subscription.status,
    isExpired,
    daysRemaining
  };
}

// Server-side Gemini Client
function getGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    throw new Error('GEMINI_API_KEY_MISSING');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build'
      }
    }
  });
}

// -------------------------------------------------------------
// API Endpoints
// -------------------------------------------------------------

// System Health & Configuration status
app.get('/api/health', (req, res) => {
  const hasKey = Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== 'MY_GEMINI_API_KEY');
  res.json({
    status: 'ok',
    appName: 'TalkBot AI',
    tagline: 'Your World. One AI.',
    geminiConfigured: hasKey,
    adSenseEnabled: db.settings.adSenseEnabled,
    defaultLanguage: db.settings.defaultLanguage,
    maintenanceMode: db.settings.maintenanceMode
  });
});

// Authentication routes
app.post('/api/auth/register', (req, res) => {
  const { email, password, name } = req.body;
  if (!email || !password || !name) {
    return res.status(400).json({ error: 'Name, email, and password are required' });
  }
  const cleanEmail = String(email).trim().toLowerCase();
  if (!cleanEmail.includes('@') || password.length < 6) {
    return res.status(400).json({ error: 'Invalid email address or password too short (min 6 chars)' });
  }

  const existing = db.users.find(u => u.email === cleanEmail);
  if (existing) {
    return res.status(400).json({ error: 'An account with this email already exists' });
  }

  const salt = generateSalt();
  const passwordHash = hashPassword(password, salt);
  // Strictly enforce admin role: only authorized admin email
  const role: 'admin' | 'user' = cleanEmail === ADMIN_EMAIL.toLowerCase() ? 'admin' : 'user';

  const newUser: UserRecord = {
    id: `user-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
    email: cleanEmail,
    name: String(name).trim(),
    passwordHash,
    salt,
    role,
    createdAt: new Date().toISOString()
  };

  db.users.push(newUser);

  // Auto-login session
  const token = generateToken();
  db.sessions[token] = {
    userId: newUser.id,
    email: newUser.email,
    role: newUser.role,
    expiresAt: Date.now() + 30 * 24 * 60 * 60 * 1000 // 30 days
  };
  saveDatabase(db);

  res.status(201).json({
    token,
    user: {
      id: newUser.id,
      email: newUser.email,
      name: newUser.name,
      role: newUser.role,
      subscription: getUserSubscriptionWithStatus(newUser)
    }
  });
});

app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required' });
  }
  const cleanEmail = String(email).trim().toLowerCase();
  let user = db.users.find(u => u.email === cleanEmail);

  // If this is the configured admin and they haven't registered yet, auto-provision admin safely with the given password
  if (!user && cleanEmail === ADMIN_EMAIL.toLowerCase()) {
    const salt = generateSalt();
    const passwordHash = hashPassword(password, salt);
    user = {
      id: `admin-${Date.now()}`,
      email: cleanEmail,
      name: 'System Administrator',
      passwordHash,
      salt,
      role: 'admin',
      createdAt: new Date().toISOString()
    };
    db.users.push(user);
    saveDatabase(db);
  }

  if (!user) {
    return res.status(401).json({ error: 'Invalid email or password' });
  }

  const testHash = hashPassword(password, user.salt);
  if (testHash !== user.passwordHash) {
    return res.status(401).json({ error: 'Invalid email or password' });
  }

  // Double check admin role
  if (user.email === ADMIN_EMAIL.toLowerCase() && user.role !== 'admin') {
    user.role = 'admin';
  }

  const token = generateToken();
  db.sessions[token] = {
    userId: user.id,
    email: user.email,
    role: user.role,
    expiresAt: Date.now() + 30 * 24 * 60 * 60 * 1000
  };
  saveDatabase(db);

  res.json({
    token,
    user: {
      id: user.id,
      email: user.email,
      name: user.name,
      role: user.role,
      subscription: getUserSubscriptionWithStatus(user)
    }
  });
});

app.get('/api/auth/me', authenticate, (req, res) => {
  const session = (req as any).user;
  const user = db.users.find(u => u.id === session.userId);
  if (!user) {
    return res.status(404).json({ error: 'User record not found' });
  }
  res.json({
    user: {
      id: user.id,
      email: user.email,
      name: user.name,
      role: user.role,
      subscription: getUserSubscriptionWithStatus(user)
    }
  });
});

app.post('/api/auth/logout', authenticate, (req, res) => {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.substring(7);
    delete db.sessions[token];
    saveDatabase(db);
  }
  res.json({ success: true, message: 'Logged out successfully' });
});

app.post('/api/auth/reset-password', (req, res) => {
  const { email, newPassword } = req.body;
  if (!email || !newPassword || newPassword.length < 6) {
    return res.status(400).json({ error: 'Valid email and new password (min 6 characters) required' });
  }
  const cleanEmail = String(email).trim().toLowerCase();
  const user = db.users.find(u => u.email === cleanEmail);
  if (!user) {
    // For privacy, do not reveal non-existence, but inform standard instructions
    return res.json({ success: true, message: 'If an account exists with this email, your password has been reset.' });
  }

  user.salt = generateSalt();
  user.passwordHash = hashPassword(newPassword, user.salt);
  saveDatabase(db);
  res.json({ success: true, message: 'Password has been successfully updated. You may now log in.' });
});

// -------------------------------------------------------------
// Real AI Chat Endpoint (Official @google/genai SDK, server-side only)
// -------------------------------------------------------------
app.post('/api/chat', async (req, res) => {
  try {
    const { messages, language = 'en', persona = 'general' } = req.body;

    if (!Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: 'Please provide messages array with at least one message.' });
    }

    let ai: GoogleGenAI;
    try {
      ai = getGeminiClient();
    } catch (err: any) {
      if (err.message === 'GEMINI_API_KEY_MISSING') {
        return res.status(503).json({
          error: 'GEMINI_API_KEY is not configured on the server. Please ensure the GEMINI_API_KEY environment variable is set.'
        });
      }
      throw err;
    }

    // Build system instructions based on language & persona
    const isTelugu = language === 'te';
    let systemInstruction = `You are TALKBOT AI, a premium, intelligent, versatile, and articulate AI assistant.
Brand name: TALKBOT AI
Tagline: "Your World. One AI."
Founder: Maaneesh
Official designation: Founder & CEO of TALKBOT AI
You excel across education, mathematics, creative writing, software engineering, business strategy, and global knowledge. When asked about your origin, identity, or creator, state that you are TALKBOT AI ("Your World. One AI."), founded by Maaneesh, Founder & CEO of TALKBOT AI.`;

    if (isTelugu) {
      systemInstruction += `\nCRITICAL LANGUAGE DIRECTIVE: The user has selected TELUGU (తెలుగు) as their preferred language. Respond in fluent, accurate, elegant, and natural Telugu (తెలుగు లిపి). When discussing technical concepts, computer science, or mathematics, explain clearly in Telugu and you may include English technical terms in parentheses for precision. Be polite, culturally respectful, and comprehensive.`;
    } else {
      systemInstruction += `\nLANGUAGE DIRECTIVE: Communicate in clear, concise, and structured English. Format responses with markdown, bullet points, and code fences where helpful.`;
    }

    if (persona === 'tutor') {
      systemInstruction += `\nYou are operating in Socratic Academic Tutor mode: Explain step-by-step, verify foundational principles, and encourage deep comprehension.`;
    } else if (persona === 'coder') {
      systemInstruction += `\nYou are operating in Senior Software Architect mode: Provide clean, idiomatic code, explain architecture choices, and highlight performance and edge cases.`;
    } else if (persona === 'business') {
      systemInstruction += `\nYou are operating in Executive Business Strategist mode: Structure insights around market dynamics, value proposition, operational execution, and revenue viability.`;
    }

    // Format conversation history for Gemini API
    // Gemini SDK expects contents array with role: 'user' or 'model'
    const contents = messages.map(m => ({
      role: m.role === 'assistant' || m.role === 'model' ? 'model' : 'user',
      parts: [{ text: String(m.content || '') }]
    }));

    // Candidate models from skill: prioritize flash-lite (high RPM quota, low latency), fallback seamlessly
    const candidateModels = ['gemini-3.1-flash-lite', 'gemini-flash-latest', 'gemini-3.8-flash'];
    let lastError: any = null;
    let responseText: string | undefined = undefined;
    let usedModel = 'gemini-3.1-flash-lite';

    for (const modelName of candidateModels) {
      try {
        const response = await ai.models.generateContent({
          model: modelName,
          contents,
          config: {
            systemInstruction,
            temperature: 0.7,
            topP: 0.95
          }
        });
        if (response.text) {
          responseText = response.text;
          usedModel = modelName;
          break;
        }
      } catch (err: any) {
        lastError = err;
        const msg = String(err?.message || '');
        console.warn(`Model ${modelName} returned error, checking next candidate:`, msg);
        const isRetryable =
          msg.includes('503') ||
          msg.includes('504') ||
          msg.includes('429') ||
          msg.includes('RESOURCE_EXHAUSTED') ||
          msg.includes('quota') ||
          msg.includes('rate limit') ||
          msg.includes('high demand') ||
          msg.includes('DEADLINE_EXCEEDED') ||
          msg.includes('UNAVAILABLE');

        if (!isRetryable) {
          break;
        }

        // Brief jittered pause before trying the next fallback model
        const jitter = Math.floor(Math.random() * 300) + 200;
        await new Promise(resolve => setTimeout(resolve, jitter));
      }
    }

    if (!responseText) {
      throw lastError || new Error('The AI model returned an empty response.');
    }

    res.json({
      response: responseText,
      model: usedModel,
      language
    });
  } catch (error: any) {
    console.error('Gemini Chat API Error:', error?.message || error);

    // Differentiate quota exhaustion vs temporary rate limits vs auth errors
    const errorMessage = String(error?.message || error);
    const lowerMsg = errorMessage.toLowerCase();

    if (
      lowerMsg.includes('free_tier_requests') ||
      lowerMsg.includes('quota exceeded for metric') ||
      (lowerMsg.includes('limit:') && lowerMsg.includes('quota'))
    ) {
      return res.status(429).json({
        error: 'Google Gemini free-tier daily request quota has been reached for this project. Daily limits on Google’s free tier replenish automatically. Please wait before retrying.',
        errorType: 'QUOTA_EXHAUSTED',
        retryAfter: 30
      });
    }

    if (errorMessage.includes('429') || lowerMsg.includes('rate limit') || lowerMsg.includes('resource_exhausted')) {
      return res.status(429).json({
        error: 'Gemini API temporary rate limit reached due to high traffic spikes. Please wait a brief moment and tap Retry.',
        errorType: 'RATE_LIMITED',
        retryAfter: 8
      });
    }

    if (
      errorMessage.includes('API_KEY_INVALID') ||
      errorMessage.includes('403') ||
      lowerMsg.includes('unauthorized') ||
      lowerMsg.includes('api key not valid')
    ) {
      return res.status(403).json({
        error: 'Invalid or unauthorized GEMINI_API_KEY. Please verify server environment credentials.',
        errorType: 'AUTH_ERROR'
      });
    }

    if (errorMessage.includes('503') || lowerMsg.includes('unavailable') || lowerMsg.includes('deadline_exceeded')) {
      return res.status(503).json({
        error: 'Gemini AI servers are temporarily experiencing high demand. Please retry in a few seconds.',
        errorType: 'SERVICE_UNAVAILABLE',
        retryAfter: 5
      });
    }

    return res.status(500).json({
      error: 'Temporary error communicating with the AI service. Please check your connection and retry.',
      errorType: 'SERVER_ERROR'
    });
  }
});

// -------------------------------------------------------------
// Real AI Tools Endpoint (Study, Writing, Coding, Business, Email, Social, Website, Interview)
// -------------------------------------------------------------
app.post('/api/tool/execute', async (req, res) => {
  try {
    const { toolId, prompt, language = 'en', inputs = {} } = req.body;

    if (!toolId || !prompt) {
      return res.status(400).json({ error: 'toolId and prompt are required' });
    }

    let ai: GoogleGenAI;
    try {
      ai = getGeminiClient();
    } catch (err: any) {
      if (err.message === 'GEMINI_API_KEY_MISSING') {
        return res.status(503).json({
          error: 'GEMINI_API_KEY is not configured on the server. Please ensure the GEMINI_API_KEY environment variable is set.'
        });
      }
      throw err;
    }

    const isTelugu = language === 'te';
    let toolInstruction = '';

    switch (toolId) {
      case 'study':
        toolInstruction = `You are TalkBot Study Assistant. Break down complex concepts into crystal-clear principles. Include:
1. Core Conceptual Summary
2. Step-by-Step Breakdown
3. 2-3 Quick Practice Questions or Flashcards
4. Common Mistakes to Avoid`;
        break;
      case 'writing':
        toolInstruction = `You are TalkBot Writing Assistant. Deliver polished, engaging, and grammatically impeccable prose. Adapt to the requested tone (formal, storytelling, persuasive, or creative). Provide actionable critique and revised versions.`;
        break;
      case 'coding':
        toolInstruction = `You are TalkBot Coding Assistant. Provide production-ready, clean, secure, and modern code snippets with explanatory comments. Detail time/space complexity and potential edge cases.`;
        break;
      case 'business':
        toolInstruction = `You are TalkBot Business Ideas Assistant. Analyze commercial viability, target demographic, unique value proposition (UVP), monetization models (SaaS, marketplace, freemium, B2B), and go-to-market execution milestones.`;
        break;
      case 'email':
        toolInstruction = `You are TalkBot Email and Letter Writer. Generate professional, concise, and persuasive correspondence. Provide clear subject line options, opening hooks, call-to-actions, and graceful sign-offs.`;
        break;
      case 'social':
        toolInstruction = `You are TalkBot Social Media Caption Generator. Generate 3 distinct high-engagement caption variations (e.g. Punchy/Viral, Storytelling/Value, Professional/Educational) with relevant hashtags and call-to-action hooks.`;
        break;
      case 'website':
        toolInstruction = `You are TalkBot Website Planning Assistant. Outline a comprehensive website architecture: Target Audience, Recommended Page Sitemap, Key Conversion Sections, Tech Stack Recommendations, and Essential SEO & UI/UX Checklist.`;
        break;
      case 'interview':
        toolInstruction = `You are TalkBot Interview Practice Coach. Simulate realistic hiring manager questions for the specified domain/role. Provide STAR (Situation, Task, Action, Result) model sample answers, key evaluation criteria, and coaching tips.`;
        break;
      default:
        toolInstruction = `You are TalkBot AI specialized task assistant. Provide high-quality, actionable, structured output.`;
    }

    if (isTelugu) {
      toolInstruction += `\nCRITICAL LANGUAGE REQUIREMENT: Output your entire answer in authentic, natural, and grammatically accurate Telugu (తెలుగు లిపి). English technical terms can be placed in parentheses when necessary.`;
    } else {
      toolInstruction += `\nFormat the response in structured markdown with bold headings and organized sections.`;
    }

    // Contextual additions from inputs
    let composedPrompt = prompt;
    if (Object.keys(inputs).length > 0) {
      composedPrompt += `\n\nAdditional parameters:\n` + Object.entries(inputs)
        .map(([k, v]) => `- ${k}: ${v}`)
        .join('\n');
    }

    const candidateModels = ['gemini-3.1-flash-lite', 'gemini-flash-latest', 'gemini-3.8-flash'];
    let lastError: any = null;
    let responseText: string | undefined = undefined;

    for (const modelName of candidateModels) {
      try {
        const response = await ai.models.generateContent({
          model: modelName,
          contents: [{ role: 'user', parts: [{ text: composedPrompt }] }],
          config: {
            systemInstruction: toolInstruction,
            temperature: 0.7
          }
        });
        if (response.text) {
          responseText = response.text;
          break;
        }
      } catch (err: any) {
        lastError = err;
        console.warn(`Tool model ${modelName} error, checking next candidate:`, err?.message || err);
        const msg = String(err?.message || '');
        const isRetryable =
          msg.includes('503') ||
          msg.includes('504') ||
          msg.includes('429') ||
          msg.includes('RESOURCE_EXHAUSTED') ||
          msg.includes('quota') ||
          msg.includes('rate limit') ||
          msg.includes('high demand') ||
          msg.includes('DEADLINE_EXCEEDED') ||
          msg.includes('UNAVAILABLE');

        if (!isRetryable) {
          break;
        }
      }
    }

    if (!responseText) {
      throw lastError || new Error('The AI model returned an empty response. Please try with more details.');
    }

    res.json({
      toolId,
      result: responseText,
      language
    });
  } catch (error: any) {
    console.error('Gemini Tool API Error:', error);
    const errorMessage = error?.message || String(error);
    if (errorMessage.includes('429') || errorMessage.toLowerCase().includes('quota')) {
      return res.status(429).json({ error: 'Gemini API quota or rate limit exceeded. Please wait a moment.' });
    }
    return res.status(500).json({ error: `Tool execution failed: ${errorMessage}` });
  }
});

// -------------------------------------------------------------
// Articles API (Original, informative content with Search & Category filter)
// -------------------------------------------------------------
app.get('/api/articles', (req, res) => {
  const { category, search } = req.query;
  let articles = db.articles.filter(a => a.published);

  if (category && category !== 'All') {
    articles = articles.filter(a => a.category.toLowerCase() === String(category).toLowerCase());
  }

  if (search) {
    const q = String(search).toLowerCase();
    articles = articles.filter(a =>
      a.title.toLowerCase().includes(q) ||
      a.description.toLowerCase().includes(q) ||
      a.tags.some(t => t.toLowerCase().includes(q))
    );
  }

  res.json({ articles });
});

app.get('/api/articles/:slug', (req, res) => {
  const { slug } = req.params;
  const article = db.articles.find(a => a.slug === slug || a.id === slug);
  if (!article) {
    return res.status(404).json({ error: 'Article not found' });
  }
  res.json({ article });
});

// Protected Admin Article management
app.post('/api/admin/articles', authenticate, requireAdmin, (req, res) => {
  const { title, category, description, content, tags, readTime } = req.body;
  if (!title || !content || !description) {
    return res.status(400).json({ error: 'Title, description, and content are required' });
  }

  const slug = title
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)+/g, '');

  const newArticle: ArticleRecord = {
    id: `art-${Date.now()}`,
    slug: `${slug}-${Math.random().toString(36).substr(2, 4)}`,
    title: String(title).trim(),
    category: category || 'Technology',
    description: String(description).trim(),
    content: String(content).trim(),
    readTime: readTime || '5 min read',
    publishedAt: new Date().toISOString().split('T')[0],
    published: true,
    authorRole: 'TalkBot Editorial Group',
    tags: Array.isArray(tags) ? tags : ['AI', 'Tech']
  };

  db.articles.unshift(newArticle);
  saveDatabase(db);
  res.status(201).json({ article: newArticle });
});

app.put('/api/admin/articles/:id', authenticate, requireAdmin, (req, res) => {
  const { id } = req.params;
  const index = db.articles.findIndex(a => a.id === id);
  if (index === -1) {
    return res.status(404).json({ error: 'Article not found' });
  }

  const existing = db.articles[index];
  db.articles[index] = {
    ...existing,
    ...req.body,
    id: existing.id // preserve ID
  };
  saveDatabase(db);
  res.json({ article: db.articles[index] });
});

app.delete('/api/admin/articles/:id', authenticate, requireAdmin, (req, res) => {
  const { id } = req.params;
  const index = db.articles.findIndex(a => a.id === id);
  if (index === -1) {
    return res.status(404).json({ error: 'Article not found' });
  }

  db.articles.splice(index, 1);
  saveDatabase(db);
  res.json({ success: true, message: 'Article deleted successfully' });
});

// -------------------------------------------------------------
// Site Settings & AdSense Management (Admin Protected)
// -------------------------------------------------------------
app.get('/api/settings/public', (req, res) => {
  res.json({
    adSenseEnabled: db.settings.adSenseEnabled,
    adSenseClientId: db.settings.adSenseClientId,
    maintenanceMode: db.settings.maintenanceMode,
    bannerNotice: db.settings.bannerNotice,
    defaultLanguage: db.settings.defaultLanguage,
    phonePeNumber: db.settings.phonePeNumber || '9876543210',
    phonePeUpiId: db.settings.phonePeUpiId || 'talkbot@ybl',
    phonePeRecipientName: db.settings.phonePeRecipientName || 'TALKBOT AI (Maaneesh)',
    merchantVerifiedMode: Boolean(db.settings.merchantVerifiedMode)
  });
});

app.get('/api/admin/settings', authenticate, requireAdmin, (req, res) => {
  res.json({
    settings: db.settings,
    totalUsers: db.users.length,
    totalArticles: db.articles.length,
    adminEmail: ADMIN_EMAIL
  });
});

app.put('/api/admin/settings', authenticate, requireAdmin, (req, res) => {
  db.settings = {
    ...db.settings,
    ...req.body
  };
  saveDatabase(db);
  res.json({ settings: db.settings, message: 'Settings updated successfully' });
});

// -------------------------------------------------------------
// PhonePe Subscriptions Management API
// -------------------------------------------------------------
app.get('/api/subscriptions/plans', (req, res) => {
  res.json({
    plans: SUBSCRIPTION_PLANS,
    phonePeConfig: {
      phonePeNumber: db.settings.phonePeNumber || '9876543210',
      phonePeUpiId: db.settings.phonePeUpiId || 'talkbot@ybl',
      phonePeRecipientName: db.settings.phonePeRecipientName || 'TALKBOT AI (Maaneesh)',
      merchantVerifiedMode: Boolean(db.settings.merchantVerifiedMode)
    }
  });
});

app.get('/api/subscriptions/my', authenticate, (req, res) => {
  const session = (req as any).user;
  const user = db.users.find(u => u.id === session.userId);
  if (!user) {
    return res.status(404).json({ error: 'User record not found' });
  }

  const sub = getUserSubscriptionWithStatus(user);
  res.json({
    subscription: sub || null,
    user: {
      id: user.id,
      email: user.email,
      name: user.name,
      role: user.role
    }
  });
});

app.post('/api/subscriptions/create-order', authenticate, (req, res) => {
  const session = (req as any).user;
  const user = db.users.find(u => u.id === session.userId);
  if (!user) {
    return res.status(404).json({ error: 'User record not found' });
  }

  const { planId } = req.body;
  const plan = SUBSCRIPTION_PLANS.find(p => p.id === planId);
  if (!plan) {
    return res.status(400).json({ error: 'Invalid subscription plan selected' });
  }

  const orderId = `sub-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`;
  const order: SubscriptionOrder = {
    id: orderId,
    userId: user.id,
    userEmail: user.email,
    userName: user.name,
    planId: plan.id as any,
    planName: plan.name,
    amount: plan.price,
    phonePeTransactionId: '',
    status: 'pending_verification',
    createdAt: new Date().toISOString()
  };

  db.subscriptions.unshift(order);
  saveDatabase(db);

  res.status(201).json({
    order,
    phonePeConfig: {
      phonePeNumber: db.settings.phonePeNumber || '9876543210',
      phonePeUpiId: db.settings.phonePeUpiId || 'talkbot@ybl',
      phonePeRecipientName: db.settings.phonePeRecipientName || 'TALKBOT AI (Maaneesh)',
      merchantVerifiedMode: Boolean(db.settings.merchantVerifiedMode)
    },
    paymentInstructions: {
      planName: plan.name,
      amount: plan.price,
      currency: 'INR',
      daysDuration: 30,
      phonePeNumber: db.settings.phonePeNumber || '9876543210',
      phonePeUpiId: db.settings.phonePeUpiId || 'talkbot@ybl',
      recipientName: db.settings.phonePeRecipientName || 'TALKBOT AI (Maaneesh)',
      steps: [
        `1. Open PhonePe on your mobile phone.`,
        `2. Send exact amount of ₹${plan.price} to PhonePe Number ${db.settings.phonePeNumber || '9876543210'} or UPI ID ${db.settings.phonePeUpiId || 'talkbot@ybl'}.`,
        `3. Copy the 12-digit PhonePe Transaction ID / UTR number from the payment receipt.`,
        `4. Submit the Transaction ID below to verify your 30-day access.`
      ]
    }
  });
});

app.post('/api/subscriptions/submit-proof', authenticate, (req, res) => {
  const session = (req as any).user;
  const { orderId, phonePeTransactionId, customerPhone } = req.body;

  if (!orderId || !phonePeTransactionId || String(phonePeTransactionId).trim().length < 6) {
    return res.status(400).json({
      error: 'A valid PhonePe Transaction ID / UTR (minimum 6 characters) is strictly required.'
    });
  }

  const cleanTxId = String(phonePeTransactionId).trim();
  const cleanPhone = customerPhone ? String(customerPhone).trim() : '';

  const orderIndex = db.subscriptions.findIndex(o => o.id === orderId && o.userId === session.userId);
  if (orderIndex === -1) {
    return res.status(404).json({ error: 'Subscription order not found or does not belong to your account' });
  }

  const order = db.subscriptions[orderIndex];
  order.phonePeTransactionId = cleanTxId;
  order.customerPhone = cleanPhone;
  order.status = 'pending_verification';

  const user = db.users.find(u => u.id === session.userId);
  if (user) {
    user.subscription = {
      planId: order.planId,
      planName: order.planName,
      amount: order.amount,
      status: 'pending_verification',
      phonePeTransactionId: cleanTxId,
      customerPhone: cleanPhone,
      createdAt: order.createdAt
    };
  }

  saveDatabase(db);

  res.json({
    success: true,
    status: 'pending_verification',
    order,
    verified: false,
    message: 'Payment submission received. Your subscription is pending verification against official PhonePe merchant records. Access will be unlocked for 30 days as soon as the administrator verifies your transaction.',
    securityNotice: 'TalkBot AI does not activate premium access based only on screenshots or unverified claims. Verification ensures mutual security and zero fraud.'
  });
});

app.get('/api/admin/subscriptions', authenticate, requireAdmin, (req, res) => {
  res.json({
    subscriptions: db.subscriptions,
    totalOrders: db.subscriptions.length,
    pendingCount: db.subscriptions.filter(s => s.status === 'pending_verification').length,
    activeCount: db.subscriptions.filter(s => s.status === 'active').length,
    phonePeConfig: {
      phonePeNumber: db.settings.phonePeNumber || '9876543210',
      phonePeUpiId: db.settings.phonePeUpiId || 'talkbot@ybl',
      phonePeRecipientName: db.settings.phonePeRecipientName || 'TALKBOT AI (Maaneesh)'
    }
  });
});

app.post('/api/admin/subscriptions/:id/verify', authenticate, requireAdmin, (req, res) => {
  const { id } = req.params;
  const order = db.subscriptions.find(s => s.id === id);
  if (!order) {
    return res.status(404).json({ error: 'Subscription order not found' });
  }

  const now = new Date();
  const expiresAt = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000); // Exactly 30 days

  order.status = 'active';
  order.verifiedAt = now.toISOString();
  order.expiresAt = expiresAt.toISOString();

  // Find customer and activate 30 days
  const user = db.users.find(u => u.id === order.userId);
  if (user) {
    user.subscription = {
      planId: order.planId,
      planName: order.planName,
      amount: order.amount,
      status: 'active',
      phonePeTransactionId: order.phonePeTransactionId,
      customerPhone: order.customerPhone,
      createdAt: order.createdAt,
      verifiedAt: order.verifiedAt,
      expiresAt: order.expiresAt
    };
  }

  saveDatabase(db);

  res.json({
    success: true,
    order,
    userSubscription: user ? getUserSubscriptionWithStatus(user) : null,
    message: `Payment verified. 30 days of access granted until ${expiresAt.toLocaleDateString('en-IN')}.`
  });
});

app.post('/api/admin/subscriptions/:id/reject', authenticate, requireAdmin, (req, res) => {
  const { id } = req.params;
  const { notes } = req.body;
  const order = db.subscriptions.find(s => s.id === id);
  if (!order) {
    return res.status(404).json({ error: 'Subscription order not found' });
  }

  order.status = 'rejected';
  order.notes = notes || 'Transaction ID could not be verified in PhonePe merchant account.';

  const user = db.users.find(u => u.id === order.userId);
  if (user && user.subscription?.phonePeTransactionId === order.phonePeTransactionId) {
    user.subscription.status = 'rejected';
  }

  saveDatabase(db);
  res.json({ success: true, order, message: 'Subscription order marked as rejected.' });
});

app.delete('/api/admin/subscriptions/:id', authenticate, requireAdmin, (req, res) => {
  const { id } = req.params;
  const idx = db.subscriptions.findIndex(s => s.id === id);
  if (idx === -1) {
    return res.status(404).json({ error: 'Subscription order not found' });
  }
  db.subscriptions.splice(idx, 1);
  saveDatabase(db);
  res.json({ success: true, message: 'Subscription record deleted.' });
});

// -------------------------------------------------------------
// User Chat History Storage (Per-user private sync)
// -------------------------------------------------------------
app.get('/api/history', authenticate, (req, res) => {
  const session = (req as any).user;
  const userHistory = db.chatHistories[session.userId] || [];
  res.json({ histories: userHistory });
});

app.post('/api/history', authenticate, (req, res) => {
  const session = (req as any).user;
  const { id, title, messages } = req.body;
  if (!id || !messages) {
    return res.status(400).json({ error: 'Chat id and messages are required' });
  }

  if (!db.chatHistories[session.userId]) {
    db.chatHistories[session.userId] = [];
  }

  const existingIdx = db.chatHistories[session.userId].findIndex(h => h.id === id);
  const record: ChatHistoryItem = {
    id,
    userId: session.userId,
    title: title || 'New Conversation',
    messages,
    updatedAt: new Date().toISOString()
  };

  if (existingIdx >= 0) {
    db.chatHistories[session.userId][existingIdx] = record;
  } else {
    db.chatHistories[session.userId].unshift(record);
  }

  // Keep max 50 conversations per user
  if (db.chatHistories[session.userId].length > 50) {
    db.chatHistories[session.userId] = db.chatHistories[session.userId].slice(0, 50);
  }

  saveDatabase(db);
  res.json({ success: true, history: record });
});

app.delete('/api/history/:id', authenticate, (req, res) => {
  const session = (req as any).user;
  const { id } = req.params;
  if (db.chatHistories[session.userId]) {
    db.chatHistories[session.userId] = db.chatHistories[session.userId].filter(h => h.id !== id);
    saveDatabase(db);
  }
  res.json({ success: true });
});

// -------------------------------------------------------------
// Vite Middleware / Static Serve
// -------------------------------------------------------------
async function startServer() {
  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[TalkBot AI] Server running on http://0.0.0.0:${PORT} in ${isProd ? 'production' : 'development'} mode`);
  });
}

startServer().catch(err => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
